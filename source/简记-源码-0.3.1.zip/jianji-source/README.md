# 简记 · iPhone PWA

快捷指令截屏与 OCR、黑白极简界面、确认或自动入账的本地优先记账 PWA，支持可选的 Supabase 云同步。

## 运行

```bash
cd app
npm install
npm run dev
```

构建：

```bash
npm run build
npm run preview
```

生产构建在 `app/dist/`，部署时把该目录作为站点根目录。

## iPhone 自动记账快捷指令

推荐的自动模式：

1. 打开“快捷指令”，新建“自动记一笔”。
2. 添加“截屏”。
3. 添加“从图像中提取文本”，输入为截屏。
4. 添加“URL 编码”，输入为提取出的文本。
5. 添加“打开 URL”，使用：
   `https://你的域名/?capture=auto&text=编码后的文本&auto=1`
   把「编码后的文本」替换为上一步的 URL 编码结果。
6. 可在“设置 → 辅助功能 → 触控 → 轻点背面”中绑定该快捷指令。

打开 `auto=1` 时：

- 高置信度、有金额、未发现重复的账目会直接入账。
- 低置信度、缺少金额或疑似重复的账目会进入核对页。
- 快捷指令不会把原图传给 PWA；图片只在 Shortcuts 的 Apple OCR 流程中临时使用，不写入相册。

## 备用方式

如果尚未配置“从图像中提取文本”，可以用剪贴板兜底：

1. 快捷指令添加“截屏”和“拷贝到剪贴板”。
2. 打开 `/capture=1` 页面，点“读取剪贴板截图”。
3. iOS 拒绝读取时，长按扫描页粘贴区手动粘贴。

## 隐私边界

- 不提供相册或相机入口。
- 原图不进入 PWA，不写入 IndexedDB、localStorage 或文件系统。
- IndexedDB 只保存用户确认后的金额、商户、时间、分类、支付方式和备注。
- 没有后端、账号、同步或上传接口。

## 技术栈

- Vite + React + TypeScript
- vite-plugin-pwa / Workbox
- Tesseract.js 7（剪贴板备用模式的本地 chi_sim + eng 模型）
- IndexedDB
- Supabase Auth + Postgres（可选云同步）

## Supabase 云同步

1. 在 Supabase SQL Editor 执行 `../supabase/schema.sql`。
2. 在 `app/.env.production` 配置：

```text
VITE_SUPABASE_URL=https://你的项目.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=sb_publishable_xxx
```

Publishable Key 可以公开，但必须保留数据库 RLS 和策略。不要在前端使用 Secret Key。

3. 重新构建并部署。
4. 在简记“设置 → 云同步”中创建账号并登录。

Safari 与主屏幕 PWA 需要使用同一个账号登录；首次登录会把两边已有账目按 ID 合并。删除操作通过本地 tombstone 同步，不会在其他设备上复活。
