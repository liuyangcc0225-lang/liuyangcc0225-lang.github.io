import { cp, mkdir, rm, stat } from 'node:fs/promises';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const appRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const targetIndex = process.argv.indexOf('--target');
const target = path.resolve(targetIndex >= 0 ? process.argv[targetIndex + 1] : path.join(appRoot, '..', '..', 'jianji'));

if (path.basename(target) !== 'jianji') {
  throw new Error('Refusing to publish: target directory must be named jianji');
}

const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
const run = (args) => execFileSync(npm, args, { cwd: appRoot, stdio: 'inherit' });

run(['run', 'build']);
run(['exec', 'vite', '--', 'build', '--mode', 'github', '--outDir', 'dist-github']);

const dist = path.join(appRoot, 'dist-github');

// Runtime-only OCR assets are intentionally excluded from the source archive
// to keep the repository small. Reuse the current Pages copy when building.
for (const directory of ['tesseract', 'tessdata', 'icons']) {
  const source = path.join(target, directory);
  try {
    await stat(source);
    await cp(source, path.join(appRoot, 'public', directory), { recursive: true, force: true });
  } catch {
    // The local development copy in public/ is already available.
  }
}

await stat(path.join(dist, 'index.html'));

// The target is exclusively the Jianji app directory. Removing it first avoids
// accumulating stale hashed bundles and stale Service Worker precache entries.
await rm(target, { recursive: true, force: true });
await mkdir(path.dirname(target), { recursive: true });
await cp(dist, target, { recursive: true });

console.log(`Published ${dist} -> ${target}`);
