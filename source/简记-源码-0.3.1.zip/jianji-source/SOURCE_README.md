# 简记源码 0.3.1

源码包包含 React/TypeScript 页面、OCR 懒加载、PWA 构建配置、Supabase Schema、Muse Edge Function 和发布脚本。

## Muse 权限

- `read`：查询账目与分类
- `write`：创建账目
- `update`：修改由 Muse 创建的账目
- `delete`：删除由 Muse 创建的账目

手工账目不会被 Muse 修改或删除。

## 构建

```powershell
npm ci
npm run build
npm run publish:pages -- --target C:\path\to\repo\jianji
```

Tesseract wasm 和语言包体积较大，不重复放入源码包。构建前从部署目录的 `jianji/tesseract`、`jianji/tessdata` 复制到 `public/`。发布脚本会先清空整个 `jianji/` 部署目录，避免旧 assets 堆积。
