import { useState, type FormEvent } from 'react';
import {
  Bot,
  Check,
  ChevronRight,
  ClipboardCopy,
  Cloud,
  CloudOff,
  Database,
  Download,
  Info,
  KeyRound,
  LockKeyhole,
  LogIn,
  LogOut,
  RefreshCw,
  RotateCcw,
  Share,
  Smartphone,
  Trash2,
  UserRound,
} from 'lucide-react';
import type { AppSettings, CloudPhase } from '../types';

type CloudSignUpResult = { ok: boolean; message: string };

type Props = {
  settings: AppSettings;
  onSettingsChange: (settings: AppSettings) => void;
  onExport: () => void;
  onClearSamples: () => void;
  onReset: () => void;
  installPrompt: BeforeInstallPromptEvent | null;
  onInstall: () => void;
  isStandalone: boolean;
  cloudConfigured: boolean;
  cloudPhase: CloudPhase;
  cloudEmail?: string;
  cloudError: string;
  lastSyncedAt: string;
  onCloudSignIn: (email: string, password: string) => Promise<string | null>;
  onCloudSignUp: (email: string, password: string) => Promise<CloudSignUpResult>;
  onCloudSignOut: () => Promise<void>;
  onCloudSync: () => Promise<void>;
  shortcutToken: string;
  shortcutEndpoint: string;
  shortcutApiKey: string;
  onGenerateShortcutToken: () => Promise<string>;
  onRevokeShortcutToken: () => Promise<void>;
  museToken: string;
  museEndpoint: string;
  onGenerateMuseToken: () => Promise<string>;
  onRevokeMuseToken: () => Promise<void>;
};


const syncLabels: Record<CloudPhase, string> = {
  disabled: '未配置',
  'signed-out': '未登录',
  connecting: '正在连接',
  syncing: '同步中',
  synced: '已同步',
  error: '同步失败',
};

export default function SettingsPage({
  settings,
  onSettingsChange,
  onExport,
  onClearSamples,
  onReset,
  installPrompt,
  onInstall,
  isStandalone,
  cloudConfigured,
  cloudPhase,
  cloudEmail,
  cloudError,
  lastSyncedAt,
  onCloudSignIn,
  onCloudSignUp,
  onCloudSignOut,
  onCloudSync,
  shortcutToken,
  shortcutEndpoint,
  shortcutApiKey,
  onGenerateShortcutToken,
  onRevokeShortcutToken,
  museToken,
  museEndpoint,
  onGenerateMuseToken,
  onRevokeMuseToken,
}: Props) {
  const [copied, setCopied] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [cloudBusy, setCloudBusy] = useState(false);
  const [cloudMessage, setCloudMessage] = useState('');
  const [shortcutBusy, setShortcutBusy] = useState(false);
  const [shortcutCopied, setShortcutCopied] = useState(false);
  const [museBusy, setMuseBusy] = useState(false);
  const [museCopied, setMuseCopied] = useState(false);
  const [museDeleteCopied, setMuseDeleteCopied] = useState(false);
  const autoTemplate = `${window.location.origin}${import.meta.env.BASE_URL}?capture=auto&text=编码后的文本&auto=1`;

  const signedIn = Boolean(cloudEmail);
  const lastSyncLabel = lastSyncedAt
    ? new Date(lastSyncedAt).toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai', month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })
    : '尚未同步';

  async function copy(value: string) {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  }

  async function handleSignIn(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setCloudBusy(true);
    setCloudMessage('');
    const error = await onCloudSignIn(email, password);
    if (!error) {
      setPassword('');
      setCloudMessage('');
    } else {
      setCloudMessage(error);
    }
    setCloudBusy(false);
  }

  async function handleSignUp() {
    setCloudBusy(true);
    setCloudMessage('');
    const result = await onCloudSignUp(email, password);
    setCloudMessage(result.message);
    if (result.ok) setPassword('');
    setCloudBusy(false);
  }

  async function copyShortcutConfig() {
    if (!shortcutToken) return;
    const config = JSON.stringify({ url: shortcutEndpoint, apikey: shortcutApiKey, token: shortcutToken }, null, 2);
    try {
      await navigator.clipboard.writeText(config);
      setShortcutCopied(true);
      window.setTimeout(() => setShortcutCopied(false), 1800);
    } catch {
      setShortcutCopied(false);
    }
  }

  async function handleGenerateShortcutToken() {
    setShortcutBusy(true);
    await onGenerateShortcutToken();
    setShortcutBusy(false);
  }

  async function handleRevokeShortcutToken() {
    setShortcutBusy(true);
    await onRevokeShortcutToken();
    setShortcutBusy(false);
  }

  async function copyMuseConfig() {
    if (!museToken) return;
    const config = JSON.stringify({
      method: 'POST',
      url: museEndpoint,
      headers: {
        Authorization: `Bearer ${museToken}`,
        'Content-Type': 'application/json',
      },
      body: {
        amount: 23.5,
        direction: 'expense',
        merchant: '瑞幸咖啡',
        categoryId: 'food',
        occurredAt: '2026-10-30T14:30:00+08:00',
        source: '微信',
        note: 'Muse 自动记账',
        idempotencyKey: 'muse-20261030-1430-luckin',
      },
      readExample: {
        action: 'list',
        query: { from: '2026-10-01T00:00:00+08:00', limit: 20 },
      },
      updateExample: {
        action: 'update',
        transactionId: '要修改的 Muse 账目 ID',
        fields: { amount: 25, merchant: '瑞幸咖啡', note: '已修改' },
      },
      deleteExample: {
        action: 'delete',
        transactionId: '要删除的 Muse 账目 ID',
      },
    }, null, 2);
    try {
      await navigator.clipboard.writeText(config);
      setMuseCopied(true);
      window.setTimeout(() => setMuseCopied(false), 1800);
    } catch {
      setMuseCopied(false);
    }
  }

  async function handleGenerateMuseToken() {
    setMuseBusy(true);
    await onGenerateMuseToken();
    setMuseBusy(false);
  }

  async function handleRevokeMuseToken() {
    setMuseBusy(true);
    await onRevokeMuseToken();
    setMuseBusy(false);
  }

  async function copyMuseDeleteConfig() {
    if (!museToken) return;
    const config = JSON.stringify({
      method: 'POST',
      url: museEndpoint,
      headers: {
        Authorization: `Bearer ${museToken}`,
        'Content-Type': 'application/json',
      },
      body: {
        action: 'delete',
        transactionId: '要删除的 Muse 账目 ID',
      },
      note: '也可以用 DELETE 请求，并在 body 中传 transactionId 或 idempotencyKey。',
    }, null, 2);
    try {
      await navigator.clipboard.writeText(config);
      setMuseDeleteCopied(true);
      window.setTimeout(() => setMuseDeleteCopied(false), 1800);
    } catch {
      setMuseDeleteCopied(false);
    }
  }
  async function handleSignOut() {
    setCloudBusy(true);
    await onCloudSignOut();
    setCloudMessage('');
    setCloudBusy(false);
  }

  return (
    <main className="page settings-page settings-page-compact">
      <header className="settings-hero">
        <div><h1>设置</h1><p>简记 0.3.3 · 本地优先</p></div>
        <span className={`settings-health ${cloudPhase === 'error' ? 'is-error' : signedIn ? 'is-on' : ''}`}><i aria-hidden="true" />{cloudConfigured ? syncLabels[cloudPhase] : '本地模式'}</span>
      </header>

      <details className="settings-block settings-disclosure cloud-block">
        <summary className="settings-summary">
          <span className="settings-summary-icon">{cloudConfigured ? <Cloud size={18} /> : <CloudOff size={18} />}</span>
          <span className="settings-summary-copy"><strong>云同步</strong><small>{signedIn ? cloudEmail : cloudConfigured ? '登录后跨设备合并账目' : '当前账目只保存在本机'}</small></span>
          <span className="settings-summary-status">{cloudConfigured ? syncLabels[cloudPhase] : '本地'}</span>
          <ChevronRight className="settings-summary-chevron" size={17} aria-hidden="true" />
        </summary>
        <div className="settings-details-body">
          {!cloudConfigured ? (
            <p className="settings-copy">云同步尚未配置。本地记账不受影响。</p>
          ) : signedIn ? (
            <div className="cloud-account">
              <div className="cloud-identity">
                <div className="cloud-avatar"><UserRound size={19} /></div>
                <div><strong>{cloudEmail}</strong><small>Safari 与主屏幕简记共用这份云端账本</small></div>
              </div>
              <div className={`sync-state is-${cloudPhase}`}><span className="sync-dot" aria-hidden="true" /><span>{syncLabels[cloudPhase]}</span><small>{lastSyncLabel}</small></div>
              <p className="microcopy">只同步确认后的账目字段，不上传截图或 OCR 原图。</p>
              <div className="settings-actions">
                <button type="button" className="secondary-button" onClick={() => void onCloudSync()} disabled={cloudPhase === 'syncing'}>
                  <RefreshCw size={16} /> {cloudPhase === 'syncing' ? '同步中' : '立即同步'}
                </button>
                <button type="button" className="secondary-button" onClick={() => void handleSignOut()} disabled={cloudBusy}>
                  <LogOut size={16} /> 退出账号
                </button>
              </div>
              {cloudError || cloudMessage ? <p className="cloud-message is-error">{cloudMessage || cloudError}</p> : null}
            </div>
          ) : (
            <>
              <p className="settings-copy">登录同一账号后，多台设备会自动合并账目；不登录也能完全离线使用。</p>
              <form className="cloud-auth" onSubmit={handleSignIn}>
                <label><span>邮箱</span><input type="email" autoComplete="email" inputMode="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@example.com" required /></label>
                <label><span>密码</span><input type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="至少 6 位" minLength={6} required /></label>
                <div className="settings-actions">
                  <button type="submit" className="secondary-button" disabled={cloudBusy}><LogIn size={16} /> {cloudBusy ? '处理中' : '登录并同步'}</button>
                  <button type="button" className="secondary-button" onClick={() => void handleSignUp()} disabled={cloudBusy || !email || password.length < 6}><UserRound size={16} /> 创建账号</button>
                </div>
              </form>
              {cloudError || cloudMessage ? <p className={`cloud-message ${cloudError ? 'is-error' : ''}`}>{cloudMessage || cloudError}</p> : null}
            </>
          )}
        </div>
      </details>

      <details className="settings-block settings-disclosure">
        <summary className="settings-summary">
          <span className="settings-summary-icon"><Smartphone size={18} /></span>
          <span className="settings-summary-copy"><strong>快捷指令自动记账</strong><small>截屏识别、自动入账与核对</small></span>
          <span className="settings-summary-status">{shortcutToken ? '已配置' : '基础'}</span>
          <ChevronRight className="settings-summary-chevron" size={17} aria-hidden="true" />
        </summary>
        <div className="settings-details-body">
          <p className="settings-copy">截屏只在快捷指令中识别，简记只接收文字并生成账目，不保存原图。</p>
          <div className="url-box"><code>{autoTemplate}</code></div>
          <button type="button" className="secondary-button full-width" onClick={() => void copy(autoTemplate)}>
            {copied ? <Check size={16} /> : <ClipboardCopy size={16} />} {copied ? '地址已复制' : '复制快捷指令地址'}
          </button>
          {!signedIn ? <p className="settings-inline-note">登录云同步后可启用无跳转 POST 写入和独立令牌。</p> : (
            <div className="advanced-connection">
              <div className="advanced-connection-head"><KeyRound size={16} /><strong>无跳转写入</strong><span>POST · 不打开网页</span></div>
              {shortcutToken ? (
                <>
                  <div className="shortcut-token-status"><span>当前令牌</span><code>••••{shortcutToken.slice(-6)}</code></div>
                  <div className="settings-action-list">
                    <button type="button" className="settings-action-row" onClick={() => void copyShortcutConfig()}><ClipboardCopy size={16} /><span>{shortcutCopied ? '配置已复制' : '复制快捷指令配置'}</span><ChevronRight size={14} /></button>
                    <button type="button" className="settings-action-row" onClick={() => void handleGenerateShortcutToken()} disabled={shortcutBusy}><RefreshCw size={16} /><span>重新生成令牌</span><ChevronRight size={14} /></button>
                    <button type="button" className="settings-action-row danger" onClick={() => void handleRevokeShortcutToken()} disabled={shortcutBusy}><Trash2 size={16} /><span>撤销令牌</span><ChevronRight size={14} /></button>
                  </div>
                </>
              ) : (
                <button type="button" className="secondary-button full-width" onClick={() => void handleGenerateShortcutToken()} disabled={shortcutBusy}><KeyRound size={16} /> {shortcutBusy ? '生成中' : '生成快捷指令令牌'}</button>
              )}
            </div>
          )}
        </div>
      </details>

      <details className="settings-block settings-disclosure">
        <summary className="settings-summary">
          <span className="settings-summary-icon"><Bot size={18} /></span>
          <span className="settings-summary-copy"><strong>Muse 写入接口</strong><small>读取、创建、修改与删除</small></span>
          <span className="settings-summary-status">{museToken ? '已配置' : signedIn ? '可启用' : '需登录'}</span>
          <ChevronRight className="settings-summary-chevron" size={17} aria-hidden="true" />
        </summary>
        <div className="settings-details-body">
          {!signedIn ? <p className="settings-copy">登录云同步后，才能为 Muse 生成独立写入令牌。</p> : (
            <div className="advanced-connection">
              <p className="settings-copy">标准 Muse 安全连接只需要一个 Bearer 密钥。手工账目不会被 Muse 修改或删除。</p>
              {museToken ? (
                <>
                  <div className="shortcut-token-status"><span>当前令牌</span><code>••••{museToken.slice(-6)}</code></div>
                  <div className="settings-action-list">
                    <button type="button" className="settings-action-row" onClick={() => void copyMuseConfig()}><ClipboardCopy size={16} /><span>{museCopied ? '配置已复制' : '复制 Muse 连接配置'}</span><ChevronRight size={14} /></button>
                    <button type="button" className="settings-action-row" onClick={() => void copyMuseDeleteConfig()}><ClipboardCopy size={16} /><span>{museDeleteCopied ? '删除配置已复制' : '复制删除配置'}</span><ChevronRight size={14} /></button>
                    <button type="button" className="settings-action-row" onClick={() => void handleGenerateMuseToken()} disabled={museBusy}><RefreshCw size={16} /><span>重新生成令牌</span><ChevronRight size={14} /></button>
                    <button type="button" className="settings-action-row danger" onClick={() => void handleRevokeMuseToken()} disabled={museBusy}><Trash2 size={16} /><span>撤销令牌</span><ChevronRight size={14} /></button>
                  </div>
                </>
              ) : (
                <button type="button" className="secondary-button full-width" onClick={() => void handleGenerateMuseToken()} disabled={museBusy}><KeyRound size={16} /> {museBusy ? '生成中' : '生成 Muse 写入令牌'}</button>
              )}
              <div className="url-box muse-endpoint"><code>{museEndpoint}</code></div>
              <details className="muse-api-details">
                <summary>查看调用格式</summary>
                <pre>{`统一接口：\nPOST ${museEndpoint}\nAuthorization: Bearer 你的令牌\nContent-Type: application/json\n\n查询：\n{"action":"list","query":{"limit":20}}\n\n新增：\n{"amount":23.5,"merchant":"瑞幸咖啡","categoryId":"food","occurredAt":"2026-10-30T14:30:00+08:00"}\n\n修改 Muse 账目：\n{"action":"update","transactionId":"交易 ID","fields":{"amount":25,"note":"已修改"}}\n\n删除 Muse 账目：\n{"action":"delete","transactionId":"交易 ID"}`}</pre>
              </details>
            </div>
          )}
        </div>
      </details>

      <section className="settings-block settings-privacy">
        <div className="settings-heading"><LockKeyhole size={18} /><h2>隐私与识别</h2></div>
        <label className="setting-toggle">
          <span><strong>识别后尝试覆盖剪贴板</strong><small>仅备用剪贴板模式；iOS 可能拒绝自动写入</small></span>
          <input type="checkbox" checked={settings.clearClipboard} onChange={(event) => onSettingsChange({ ...settings, clearClipboard: event.target.checked })} />
          <i aria-hidden="true" />
        </label>
        <label className="setting-toggle">
          <span><strong>记住分类习惯</strong><small>确认分类后，记住商户与分类的对应关系</small></span>
          <input type="checkbox" checked={settings.learnedRules} onChange={(event) => onSettingsChange({ ...settings, learnedRules: event.target.checked })} />
          <i aria-hidden="true" />
        </label>
        <p className="settings-inline-note">原图不进入简记。应用不读取相册或相机，也不会把图片写入本地或服务器。</p>
      </section>

      <details className="settings-block settings-disclosure">
        <summary className="settings-summary">
          <span className="settings-summary-icon"><Database size={18} /></span>
          <span className="settings-summary-copy"><strong>数据与应用</strong><small>安装、导出与清理</small></span>
          <span className="settings-summary-status">{isStandalone ? '已安装' : '浏览器'}</span>
          <ChevronRight className="settings-summary-chevron" size={17} aria-hidden="true" />
        </summary>
        <div className="settings-details-body">
          {isStandalone ? (
            <div className="installed-state"><Check size={18} /> 已作为独立应用运行</div>
          ) : (
            <div className="install-row">
              <div><Share size={17} /><span><strong>安装到主屏幕</strong><small>用 Safari 分享菜单添加到主屏幕</small></span></div>
              {installPrompt ? <button type="button" className="secondary-button" onClick={onInstall}>安装简记</button> : null}
            </div>
          )}
          <div className="settings-action-list data-action-list">
            <button type="button" className="settings-action-row" onClick={onExport}><Download size={16} /><span>导出 CSV</span><ChevronRight size={14} /></button>
            <button type="button" className="settings-action-row" onClick={onClearSamples}><Trash2 size={16} /><span>清除示例账目</span><ChevronRight size={14} /></button>
            <button type="button" className="settings-action-row danger" onClick={onReset}><RotateCcw size={16} /><span>清空全部本地数据</span><ChevronRight size={14} /></button>
          </div>
        </div>
      </details>

      <footer className="settings-about"><Info size={16} /><div><strong>简记 0.3.3</strong><span>本地优先、可选云同步的快捷指令记账 PWA。</span></div></footer>
    </main>
  );
}
