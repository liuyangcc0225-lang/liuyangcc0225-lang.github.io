# 简记源码 0.3.3

源码包包含 React/TypeScript 页面、OCR 懒加载、PWA 构建配置、Supabase Schema、Muse Edge Function 和发布脚本。

## 本次更新

- 账页的“快捷指令自动记账”改为在当前页面打开说明面板，不再跳转设置。
- 分类统计支持点开分类查看本月账目明细，并可继续打开单笔账目。
- 合并分类可展开查看包含的小分类和对应账目。
- 设置页改为摘要加按需展开：云同步、快捷指令、Muse 接口、数据与应用分别收纳。
- 隐私开关和本地数据操作保留清晰入口，减少默认页面中的令牌与接口噪音。

## Muse 权限

- `read`：查询账目与分类
- `write`：创建账目
- `update`：修改由 Muse 创建的账目
- `delete`：删除由 Muse 创建的账目

手工账目不会被 Muse 修改或删除。

## 构建

```powershell
npm ci
npm run build
npm run publish:pages -- --target C:\path\to\repo\jianji
```

Tesseract wasm 和语言包体积较大，不重复放入源码包。首次使用前从部署目录的 `jianji/tesseract`、`jianji/tessdata` 复制到源码项目的 `public/`。发布脚本会先带入并校验这些运行资源，再清空旧 `jianji/`，避免旧 assets 堆积。