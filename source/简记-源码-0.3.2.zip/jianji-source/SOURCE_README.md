# 简记源码 0.3.2

源码包包含 React/TypeScript 页面、OCR 懒加载、PWA 构建配置、Supabase Schema、Muse Edge Function 和发布脚本。

## 本次更新

- 修复带查询串的 `review.html?capture=…&token=…` 被 Service Worker 当成主页兜底的问题。
- 补齐分享元信息、favicon、无 JavaScript 提示和 iOS PWA 元信息。
- 核对页补齐表单字段名、状态播报和结果页焦点管理。
- 改善 Android/iOS 状态栏颜色、小字号对比度、toast 命中区和 iOS 输入框聚焦缩放。
- 发布脚本改为构建前带入 OCR 资源、构建后校验，避免清理旧产物时误删 OCR。
- 预缓存去重，Tesseract wasm 和语言包继续按需缓存。

## Muse 权限

- `read`：查询账目与分类
- `write`：创建账目
- `update`：修改由 Muse 创建的账目
- `delete`：删除由 Muse 创建的账目

手工账目不会被 Muse 修改或删除。

## 构建

```powershell
npm ci
npm run build
npm run publish:pages -- --target C:\path\to\repo\jianji
```

Tesseract wasm 和语言包体积较大，不重复放入源码包。首次使用前从部署目录的 `jianji/tesseract`、`jianji/tessdata` 复制到源码项目的 `public/`。发布脚本会先带入并校验这些运行资源，再清空旧 `jianji/`，避免旧 assets 堆积。