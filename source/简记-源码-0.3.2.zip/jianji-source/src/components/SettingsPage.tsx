import { useState, type FormEvent } from 'react';
import {
  Bot,
  Check,
  ClipboardCopy,
  Cloud,
  CloudOff,
  Database,
  Download,
  Info,
  KeyRound,
  LockKeyhole,
  LogIn,
  LogOut,
  RefreshCw,
  RotateCcw,
  Share,
  Smartphone,
  Trash2,
  UserRound,
} from 'lucide-react';
import type { AppSettings, CloudPhase } from '../types';

type CloudSignUpResult = { ok: boolean; message: string };

type Props = {
  settings: AppSettings;
  onSettingsChange: (settings: AppSettings) => void;
  onExport: () => void;
  onClearSamples: () => void;
  onReset: () => void;
  installPrompt: BeforeInstallPromptEvent | null;
  onInstall: () => void;
  isStandalone: boolean;
  cloudConfigured: boolean;
  cloudPhase: CloudPhase;
  cloudEmail?: string;
  cloudError: string;
  lastSyncedAt: string;
  onCloudSignIn: (email: string, password: string) => Promise<string | null>;
  onCloudSignUp: (email: string, password: string) => Promise<CloudSignUpResult>;
  onCloudSignOut: () => Promise<void>;
  onCloudSync: () => Promise<void>;
  shortcutToken: string;
  shortcutEndpoint: string;
  shortcutApiKey: string;
  onGenerateShortcutToken: () => Promise<string>;
  onRevokeShortcutToken: () => Promise<void>;
  museToken: string;
  museEndpoint: string;
  onGenerateMuseToken: () => Promise<string>;
  onRevokeMuseToken: () => Promise<void>;
};


const syncLabels: Record<CloudPhase, string> = {
  disabled: '未配置',
  'signed-out': '未登录',
  connecting: '正在连接',
  syncing: '同步中',
  synced: '已同步',
  error: '同步失败',
};

export default function SettingsPage({
  settings,
  onSettingsChange,
  onExport,
  onClearSamples,
  onReset,
  installPrompt,
  onInstall,
  isStandalone,
  cloudConfigured,
  cloudPhase,
  cloudEmail,
  cloudError,
  lastSyncedAt,
  onCloudSignIn,
  onCloudSignUp,
  onCloudSignOut,
  onCloudSync,
  shortcutToken,
  shortcutEndpoint,
  shortcutApiKey,
  onGenerateShortcutToken,
  onRevokeShortcutToken,
  museToken,
  museEndpoint,
  onGenerateMuseToken,
  onRevokeMuseToken,
}: Props) {
  const [copied, setCopied] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [cloudBusy, setCloudBusy] = useState(false);
  const [cloudMessage, setCloudMessage] = useState('');
  const [shortcutBusy, setShortcutBusy] = useState(false);
  const [shortcutCopied, setShortcutCopied] = useState(false);
  const [museBusy, setMuseBusy] = useState(false);
  const [museCopied, setMuseCopied] = useState(false);
  const [museDeleteCopied, setMuseDeleteCopied] = useState(false);
  const autoTemplate = `${window.location.origin}${import.meta.env.BASE_URL}?capture=auto&text=编码后的文本&auto=1`;

  const signedIn = Boolean(cloudEmail);
  const lastSyncLabel = lastSyncedAt
    ? new Date(lastSyncedAt).toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai', month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })
    : '尚未同步';

  async function copy(value: string) {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  }

  async function handleSignIn(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setCloudBusy(true);
    setCloudMessage('');
    const error = await onCloudSignIn(email, password);
    if (!error) {
      setPassword('');
      setCloudMessage('');
    } else {
      setCloudMessage(error);
    }
    setCloudBusy(false);
  }

  async function handleSignUp() {
    setCloudBusy(true);
    setCloudMessage('');
    const result = await onCloudSignUp(email, password);
    setCloudMessage(result.message);
    if (result.ok) setPassword('');
    setCloudBusy(false);
  }

  async function copyShortcutConfig() {
    if (!shortcutToken) return;
    const config = JSON.stringify({ url: shortcutEndpoint, apikey: shortcutApiKey, token: shortcutToken }, null, 2);
    try {
      await navigator.clipboard.writeText(config);
      setShortcutCopied(true);
      window.setTimeout(() => setShortcutCopied(false), 1800);
    } catch {
      setShortcutCopied(false);
    }
  }

  async function handleGenerateShortcutToken() {
    setShortcutBusy(true);
    await onGenerateShortcutToken();
    setShortcutBusy(false);
  }

  async function handleRevokeShortcutToken() {
    setShortcutBusy(true);
    await onRevokeShortcutToken();
    setShortcutBusy(false);
  }

  async function copyMuseConfig() {
    if (!museToken) return;
    const config = JSON.stringify({
      method: 'POST',
      url: museEndpoint,
      headers: {
        Authorization: `Bearer ${museToken}`,
        'Content-Type': 'application/json',
      },
      body: {
        amount: 23.5,
        direction: 'expense',
        merchant: '瑞幸咖啡',
        categoryId: 'food',
        occurredAt: '2026-10-30T14:30:00+08:00',
        source: '微信',
        note: 'Muse 自动记账',
        idempotencyKey: 'muse-20261030-1430-luckin',
      },
      readExample: {
        action: 'list',
        query: { from: '2026-10-01T00:00:00+08:00', limit: 20 },
      },
      updateExample: {
        action: 'update',
        transactionId: '要修改的 Muse 账目 ID',
        fields: { amount: 25, merchant: '瑞幸咖啡', note: '已修改' },
      },
      deleteExample: {
        action: 'delete',
        transactionId: '要删除的 Muse 账目 ID',
      },
    }, null, 2);
    try {
      await navigator.clipboard.writeText(config);
      setMuseCopied(true);
      window.setTimeout(() => setMuseCopied(false), 1800);
    } catch {
      setMuseCopied(false);
    }
  }

  async function handleGenerateMuseToken() {
    setMuseBusy(true);
    await onGenerateMuseToken();
    setMuseBusy(false);
  }

  async function handleRevokeMuseToken() {
    setMuseBusy(true);
    await onRevokeMuseToken();
    setMuseBusy(false);
  }

  async function copyMuseDeleteConfig() {
    if (!museToken) return;
    const config = JSON.stringify({
      method: 'POST',
      url: museEndpoint,
      headers: {
        Authorization: `Bearer ${museToken}`,
        'Content-Type': 'application/json',
      },
      body: {
        action: 'delete',
        transactionId: '要删除的 Muse 账目 ID',
      },
      note: '也可以用 DELETE 请求，并在 body 中传 transactionId 或 idempotencyKey。',
    }, null, 2);
    try {
      await navigator.clipboard.writeText(config);
      setMuseDeleteCopied(true);
      window.setTimeout(() => setMuseDeleteCopied(false), 1800);
    } catch {
      setMuseDeleteCopied(false);
    }
  }
  async function handleSignOut() {
    setCloudBusy(true);
    await onCloudSignOut();
    setCloudMessage('');
    setCloudBusy(false);
  }

  return (
    <main className="page settings-page">
      <header className="page-top settings-top">
        <div>
          <p className="brand-line">简记 <span>SETTINGS</span></p>
          <h1 className="visually-hidden">设置</h1>
        </div>
      </header>

      <section className="settings-block cloud-block">
        <div className="settings-heading">{cloudConfigured ? <Cloud size={18} /> : <CloudOff size={18} />}<h2>云同步</h2></div>
        {!cloudConfigured ? (
          <p className="settings-copy">云同步尚未配置。部署时填写 Supabase 的 Project URL 和 Publishable Key 后即可启用。</p>
        ) : signedIn ? (
          <div className="cloud-account">
            <div className="cloud-identity">
              <div className="cloud-avatar"><UserRound size={19} /></div>
              <div>
                <strong>{cloudEmail}</strong>
                <small>Safari 与主屏幕简记共用这份云端账本</small>
              </div>
            </div>
            <div className={`sync-state is-${cloudPhase}`}>
              <span className="sync-dot" aria-hidden="true" />
              <span>{syncLabels[cloudPhase]}</span>
              <small>{lastSyncLabel}</small>
            </div>
            <p className="microcopy">登录后，账目字段会上传到你的 Supabase 项目；截图和 OCR 原图仍不会上传。</p>
            <div className="settings-actions">
              <button type="button" className="secondary-button" onClick={() => void onCloudSync()} disabled={cloudPhase === 'syncing'}>
                <RefreshCw size={16} /> {cloudPhase === 'syncing' ? '同步中' : '立即同步'}
              </button>
              <button type="button" className="secondary-button" onClick={() => void handleSignOut()} disabled={cloudBusy}>
                <LogOut size={16} /> 退出账号
              </button>
            </div>
            {cloudError || cloudMessage ? <p className="cloud-message is-error">{cloudMessage || cloudError}</p> : null}
            <div className="shortcut-token-panel">
              <div className="shortcut-token-heading"><KeyRound size={17} /><strong>无跳转快捷指令</strong></div>
              <p>快捷指令通过 POST 提交识别文字，不会打开 Safari 标签页。打开简记时自动入账或进入核对。</p>
              {shortcutToken ? (
                <>
                  <div className="shortcut-token-status"><span>令牌</span><code>••••{shortcutToken.slice(-6)}</code></div>
                  <div className="settings-actions vertical">
                    <button type="button" className="secondary-button" onClick={() => void copyShortcutConfig()}>
                      {shortcutCopied ? <Check size={16} /> : <ClipboardCopy size={16} />} {shortcutCopied ? '配置已复制' : '复制快捷指令配置'}
                    </button>
                    <button type="button" className="secondary-button" onClick={() => void handleGenerateShortcutToken()} disabled={shortcutBusy}>
                      <RefreshCw size={16} /> 重新生成令牌
                    </button>
                    <button type="button" className="secondary-button danger" onClick={() => void handleRevokeShortcutToken()} disabled={shortcutBusy}>
                      <Trash2 size={16} /> 撤销令牌
                    </button>
                  </div>
                </>
              ) : (
                <button type="button" className="secondary-button" onClick={() => void handleGenerateShortcutToken()} disabled={shortcutBusy}>
                  <KeyRound size={16} /> {shortcutBusy ? '生成中' : '生成快捷指令令牌'}
                </button>
              )}
            </div>
            <div className="shortcut-token-panel muse-token-panel">
              <div className="shortcut-token-heading"><Bot size={17} /><strong>Muse 写入接口</strong></div>
              <p>标准 Muse 安全连接只需要一个 Bearer 密钥。可读取账目和分类，并创建、修改或删除由 Muse 创建的账目。</p>
              {museToken ? (
                <>
                  <div className="shortcut-token-status"><span>写入令牌</span><code>••••{museToken.slice(-6)}</code></div>
                  <div className="settings-actions vertical">
                    <button type="button" className="secondary-button" onClick={() => void copyMuseConfig()}>
                      {museCopied ? <Check size={16} /> : <ClipboardCopy size={16} />} {museCopied ? 'Muse 配置已复制' : '复制 Muse 连接配置'}
                    </button>
                    <button type="button" className="secondary-button" onClick={() => void copyMuseDeleteConfig()}>
                      {museDeleteCopied ? <Check size={16} /> : <ClipboardCopy size={16} />} {museDeleteCopied ? '删除配置已复制' : '复制删除配置'}
                    </button>
                    <button type="button" className="secondary-button" onClick={() => void handleGenerateMuseToken()} disabled={museBusy}>
                      <RefreshCw size={16} /> 重新生成写入令牌
                    </button>
                    <button type="button" className="secondary-button danger" onClick={() => void handleRevokeMuseToken()} disabled={museBusy}>
                      <Trash2 size={16} /> 撤销写入令牌
                    </button>
                  </div>
                </>
              ) : (
                <button type="button" className="secondary-button" onClick={() => void handleGenerateMuseToken()} disabled={museBusy}>
                  <KeyRound size={16} /> {museBusy ? '生成中' : '生成 Muse 写入令牌'}
                </button>
              )}
              <div className="url-box muse-endpoint"><code>{museEndpoint}</code></div>
              <details className="muse-api-details">
                <summary>查看调用格式</summary>
                <pre>{`统一接口：\nPOST ${museEndpoint}\nAuthorization: Bearer 你的令牌\nContent-Type: application/json\n\n查询：\n{"action":"list","query":{"limit":20}}\n\n新增：\n{"amount":23.5,"merchant":"瑞幸咖啡","categoryId":"food","occurredAt":"2026-10-30T14:30:00+08:00"}\n\n修改 Muse 账目：\n{"action":"update","transactionId":"交易 ID","fields":{"amount":25,"note":"已修改"}}\n\n删除 Muse 账目：\n{"action":"delete","transactionId":"交易 ID"}`}</pre>
              </details>
            </div>
          </div>
        ) : (
          <>
            <p className="settings-copy">登录同一个账号后，Safari、主屏幕 PWA 和其他设备会自动合并账目。未登录时仍可完全离线使用。</p>
            <form className="cloud-auth" onSubmit={handleSignIn}>
              <label>
                <span>邮箱</span>
                <input
                  type="email"
                  autoComplete="email"
                  inputMode="email"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  placeholder="you@example.com"
                  required
                />
              </label>
              <label>
                <span>密码</span>
                <input
                  type="password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  placeholder="至少 6 位"
                  minLength={6}
                  required
                />
              </label>
              <div className="settings-actions">
                <button type="submit" className="secondary-button" disabled={cloudBusy}>
                  <LogIn size={16} /> {cloudBusy ? '处理中' : '登录并同步'}
                </button>
                <button type="button" className="secondary-button" onClick={() => void handleSignUp()} disabled={cloudBusy || !email || password.length < 6}>
                  <UserRound size={16} /> 创建账号
                </button>
              </div>
            </form>
            {cloudError || cloudMessage ? <p className={`cloud-message ${cloudError ? 'is-error' : ''}`}>{cloudMessage || cloudError}</p> : null}
          </>
        )}
      </section>

      <section className="settings-block shortcut-primary">
        <div className="settings-heading"><Smartphone size={18} /><h2>快捷指令入口</h2></div>
        <p className="settings-copy">快捷指令已经接入简记。截图只在快捷指令中做文字识别，简记不会保存原图。</p>
        <div className="url-box"><code>{autoTemplate}</code></div>
        <div className="settings-actions">
          <button type="button" className="secondary-button" onClick={() => copy(autoTemplate)}>
            {copied ? <Check size={16} /> : <ClipboardCopy size={16} />} {copied ? '地址已复制' : '复制快捷指令地址'}
          </button>
        </div>
      </section>

      <section className="settings-block">
        <div className="settings-heading"><Share size={18} /><h2>安装到主屏幕</h2></div>
        {isStandalone ? (
          <div className="installed-state"><Check size={18} /> 已作为独立应用运行</div>
        ) : (
          <>
            <p className="settings-copy">用 Safari 打开本站，点底部“分享”，再选“添加到主屏幕”。</p>
            {installPrompt ? <button type="button" className="primary-stamp compact" onClick={onInstall}>安装简记</button> : null}
          </>
        )}
      </section>

      <section className="settings-block">
        <div className="settings-heading"><LockKeyhole size={18} /><h2>隐私与识别</h2></div>
        <label className="setting-toggle">
          <span><strong>识别后尝试覆盖剪贴板</strong><small>仅备用剪贴板模式使用；iOS 可能拒绝无手势写入，失败时会提示</small></span>
          <input type="checkbox" checked={settings.clearClipboard} onChange={(event) => onSettingsChange({ ...settings, clearClipboard: event.target.checked })} />
          <i aria-hidden="true" />
        </label>
        <label className="setting-toggle">
          <span><strong>记住分类习惯</strong><small>你确认商户分类后，把商户名称加入对应分类关键词</small></span>
          <input type="checkbox" checked={settings.learnedRules} onChange={(event) => onSettingsChange({ ...settings, learnedRules: event.target.checked })} />
          <i aria-hidden="true" />
        </label>
        <div className="privacy-proof">
          <div><LockKeyhole size={18} /></div>
          <p><strong>原图不进入简记。</strong><br />快捷指令完成 Apple 端文字识别后，只把文本传给 PWA。应用不读取相册或相机，不请求截图文件，不把图片写入 IndexedDB、localStorage 或服务器。</p>
        </div>
      </section>


      <section className="settings-block">
        <div className="settings-heading"><Database size={18} /><h2>本地数据</h2></div>
        <div className="settings-actions vertical">
          <button type="button" className="secondary-button" onClick={onExport}><Download size={16} /> 导出 CSV</button>
          <button type="button" className="secondary-button" onClick={onClearSamples}><Trash2 size={16} /> 清除示例账目</button>
          <button type="button" className="secondary-button danger" onClick={onReset}><RotateCcw size={16} /> 清空全部本地数据</button>
        </div>
      </section>

      <section className="settings-block about-block">
        <div className="settings-heading"><Info size={18} /><h2>关于</h2></div>
        <p className="settings-copy">简记 0.3.2 · Muse 读取、创建、修改与删除权限版。本地优先、可选云同步的快捷指令记账 PWA。</p>
      </section>
    </main>
  );
}
