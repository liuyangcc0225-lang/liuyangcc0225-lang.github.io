import { useMemo, useState } from 'react';
import { AlertTriangle, CalendarDays, Check, PencilLine, Plus, SlidersHorizontal, Tag, X } from 'lucide-react';
import type { Category, Transaction } from '../types';
import { CATEGORY_COLORS, categoryById } from '../categories';
import { beijingDateKey, formatDayLabel, formatMoney, getBeijingDateParts } from '../parser';
import { CategoryMark } from './LedgerRow';
import { CATEGORY_ICON_OPTIONS } from './CategoryGlyph';

type Props = {
  categories: Category[];
  transactions: Transaction[];
  onSaveCategory: (category: Category) => void;
};

type EditorState = { id?: string; name: string; icon: string; color: string; keywords: string; budget: string };

const emptyEditor: EditorState = { name: '', icon: 'tag', color: CATEGORY_COLORS[0], keywords: '', budget: '' };

export default function CategoriesPage({ categories, transactions, onSaveCategory }: Props) {
  const [editor, setEditor] = useState<EditorState | null>(null);
  const [showManage, setShowManage] = useState(false);
  const now = getBeijingDateParts();
  const todayKey = beijingDateKey(new Date());

  const days = useMemo(() => {
    const grouped = new Map<string, Transaction[]>();
    for (const transaction of transactions) {
      const date = getBeijingDateParts(transaction.occurredAt);
      if (date.year !== now.year || date.month !== now.month || transaction.direction !== 'expense') continue;
      const key = beijingDateKey(transaction.occurredAt);
      const list = grouped.get(key) ?? [];
      list.push(transaction);
      grouped.set(key, list);
    }

    return Array.from(grouped.entries())
      .map(([key, rows]) => {
        const byCategory = new Map<string, { category: Category; total: number; count: number }>();
        for (const transaction of rows) {
          const category = categoryById(categories, transaction.categoryId);
          const current = byCategory.get(category.id) ?? { category, total: 0, count: 0 };
          current.total += transaction.amount;
          current.count += 1;
          byCategory.set(category.id, current);
        }
        return {
          key,
          occurredAt: rows[0].occurredAt,
          total: rows.reduce((sum, transaction) => sum + transaction.amount, 0),
          categories: Array.from(byCategory.values()).sort((a, b) => b.total - a.total),
        };
      })
      .sort((a, b) => b.key.localeCompare(a.key));
  }, [categories, now.month, now.year, transactions]);

  const monthTotal = days.reduce((sum, day) => sum + day.total, 0);
  const monthCount = days.reduce((sum, day) => sum + day.categories.reduce((count, item) => count + item.count, 0), 0);
  const budgetItems = categories
    .filter((category) => (category.monthlyBudget ?? 0) > 0)
    .map((category) => {
      const spent = days.reduce((sum, day) => {
        const item = day.categories.find((entry) => entry.category.id === category.id);
        return sum + (item?.total ?? 0);
      }, 0);
      const budget = category.monthlyBudget ?? 0;
      return { category, spent, budget, percent: budget > 0 ? (spent / budget) * 100 : 0 };
    })
    .sort((a, b) => b.percent - a.percent);

  function startEdit(category: Category) {
    setEditor({ id: category.id, name: category.name, icon: category.icon ?? 'tag', color: category.color, keywords: category.keywords.join('、'), budget: category.monthlyBudget ? String(category.monthlyBudget) : '' });
  }

  function save() {
    if (!editor || !editor.name.trim()) return;
    const name = editor.name.trim();
    const existing = categories.find((category) => category.id === editor.id);
    const id = editor.id ?? `custom-${Date.now()}`;
    const keywords = editor.keywords.split(/[、,，\n]/).map((item) => item.trim()).filter(Boolean);
    const budget = Number(editor.budget);
    onSaveCategory({
      id,
      name,
      short: name.slice(0, 1),
      icon: editor.icon,
      color: editor.color,
      keywords,
      monthlyBudget: Number.isFinite(budget) && budget > 0 ? Math.round(budget * 100) / 100 : undefined,
      builtin: existing?.builtin ?? false,
    });
    setEditor(null);
  }

  return (
    <main className="page categories-page">
      <header className="page-top">
        <div>
          <p className="brand-line">简记 <span>DAILY</span></p>
          <h1>每天，花在哪里。</h1>
        </div>
        <div className="daily-category-actions">
          <button type="button" className="icon-button" aria-label="管理分类" aria-pressed={showManage} onClick={() => setShowManage((value) => !value)}><SlidersHorizontal size={18} /></button>
          <button type="button" className="icon-button" aria-label="新增分类" onClick={() => setEditor(emptyEditor)}><Plus size={20} /></button>
        </div>
      </header>

      <section className="daily-category-summary" aria-label="本月支出概览">
        <div><span>本月支出</span><strong>¥{formatMoney(monthTotal)}</strong></div>
        <div><span>记账天数</span><strong>{days.length} 天</strong></div>
        <div><span>支出笔数</span><strong>{monthCount} 笔</strong></div>
      </section>

      {budgetItems.length ? (
        <section className="category-budget-panel" aria-label="分类预算">
          <div className="category-budget-heading"><span><AlertTriangle size={16} /><strong>本月分类预算</strong></span><small>{budgetItems.filter((item) => item.percent >= 100).length} 个超支</small></div>
          <div className="category-budget-list">
            {budgetItems.map(({ category, spent, budget, percent }) => (
              <div className={`category-budget-row ${percent >= 100 ? 'is-over' : percent >= 80 ? 'is-near' : ''}`} key={category.id}>
                <CategoryMark category={category} small />
                <div>
                  <span><strong>{category.name}</strong><small>{percent >= 100 ? '已超预算' : percent >= 80 ? '接近预算' : '预算正常'}</small></span>
                  <div className="budget-progress"><i style={{ width: `${Math.min(100, percent)}%` }} /></div>
                </div>
                <b>{Math.round(percent)}%</b>
                <em>¥{formatMoney(spent)} / ¥{formatMoney(budget)}</em>
              </div>
            ))}
          </div>
        </section>
      ) : null}

      {showManage ? (
        <section className="category-manage-panel" aria-label="管理分类">
          <div className="category-manage-heading"><span>管理分类</span><small>点击分类即可修改名称、图标和关键词</small></div>
          <div className="category-manage-list">
            {categories.map((category) => (
              <button type="button" key={category.id} onClick={() => startEdit(category)}>
                <CategoryMark category={category} small />
                <span>{category.name}</span>
                <PencilLine size={13} />
              </button>
            ))}
          </div>
        </section>
      ) : null}

      {editor ? (
        <section className="category-editor" aria-label={editor.id ? '编辑分类' : '新增分类'}>
          <div className="editor-heading">
            <div><Tag size={17} /><strong>{editor.id ? '编辑分类' : '新增分类'}</strong></div>
            <button type="button" className="icon-button" onClick={() => setEditor(null)} aria-label="关闭编辑"><X size={18} /></button>
          </div>
          <label><span className="field-label">名称</span><input value={editor.name} onChange={(event) => setEditor({ ...editor, name: event.target.value })} placeholder="例如：宠物" /></label>
          <div className="category-icon-field">
            <span className="field-label">选择图标</span>
            <div className="category-icon-picker" role="radiogroup" aria-label="分类图标">
              {CATEGORY_ICON_OPTIONS.map(({ id, label, Icon }) => (
                <button
                  key={id}
                  type="button"
                  role="radio"
                  aria-checked={editor.icon === id}
                  aria-label={label}
                  title={label}
                  className={editor.icon === id ? 'is-selected' : ''}
                  onClick={() => setEditor({ ...editor, icon: id })}
                >
                  <Icon size={19} strokeWidth={1.9} aria-hidden="true" />
                </button>
              ))}
            </div>
          </div>
          <label><span className="field-label">关键词（用顿号或逗号分隔）</span><input value={editor.keywords} onChange={(event) => setEditor({ ...editor, keywords: event.target.value })} placeholder="猫粮、宠物医院、洗澡" /></label>
          <label><span className="field-label">每月预算（可选）</span><input type="number" inputMode="decimal" min="0" step="0.01" value={editor.budget} onChange={(event) => setEditor({ ...editor, budget: event.target.value })} placeholder="例如：1500" /></label>
          <div className="color-row" role="radiogroup" aria-label="分类颜色">
            {CATEGORY_COLORS.map((color) => (
              <button key={color} type="button" role="radio" aria-checked={editor.color === color} className={editor.color === color ? 'is-selected' : ''} style={{ background: color }} onClick={() => setEditor({ ...editor, color })} aria-label={`选择颜色 ${color}`} />
            ))}
          </div>
          <button type="button" className="primary-stamp compact" onClick={save} disabled={!editor.name.trim()}><Check size={16} /> 保存分类</button>
        </section>
      ) : null}

      {days.length ? (
        <div className="daily-category-list">
          {days.map((day) => (
            <section className="daily-category-day" key={day.key}>
              <header className="daily-category-day-head">
                <div>
                  <span className="daily-category-day-label">{day.key === todayKey ? '今天' : formatDayLabel(day.occurredAt)}</span>
                  <small>{day.key === todayKey ? formatDayLabel(day.occurredAt) : `${day.categories.reduce((count, item) => count + item.count, 0)} 笔支出`}</small>
                </div>
                <div><span>当日支出</span><strong>¥{formatMoney(day.total)}</strong></div>
              </header>
              <div className="daily-category-rows">
                {day.categories.map(({ category, total, count }) => {
                  const share = day.total ? (total / day.total) * 100 : 0;
                  return (
                    <div className="daily-category-row" key={category.id}>
                      <CategoryMark category={category} small />
                      <div className="daily-category-row-main">
                        <div className="daily-category-row-line">
                          <strong>{category.name}</strong>
                          <span>{count} 笔</span>
                          <b>¥{formatMoney(total)}</b>
                        </div>
                        <div className="daily-category-bar" aria-hidden="true"><i style={{ width: `${share}%`, background: category.color }} /></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
          ))}
        </div>
      ) : (
        <div className="daily-category-empty">
          <CalendarDays size={24} />
          <strong>这个月还没有支出。</strong>
          <span>快捷指令记下第一笔后，这里会按每天和分类自动整理。</span>
        </div>
      )}
    </main>
  );
}
