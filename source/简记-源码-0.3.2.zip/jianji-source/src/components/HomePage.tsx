import { useMemo } from 'react';
import { AlertTriangle, ArrowRight, ChevronRight, Info, ScanLine } from 'lucide-react';
import type { Category, Transaction } from '../types';
import { categoryById } from '../categories';
import { beijingDateKey, formatFullDate, formatMoney, getBeijingDateParts } from '../parser';
import LedgerRow, { CategoryMark } from './LedgerRow';

type Props = {
  transactions: Transaction[];
  categories: Category[];

  onOpenLedger: () => void;
  onOpenTransaction: (transaction: Transaction) => void;
  onOpenSettings: () => void;
};

const GRAY_SCALE = ['#111111', '#4f4f4f', '#7b7b7b', '#a8a8a8', '#d0d0d0'];
const WEEKDAYS = ['一', '二', '三', '四', '五', '六', '日'];

function monthTransactions(transactions: Transaction[]) {
  const now = getBeijingDateParts();
  return transactions.filter((transaction) => {
    const date = getBeijingDateParts(transaction.occurredAt);
    return date.year === now.year && date.month === now.month;
  });
}

function DailyBars({ transactions }: { transactions: Transaction[] }) {
  const days = useMemo(() => {
    const now = getBeijingDateParts();
    return Array.from({ length: 7 }, (_, index) => {
      const date = new Date(Date.UTC(now.year, now.month - 1, now.day));
      date.setUTCDate(date.getUTCDate() - (6 - index));
      const key = `${date.getUTCFullYear()}-${date.getUTCMonth() + 1}-${date.getUTCDate()}`;
      const total = transactions
        .filter((transaction) => beijingDateKey(transaction.occurredAt) === key && transaction.direction === 'expense')
        .reduce((sum, transaction) => sum + transaction.amount, 0);
      return { label: String(date.getUTCDate()).padStart(2, '0'), total };
    });
  }, [transactions]);
  const max = Math.max(...days.map((day) => day.total), 1);
  return (
    <div className="daily-bars" aria-label="最近七天支出柱状图">
      {days.map((day) => (
        <div className="daily-bar-column" key={day.label}>
          <span className="daily-bar-value">{day.total ? Math.round(day.total) : ''}</span>
          <div className="daily-bar-track"><i style={{ height: `${day.total ? Math.max(8, (day.total / max) * 100) : 4}%` }} /></div>
          <span className="daily-bar-label">{day.label}</span>
        </div>
      ))}
    </div>
  );
}

function CalendarHeatmap({ transactions }: { transactions: Transaction[] }) {
  const now = getBeijingDateParts();
  const year = now.year;
  const month = now.month;
  const firstWeekday = (new Date(Date.UTC(year, month - 1, 1)).getUTCDay() + 6) % 7;
  const days = new Date(Date.UTC(year, month, 0)).getUTCDate();
  const totals = new Map<number, number>();
  for (const transaction of transactions) {
    const date = getBeijingDateParts(transaction.occurredAt);
    if (date.year === year && date.month === month && transaction.direction === 'expense') {
      totals.set(date.day, (totals.get(date.day) ?? 0) + transaction.amount);
    }
  }
  const max = Math.max(...Array.from(totals.values()), 1);
  return (
    <div className="calendar-heatmap">
      <div className="calendar-weekdays">{WEEKDAYS.map((day) => <span key={day}>{day}</span>)}</div>
      <div className="calendar-grid">
        {Array.from({ length: firstWeekday }).map((_, index) => <span className="calendar-empty" key={`empty-${index}`} />)}
        {Array.from({ length: days }, (_, index) => {
          const day = index + 1;
          const total = totals.get(day) ?? 0;
          const intensity = total ? 0.22 + (total / max) * 0.72 : 0;
          return (
            <div
              className={`calendar-cell ${total ? 'has-spend' : ''} ${intensity > 0.56 ? 'is-dark' : ''}`}
              key={day}
              style={total ? ({ '--heat': intensity } as React.CSSProperties) : undefined}
            >
              <strong>{day}</strong>
              {total ? <small>{Math.round(total)}</small> : <small className="muted">—</small>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function CategoryOverview({ transactions, categories }: { transactions: Transaction[]; categories: Category[] }) {
  const totals = categories.map((category) => ({
    category,
    total: transactions.filter((item) => item.direction === 'expense' && item.categoryId === category.id).reduce((sum, item) => sum + item.amount, 0),
  })).filter((item) => item.total > 0).sort((a, b) => b.total - a.total);
  const total = totals.reduce((sum, item) => sum + item.total, 0);
  const scale = total || 1;
  const top = totals.filter((item) => item.category.id !== 'other').slice(0, 4);
  const topIds = new Set(top.map((item) => item.category.id));
  const rest = totals.filter((item) => !topIds.has(item.category.id));
  const groupedTotal = rest.reduce((sum, item) => sum + item.total, 0);
  const visible = totals.length > 5 && rest.length ? [
    ...top,
    {
      category: { id: 'grouped-rest', name: '其他分类', short: '其', color: '#bdbdbd', keywords: [] },
      total: groupedTotal,
      containedCount: rest.length,
    },
  ] : totals;
  let cursor = 0;
  const gradient = visible.map((item, index) => {
    const start = cursor;
    const end = cursor + (item.total / scale) * 100;
    cursor = end;
    return `${GRAY_SCALE[index]} ${start}% ${end}%`;
  }).join(', ');
  return (
    <section className="overview-card category-overview-card">
      <div className="card-heading"><h2>分类统计</h2><span>{totals.length} 类</span></div>
      <div className="category-overview-body">
        <div className="donut-wrap">
          <div className="donut-chart" style={{ background: `conic-gradient(${gradient || '#e6e6e6 0% 100%'})` }}>
            <div className="donut-center"><strong>¥{formatMoney(total)}</strong><span>本月支出</span></div>
          </div>
        </div>
        <div className="category-ranking">
          {visible.map((item, index) => (
            <div className="category-rank-row" key={item.category.id}>
              <span className="rank-dot" style={{ background: GRAY_SCALE[index] }} />
              <span className="rank-name">
                {item.category.name}
                {'containedCount' in item ? <small>{item.containedCount} 项合并</small> : null}
              </span>
              <span className="rank-percent">{((item.total / total) * 100).toFixed(0)}%</span>
              <strong>¥{formatMoney(item.total)}</strong>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function BudgetReminder({ transactions, categories }: { transactions: Transaction[]; categories: Category[] }) {
  const alerts = categories
    .filter((category) => (category.monthlyBudget ?? 0) > 0)
    .map((category) => {
      const spent = transactions
        .filter((transaction) => transaction.direction === 'expense' && transaction.categoryId === category.id)
        .reduce((sum, transaction) => sum + transaction.amount, 0);
      const budget = category.monthlyBudget ?? 0;
      return { category, spent, budget, percent: budget > 0 ? (spent / budget) * 100 : 0 };
    })
    .filter((item) => item.percent >= 80)
    .sort((a, b) => b.percent - a.percent);

  if (!alerts.length) return null;
  return (
    <section className="budget-reminder-card" aria-label="分类预算提醒">
      <div className="budget-reminder-heading"><AlertTriangle size={17} /><strong>预算提醒</strong><span>{alerts.length} 个分类</span></div>
      <div className="budget-reminder-list">
        {alerts.slice(0, 4).map(({ category, spent, budget, percent }) => (
          <div className={`budget-reminder-row ${percent >= 100 ? 'is-over' : 'is-near'}`} key={category.id}>
            <CategoryMark category={category} small />
            <div>
              <span><strong>{category.name}</strong><small>{percent >= 100 ? '已超预算' : '接近预算'}</small></span>
              <div className="budget-progress"><i style={{ width: `${Math.min(100, percent)}%` }} /></div>
            </div>
            <b>{Math.round(percent)}%</b>
            <em>¥{formatMoney(spent)} / ¥{formatMoney(budget)}</em>
          </div>
        ))}
      </div>
    </section>
  );
}

export default function HomePage({ transactions, categories, onOpenLedger, onOpenTransaction, onOpenSettings }: Props) {
  const now = getBeijingDateParts();
  const month = monthTransactions(transactions);
  const expense = month.filter((item) => item.direction === 'expense').reduce((sum, item) => sum + item.amount, 0);
  const income = month.filter((item) => item.direction === 'income').reduce((sum, item) => sum + item.amount, 0);
  const recent = transactions.slice(0, 4);
  const sampleCount = transactions.filter((item) => item.isSample).length;
  const dateLabel = formatFullDate(new Date());

  return (
    <main className="page home-page monochrome-home">
      <header className="home-header">
        <div className="app-logo" aria-hidden="true">简</div>
        <div className="home-header-copy"><h1>简记</h1><span>极简 · 快捷 · 自动</span></div>
        <span className="home-date">{dateLabel}</span>
      </header>

      {sampleCount ? (
        <button type="button" className="sample-banner" onClick={onOpenSettings}>
          <Info size={15} />
          <span>当前包含 {sampleCount} 笔示例账目，仅用于预览；去设置可清除</span>
          <ChevronRight size={15} />
        </button>
      ) : null}

      <section className="overview-card balance-card">
        <div className="card-heading"><h2>本月结余</h2><button type="button" className="card-link" onClick={onOpenLedger}>全部 <ArrowRight size={15} /></button></div>
        <div className="balance-number">{income >= expense ? '+' : '−'}¥{formatMoney(Math.abs(income - expense))}</div>
        <div className="balance-meta">
          <span>支出 <strong>¥{formatMoney(expense)}</strong></span>
          <span>收入 <strong>¥{formatMoney(income)}</strong></span>
          <span>{month.length} 笔</span>
        </div>
        <DailyBars transactions={transactions} />
      </section>

      <div className="home-actions">
        <button type="button" className="shortcut-card" onClick={onOpenSettings}>
          <span className="shortcut-icon"><ScanLine size={22} /></span>
          <span><strong>快捷指令自动记账</strong><small>截屏后直接识别，无需手动上传</small></span>
          <ChevronRight size={18} />
        </button>

      </div>

      <CategoryOverview transactions={month} categories={categories} />

      <BudgetReminder transactions={month} categories={categories} />

      <section className="overview-card calendar-card">
        <div className="card-heading"><h2>{now.month} 月账页</h2><span>每日支出</span></div>
        <CalendarHeatmap transactions={transactions} />
      </section>

      <section className="overview-card recent-card">
        <div className="card-heading"><h2>最近记录</h2><button type="button" className="card-link" onClick={onOpenLedger}>查看全部 <ArrowRight size={14} /></button></div>
        <div className="monochrome-ledger-list">
          {recent.length ? recent.map((transaction) => (
            <LedgerRow key={transaction.id} transaction={transaction} categories={categories} onClick={onOpenTransaction} showDate />
          )) : <p className="empty-inline">还没有记录，先运行一次快捷指令吧。</p>}
        </div>
      </section>
    </main>
  );
}
