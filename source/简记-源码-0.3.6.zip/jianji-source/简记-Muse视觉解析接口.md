# 简记 × Muse 临时视觉解析接口

`muse-vision` 接收一张支付截图，调用已配置的视觉模型提取账目草稿，然后把结构化字段返回给快捷指令或 Muse。

它只负责“看图并解析”，不会自动记账。返回的 `writePayload` 可以继续提交给 `muse-write`。

## 隐私边界

- 图片只在一次 HTTP 请求内读取并转发给视觉供应商。
- 不写相册、IndexedDB、Supabase Storage 或数据库。
- 不记录图片正文、Base64 或视觉供应商原始响应。
- 图片仍会离开手机并发给视觉供应商；供应商是否留存图片取决于其自身政策。
- 请求必须携带现有的 `muse_...` Bearer 令牌，并要求令牌具有 `write` scope。

## 接口

```text
POST https://boqulmopdqwadqwkbgzm.supabase.co/functions/v1/muse-vision
Authorization: Bearer muse_你的专用写入令牌
Content-Type: multipart/form-data
```

### multipart 参数

| 字段 | 必填 | 说明 |
| --- | --- | --- |
| `image` | 是 | PNG、JPEG、WebP 或 HEIC，最大 8 MB |
| `locale` | 否 | 默认 `zh-CN` |
| `categories` | 否 | 分类 JSON 数组，例如 `[{"id":"food","name":"餐饮"}]` |

也支持 JSON Base64：

```json
{
  "imageBase64": "iVBORw0KGgo...",
  "mimeType": "image/png",
  "locale": "zh-CN",
  "categories": [
    { "id": "food", "name": "餐饮" },
    { "id": "shopping", "name": "购物" }
  ]
}
```

### curl 示例

```bash
curl -X POST "https://boqulmopdqwadqwkbgzm.supabase.co/functions/v1/muse-vision" \
  -H "Authorization: Bearer $MUSE_TOKEN" \
  -F "image=@payment.png;type=image/png" \
  -F "locale=zh-CN"
```

## 返回结果

```json
{
  "ok": true,
  "needsReview": false,
  "transaction": {
    "amount": 23.5,
    "direction": "expense",
    "merchant": "瑞幸咖啡",
    "categoryId": "food",
    "occurredAt": "2026-10-30T14:30:00+08:00",
    "source": "微信",
    "note": ""
  },
  "writePayload": {
    "amount": 23.5,
    "direction": "expense",
    "merchant": "瑞幸咖啡",
    "categoryId": "food",
    "occurredAt": "2026-10-30T14:30:00+08:00",
    "source": "微信",
    "note": "",
    "idempotencyKey": "vision-0123456789abcdef0123456789abcdef"
  },
  "confidence": 0.94,
  "rawText": "瑞幸咖啡 实付 23.50",
  "warnings": [],
  "meta": {
    "imageType": "image/png",
    "imageBytes": 182340,
    "processedAt": "2026-10-30T14:32:11+08:00",
    "imageStored": false
  }
}
```

- `needsReview=true`：金额缺失、置信度低于 0.72，或模型给出警告。
- `writePayload=null`：没有可靠金额，不应自动写入。
- `writePayload.idempotencyKey` 根据图片 SHA-256 生成；同一张图片重试时不会重复入账。

## 配置视觉供应商

接口采用 OpenAI-compatible Chat Completions 图片消息格式。先在 Supabase Edge Function Secrets 中配置：

```text
MUSE_VISION_ENDPOINT=https://你的视觉服务/v1/chat/completions
MUSE_VISION_API_KEY=你的供应商密钥
MUSE_VISION_MODEL=支持图片输入的模型名
```

可选：

```text
MUSE_VISION_AUTH_HEADER=Authorization
MUSE_VISION_AUTH_SCHEME=Bearer
```

未配置供应商时，接口返回 `503 vision provider is not configured`。供应商密钥只保存在 Supabase Secrets，不进入网页或快捷指令。

## iPhone 快捷指令

推荐流程：

1. `截屏`：输出保留在快捷指令变量中，不保存到相册。
2. `获取 URL 内容`：
   - URL：`https://boqulmopdqwadqwkbgzm.supabase.co/functions/v1/muse-vision`
   - 方法：`POST`
   - 请求头：`Authorization: Bearer muse_...`
   - 请求体：`表单`
   - 添加 `image`，类型选 `文件`，值选择上一步的截图。
   - 可选添加 `locale=zh-CN`。
3. 获取返回 JSON 中的 `needsReview`、`transaction` 和 `writePayload`。
4. 如果金额和分类正确，可继续向 `muse-write` 提交 `writePayload`；否则打开简记核对。

不要把图片先保存到相册。快捷指令可以直接把“截屏”动作的输出作为文件字段发送。

## 重要限制

- 自动截屏本身仍需要快捷指令、轻点背面、操作按钮或语音触发；iOS 不允许网页监听支付完成并后台截屏。
- Muse 不能后台直接读取系统剪贴板。必须由 Muse 自己提供快捷指令动作或粘贴入口，或者由你手动点一次粘贴。
- 视觉解析接口需要 Muse 或其他客户端能发起 multipart HTTP 请求；普通聊天窗口若没有网络工具，无法直接上传图片。