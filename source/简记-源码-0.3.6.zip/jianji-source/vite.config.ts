import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig(({ mode }) => {
  const base = mode === 'github' ? '/jianji/' : '/';

  return {
    base,
    build: {
      chunkSizeWarningLimit: 650,
      rollupOptions: {
        input: {
          main: 'index.html',
          review: 'review.html',
        },
      },
    },
    plugins: [
      react(),
      VitePWA({
        registerType: 'autoUpdate',
        manifest: {
          name: '简记',
          short_name: '简记',
          description: '截屏识别、确认后入账的本地隐私记账 PWA',
          lang: 'zh-CN',
          id: base,
          start_url: `${base}?source=pwa`,
          scope: base,
          display: 'standalone',
          orientation: 'portrait',
          background_color: '#ededed',
          theme_color: '#ededed',
          categories: ['finance', 'productivity'],
          icons: [
            { src: `${base}icons/pwa-192x192.png`, sizes: '192x192', type: 'image/png' },
            { src: `${base}icons/pwa-512x512.png`, sizes: '512x512', type: 'image/png', purpose: 'any' },
            { src: `${base}icons/pwa-512x512.png`, sizes: '512x512', type: 'image/png', purpose: 'maskable' },
          ],
        },
        workbox: {
          globPatterns: ['**/*.{js,css,html,svg,png,woff2}'],
          globIgnores: ['**/tesseract/**', '**/tessdata/**'],
          maximumFileSizeToCacheInBytes: 6 * 1024 * 1024,
          navigateFallback: `${base}index.html`,
          navigateFallbackDenylist: [/\/review\.html/],
          cleanupOutdatedCaches: true,
          runtimeCaching: [{
            urlPattern: /\/(?:tesseract|tessdata)\//,
            handler: 'CacheFirst',
            options: {
              cacheName: 'jianji-ocr-runtime-v1',
              cacheableResponse: { statuses: [0, 200] },
              expiration: { maxEntries: 20, maxAgeSeconds: 60 * 60 * 24 * 30 },
            },
          }],
        },
        devOptions: { enabled: false },
      }),
    ],
  };
});
