# 简记 × OCR 文本自动入账

`muse-ocr` 接收 iPhone 快捷指令本地 OCR 出来的文字，不接收图片。服务端解析金额、商户、分类、时间和支付方式；高置信度直接写入简记，低置信度或还款类截图返回核对链接。

这条链路不需要第三方视觉 API。

## 接口

```text
POST https://boqulmopdqwadqwkbgzm.supabase.co/functions/v1/muse-ocr
Authorization: Bearer muse_你的专用写入令牌
Content-Type: application/json
```

请求体：

```json
{
  "text": "微信支付\n商户全称：瑞幸咖啡\n支付金额：¥23.50\n支付方式：微信\n2026年10月30日 14:30\n支付成功",
  "capturedAt": "2026-10-30T14:32:11+08:00",
  "sourceHint": "微信",
  "locale": "zh-CN"
}
```

- `text`：必填，Apple 端 OCR 结果，最多 12000 字。
- `capturedAt`：可选，截图/触发时间。缺失时使用服务器北京时间。
- `sourceHint`：可选，支付方式提示。
- `locale`：可选，默认中文。
- 分类规则从当前用户的云端账本读取；尚未同步过分类时使用默认分类。

## 解析规则

- 优先识别 `实付、实际支付、最终支付、付款金额、支付金额`。
- 其次识别 `交易金额、订单金额、合计、总计、消费金额`。
- 排除 `余额、可用、额度、优惠、原价、已省、积分、红包、立减、折扣`，避免把余额或优惠前价格当实付。
- 出现多个同等候选金额时强制进入核对。
- 识别商户标注、支付方式、交易时间和分类关键词。
- 还款、已还清、信用卡账单、账单分期、花呗/白条/借呗还款等关键词强制进入核对，禁止自动写入。
- `idempotencyKey` 根据归一化 OCR 文本生成；同一截图重复触发不会重复入账。

## 返回

自动写入：

```json
{
  "ok": true,
  "written": true,
  "duplicate": false,
  "requiresReview": false,
  "reviewReasons": [],
  "confidence": 0.95,
  "transaction": {
    "amount": 23.5,
    "direction": "expense",
    "merchant": "瑞幸咖啡",
    "categoryId": "food",
    "occurredAt": "2026-10-30T14:30:00+08:00",
    "source": "微信",
    "note": "",
    "idempotencyKey": "ocr-..."
  },
  "writePayload": {
    "amount": 23.5,
    "direction": "expense",
    "merchant": "瑞幸咖啡",
    "categoryId": "food",
    "occurredAt": "2026-10-30T14:30:00+08:00",
    "source": "微信",
    "note": "",
    "idempotencyKey": "ocr-..."
  },
  "reviewUrl": null
}
```

需要核对：

```json
{
  "ok": true,
  "written": false,
  "duplicate": false,
  "requiresReview": true,
  "reviewReasons": ["截图中有多个候选金额", "疑似还款类截图，禁止自动入账"],
  "confidence": 0.58,
  "transaction": {},
  "writePayload": {},
  "reviewUrl": "https://liuyangcc0225-lang.github.io/jianji/review.html?capture=...&token=..."
}
```

## iPhone 快捷指令配置

1. `截屏`。
2. `从图像中提取文本`，输入选择上一步截图。
3. `获取 URL 内容`：
   - URL：`https://boqulmopdqwadqwkbgzm.supabase.co/functions/v1/muse-ocr`
   - 方法：`POST`
   - 请求头：
     - `Authorization: Bearer muse_...`
     - `Content-Type: application/json`
   - 请求体：`JSON`
     - `text`：选择“从图像中提取的文本”
     - `capturedAt`：选择“当前日期”，最好先格式化为 ISO 8601；也可留空
     - `sourceHint`：可留空
4. `获取词典值`：从返回 JSON 读取 `written`、`requiresReview`、`duplicate`、`reviewUrl`。
5. `如果` 开始：
   - `written` 为真且 `duplicate` 为假：显示通知“简记已自动记账”。
   - `duplicate` 为真：显示通知“这笔已经记过”。
   - `requiresReview` 为真：显示“需要核对”提示，并打开 `reviewUrl`。

## 错误码

- `401`：令牌缺失、撤销或不匹配。
- `400`：JSON 或 OCR 文本无效。
- `413`：文本超过 32 KB 限制。
- `500`：服务端配置或数据库错误。

## 重要限制

- 图片和截图原文件始终留在 iPhone 本地；上传的只有 OCR 文字。
- iOS 仍不允许网页监听支付通知并后台截屏。触发方式可选手动、轻点背面、操作按钮、快捷指令小组件或离开支付 App 的自动化。
- 第一版不自动确认低置信度结果；必须由用户打开核对页确认。