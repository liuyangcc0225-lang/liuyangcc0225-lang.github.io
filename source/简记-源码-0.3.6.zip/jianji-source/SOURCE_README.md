# 简记源码 0.3.6

源码包包含 React/TypeScript 页面、OCR 懒加载、PWA 配置、Supabase Schema、Muse 写入、视觉解析和 OCR 文本自动入账 Edge Functions。

## 本次更新

- 新增 `muse-ocr`：接收 Apple 本地 OCR 文本，不接收图片。
- 优先识别实付金额，排除余额、额度、优惠前价格。
- 自动识别商户、支付方式、北京时间、分类和方向。
- 高置信度直接写入；低置信度返回简记核对链接。
- 还款、已还清、信用卡/花呗/白条/借呗还款等截图强制人工核对。
- 使用归一化 OCR 文本生成稳定幂等键，重复截图不会重复入账。
- 设置页新增 OCR 自动入账接口地址与配置复制入口。

## 接口

```text
POST https://boqulmopdqwadqwkbgzm.supabase.co/functions/v1/muse-ocr
Authorization: Bearer muse_你的专用写入令牌
Content-Type: application/json
```

完整说明见 `简记-OCR自动入账接口.md`。

## Muse 权限

- `read`：查询账目与分类
- `write`：创建账目、调用 OCR/视觉解析
- `update`：修改由 Muse 创建的账目
- `delete`：删除由 Muse 创建的账目

手工账目不会被 Muse 修改或删除。

## 构建

```powershell
npm ci
npm run build
npm run publish:pages -- --target C:\path\to\repo\jianji
```

Tesseract wasm 和语言包体积较大，不重复放入源码包。首次使用前从部署目录的 `jianji/tesseract`、`jianji/tessdata` 复制到源码项目的 `public/`。发布脚本会先带入并校验这些运行资源，再清空旧 `jianji/`，避免旧 assets 堆积。