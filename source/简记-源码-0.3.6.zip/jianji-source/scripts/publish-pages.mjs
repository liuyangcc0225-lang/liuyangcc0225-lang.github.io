import { cp, mkdir, rm, stat } from 'node:fs/promises';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const appRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const targetIndex = process.argv.indexOf('--target');
const target = path.resolve(targetIndex >= 0 ? process.argv[targetIndex + 1] : path.join(appRoot, '..', '..', 'jianji'));

if (path.basename(target) !== 'jianji') {
  throw new Error('Refusing to publish: target directory must be named jianji');
}
if (path.dirname(target) === target) {
  throw new Error('Refusing to publish: invalid target directory');
}

const runNode = (script, args) => execFileSync(process.execPath, [script, ...args], {
  cwd: appRoot,
  stdio: 'inherit',
  windowsHide: true,
});

// Runtime-only OCR and icon assets are intentionally excluded from the source
// archive to keep the repository small. Move the current Pages copies into
// public/ BEFORE building so Vite includes them in the fresh dist-github.
for (const directory of ['tesseract', 'tessdata', 'icons']) {
  const source = path.join(target, directory);
  try {
    await stat(source);
  } catch {
    // Fall back to the local copy already present in public/.
    continue;
  }
  const destination = path.join(appRoot, 'public', directory);
  await rm(destination, { recursive: true, force: true });
  await cp(source, destination, { recursive: true, force: true });
}

runNode(path.join(appRoot, 'node_modules', 'typescript', 'bin', 'tsc'), ['-b']);
runNode(path.join(appRoot, 'node_modules', 'vite', 'bin', 'vite.js'), ['build']);
runNode(path.join(appRoot, 'node_modules', 'vite', 'bin', 'vite.js'), ['build', '--mode', 'github', '--outDir', 'dist-github']);

const dist = path.join(appRoot, 'dist-github');

// Never replace the live app unless the fresh build contains every runtime
// resource needed by screenshot OCR and the installed PWA.
for (const directory of ['tesseract', 'tessdata', 'icons']) {
  await stat(path.join(dist, directory));
}

await stat(path.join(dist, 'index.html'));

// The target is exclusively the Jianji app directory. Removing it first avoids
// accumulating stale hashed bundles and stale Service Worker precache entries.
await rm(target, { recursive: true, force: true });
await mkdir(path.dirname(target), { recursive: true });
await cp(dist, target, { recursive: true });

console.log(`Published ${dist} -> ${target}`);
