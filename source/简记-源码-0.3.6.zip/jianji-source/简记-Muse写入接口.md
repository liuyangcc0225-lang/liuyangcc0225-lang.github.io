# 简记 × Muse 写入接口

简记现在提供一个独立的 HTTPS 接口。Muse 或其他支持 HTTP Actions / API 调用的 AI 工具，可以使用一个专用 Bearer 令牌读取、创建、修改和删除账目。

该接口通过 Supabase Edge Function 中转，不需要把 Supabase Publishable Key 或 Service Role Key 交给 Muse。

## 安全边界

- 令牌权限由 `read`、`write`、`update`、`delete` 四个 scope 控制。
- 修改和删除只允许操作由 Muse 创建、带 `externalId` 的账目，不能修改手工账目。
- 令牌只以 SHA-256 哈希形式保存在 Supabase，简记页面只保存你生成后的本地副本。
- 不要把写入令牌发到公开群聊、代码仓库或截图里。
- 不再使用时，在简记「设置 → 云同步 → Muse 写入接口」撤销。

## 1. 生成令牌

1. 打开简记并登录云同步账号。
2. 进入「设置」。
3. 找到「Muse 写入接口」。
4. 点击「生成 Muse 写入令牌」。
5. 点击「复制 Muse 连接配置」，把配置交给 Muse 的 HTTP 工具。

## 2. 接口

```text
POST https://boqulmopdqwadqwkbgzm.supabase.co/functions/v1/muse-write
Authorization: Bearer muse_你的专用写入令牌
Content-Type: application/json
```

请求体：

```json
{
  "amount": 23.5,
  "direction": "expense",
  "merchant": "瑞幸咖啡",
  "categoryId": "food",
  "occurredAt": "2026-10-30T14:30:00+08:00",
  "source": "微信",
  "note": "Muse 自动记账",
  "idempotencyKey": "muse-20261030-1430-luckin"
}
```

`direction` 可填 `expense` / `income`，也可填「支出」/「收入」。

`occurredAt` 建议带 `+08:00`；不带时区时按北京时间解析。

`idempotencyKey` 是防止重复记账的自由文本。Muse 重试同一个请求时，应复用同一个值。接口会用第一次返回的交易 ID 返回 `duplicate: true`，不会新增第二笔。

## 查询账目

```json
{
  "action": "list",
  "query": {
    "from": "2026-10-01T00:00:00+08:00",
    "to": "2026-10-31T23:59:59+08:00",
    "direction": "expense",
    "categoryId": "food",
    "search": "瑞幸",
    "limit": 50,
    "offset": 0
  }
}
```

返回 `transactions`、`categories` 和本次返回的 `count`。`limit` 最大 200。

## 修改账目

只能修改 Muse 创建的账目。可按交易 ID 或幂等键定位：

```json
{
  "action": "update",
  "transactionId": "交易 ID",
  "fields": {
    "amount": 25,
    "merchant": "瑞幸咖啡",
    "categoryId": "food",
    "note": "已修改"
  }
}
```

也可以使用：

```json
{
  "action": "update",
  "idempotencyKey": "muse-20261030-1430-luckin",
  "fields": { "amount": 26 }
}
```

## 删除账目

删除接口与写入接口相同，只使用同一个 Bearer 令牌。只能删除通过 Muse 写入、带 `externalId` 的账目，不能删除手工录入或其他来源的账目。

推荐使用兼容性更好的 POST 方式：

```text
POST https://boqulmopdqwadqwkbgzm.supabase.co/functions/v1/muse-write
Authorization: Bearer muse_你的专用写入令牌
Content-Type: application/json
```

```json
{
  "action": "delete",
  "transactionId": "写入时返回的交易 ID"
}
```

也可以按幂等键删除：

```json
{
  "action": "delete",
  "idempotencyKey": "muse-20261030-1430-luckin"
}
```

标准 REST 客户端也可以使用 `DELETE` 方法，请求体字段相同。

删除成功响应：

```json
{
  "ok": true,
  "deleted": true,
  "alreadyDeleted": false,
  "transactionId": "交易 ID",
  "externalId": "muse-20261030-1430-luckin"
}
```

重复删除同一交易 ID 会返回 `alreadyDeleted: true`，不会报错。

## 3. 分类

可以使用分类 ID：

| categoryId | 分类 |
| --- | --- |
| food | 餐饮 |
| transport | 交通 |
| shopping | 购物 |
| home | 居住 |
| fun | 娱乐 |
| health | 医疗 |
| study | 学习 |
| social | 人情 |
| salary | 工资 |
| refund | 退款 |
| other | 其他 |

也可以直接传 `category: "餐饮"`。自定义分类可传对应的 `categoryId`。

## 4. 成功响应

第一次写入：

```json
{
  "ok": true,
  "duplicate": false,
  "transaction": {
    "id": "交易 UUID",
    "amount": 23.5,
    "merchant": "瑞幸咖啡"
  }
}
```

重复请求：

```json
{
  "ok": true,
  "duplicate": true,
  "transaction": {
    "id": "第一次返回的交易 UUID"
  }
}
```

## 5. 给 Muse 的工具说明

可以直接把下面的工具说明交给 Muse：

```text
当用户明确要求记录一笔账时，向简记写入接口发送 POST 请求。
接口：https://boqulmopdqwadqwkbgzm.supabase.co/functions/v1/muse-write
鉴权头：Authorization: Bearer <从安全配置读取的写入令牌>
不要把令牌展示在聊天里，也不要放进 URL。
金额必须为正数；方向默认 expense。
按北京时间填写 occurredAt，并生成稳定的 idempotencyKey。
请求成功后回复商户、金额和分类；不要重复发起同一个 idempotencyKey。
用户明确要求删除 Muse 创建的账目时，使用 action=delete，并传 transactionId 或 idempotencyKey。
只能删除 Muse 创建且带 externalId 的账目，找不到时不要猜测交易 ID。
用户要求查看账目时使用 action=list；可以按时间、收支、分类、商家或备注筛选。
用户要求修改时使用 action=update；只能修改 Muse 创建且带 externalId 的账目。
```

## 6. 重要限制

Muse 必须拥有“发起 HTTP 请求 / 调用自定义 API / Actions”的能力。仅有普通聊天能力、不能执行网络工具的版本，无法直接写入简记。


## 7. 临时视觉解析

如果客户端需要直接读取截图而不是普通文本，可调用 `muse-vision`：

```text
POST https://boqulmopdqwadqwkbgzm.supabase.co/functions/v1/muse-vision
Authorization: Bearer muse_你的专用写入令牌
Content-Type: multipart/form-data
```

表单字段 `image` 放单张截图（最大 8 MB）。接口只在内存中把图片转发给已配置的视觉供应商，不写相册、Storage 或数据库；返回 `transaction` 和可直接传给 `muse-write` 的 `writePayload`。完整说明见 `简记-Muse视觉解析接口.md`。