-- 简记 Supabase 云同步 schema
-- 在 Supabase Dashboard → SQL Editor 中执行一次。

create table if not exists public.ledger_snapshots (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default timezone('utc', now())
);

alter table public.ledger_snapshots enable row level security;

create or replace function public.touch_ledger_snapshot()
returns trigger
language plpgsql
security invoker
set search_path = public
as $$
begin
  new.updated_at = timezone('utc', now());
  return new;
end;
$$;

drop trigger if exists ledger_snapshots_touch_updated_at on public.ledger_snapshots;
create trigger ledger_snapshots_touch_updated_at
before insert or update on public.ledger_snapshots
for each row execute function public.touch_ledger_snapshot();

drop policy if exists "read own ledger snapshot" on public.ledger_snapshots;
create policy "read own ledger snapshot"
on public.ledger_snapshots for select
to authenticated
using ((select auth.uid()) = user_id);

drop policy if exists "insert own ledger snapshot" on public.ledger_snapshots;
create policy "insert own ledger snapshot"
on public.ledger_snapshots for insert
to authenticated
with check ((select auth.uid()) = user_id);

drop policy if exists "update own ledger snapshot" on public.ledger_snapshots;
create policy "update own ledger snapshot"
on public.ledger_snapshots for update
to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

drop policy if exists "delete own ledger snapshot" on public.ledger_snapshots;
create policy "delete own ledger snapshot"
on public.ledger_snapshots for delete
to authenticated
using ((select auth.uid()) = user_id);

revoke all on public.ledger_snapshots from anon;
grant select, insert, update, delete on public.ledger_snapshots to authenticated;

do $$
begin
  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'ledger_snapshots'
  ) then
    alter publication supabase_realtime add table public.ledger_snapshots;
  end if;
end;
$$;
-- 无跳转快捷指令：一次性令牌与待处理 OCR 队列
create extension if not exists pgcrypto with schema extensions;

create table if not exists public.shortcut_tokens (
  token_hash text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  label text not null default 'iPhone 快捷指令',
  scopes text[] not null default array['write']::text[],
  created_at timestamptz not null default timezone('utc', now()),
  last_used_at timestamptz,
  revoked_at timestamptz
);

alter table public.shortcut_tokens
  add column if not exists scopes text[] not null default array['write']::text[];

update public.shortcut_tokens
set scopes = array['read', 'write', 'update', 'delete']::text[]
where label = 'Muse AI 写入接口';

create index if not exists shortcut_tokens_user_id_idx on public.shortcut_tokens(user_id);
alter table public.shortcut_tokens enable row level security;

drop policy if exists "read own shortcut tokens" on public.shortcut_tokens;
create policy "read own shortcut tokens" on public.shortcut_tokens
for select to authenticated using ((select auth.uid()) = user_id);
drop policy if exists "insert own shortcut tokens" on public.shortcut_tokens;
create policy "insert own shortcut tokens" on public.shortcut_tokens
for insert to authenticated with check ((select auth.uid()) = user_id);
drop policy if exists "delete own shortcut tokens" on public.shortcut_tokens;
create policy "delete own shortcut tokens" on public.shortcut_tokens
for delete to authenticated using ((select auth.uid()) = user_id);

create table if not exists public.shortcut_captures (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  raw_text text not null,
  created_at timestamptz not null default timezone('utc', now()),
  processed_at timestamptz,
  error text
);

create index if not exists shortcut_captures_pending_idx
on public.shortcut_captures(user_id, created_at)
where processed_at is null;
alter table public.shortcut_captures enable row level security;

drop policy if exists "read own shortcut captures" on public.shortcut_captures;
create policy "read own shortcut captures" on public.shortcut_captures
for select to authenticated using ((select auth.uid()) = user_id);
drop policy if exists "update own shortcut captures" on public.shortcut_captures;
create policy "update own shortcut captures" on public.shortcut_captures
for update to authenticated using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);
drop policy if exists "delete own shortcut captures" on public.shortcut_captures;
create policy "delete own shortcut captures" on public.shortcut_captures
for delete to authenticated using ((select auth.uid()) = user_id);

revoke all on public.shortcut_tokens from anon;
revoke all on public.shortcut_captures from anon;
grant select, insert, update, delete on public.shortcut_tokens to authenticated;
grant select, update, delete on public.shortcut_captures to authenticated;

create or replace function public.capture_shortcut(p_token text, p_text text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_user_id uuid;
  v_hash text;
begin
  if p_token is null or length(p_token) < 24 then
    raise exception 'invalid shortcut token' using errcode = '28000';
  end if;
  if p_text is null or length(trim(p_text)) = 0 then
    raise exception 'empty capture text' using errcode = '22023';
  end if;

  v_hash := encode(digest(p_token, 'sha256'), 'hex');
  select user_id into v_user_id
  from public.shortcut_tokens
  where token_hash = v_hash and revoked_at is null
  limit 1;

  if v_user_id is null then
    raise exception 'invalid shortcut token' using errcode = '28000';
  end if;

  insert into public.shortcut_captures(user_id, raw_text)
  values (v_user_id, left(trim(p_text), 12000));

  update public.shortcut_tokens
  set last_used_at = timezone('utc', now())
  where token_hash = v_hash;

  return jsonb_build_object('ok', true);
end;
$$;

revoke all on function public.capture_shortcut(text, text) from public;
grant execute on function public.capture_shortcut(text, text) to anon, authenticated;
-- 一次性核对页：快捷指令返回专属 review_url
alter table public.shortcut_captures
  add column if not exists review_token_hash text,
  add column if not exists review_expires_at timestamptz;

create or replace function public.capture_shortcut(p_token text, p_text text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_user_id uuid;
  v_token_hash text;
  v_capture_id uuid;
  v_review_token text;
begin
  if p_token is null or length(p_token) < 24 then
    raise exception 'invalid shortcut token' using errcode = '28000';
  end if;
  if p_text is null or length(trim(p_text)) = 0 then
    raise exception 'empty capture text' using errcode = '22023';
  end if;

  v_token_hash := encode(digest(p_token, 'sha256'), 'hex');
  select user_id into v_user_id
  from public.shortcut_tokens
  where token_hash = v_token_hash and revoked_at is null
  limit 1;

  if v_user_id is null then
    raise exception 'invalid shortcut token' using errcode = '28000';
  end if;

  v_review_token := rtrim(translate(encode(gen_random_bytes(24), 'base64'), '+/', '-_'), '=');

  insert into public.shortcut_captures(user_id, raw_text, review_token_hash, review_expires_at)
  values (v_user_id, left(trim(p_text), 12000), encode(digest(v_review_token, 'sha256'), 'hex'), timezone('utc', now()) + interval '30 minutes')
  returning id into v_capture_id;

  update public.shortcut_tokens
  set last_used_at = timezone('utc', now())
  where token_hash = v_token_hash;

  return jsonb_build_object(
    'ok', true,
    'capture_id', v_capture_id,
    'review_url', 'https://liuyangcc0225-lang.github.io/jianji/review.html?capture=' || v_capture_id::text || '&token=' || v_review_token
  );
end;
$$;

create or replace function public.get_shortcut_capture(p_capture_id uuid, p_review_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_capture public.shortcut_captures%rowtype;
  v_categories jsonb := '[]'::jsonb;
begin
  select * into v_capture
  from public.shortcut_captures
  where id = p_capture_id
    and review_token_hash = encode(digest(p_review_token, 'sha256'), 'hex')
    and processed_at is null
    and review_expires_at > timezone('utc', now())
  limit 1;

  if not found then
    raise exception 'invalid or expired review link' using errcode = '28000';
  end if;

  select coalesce(payload -> 'categories', '[]'::jsonb)
  into v_categories
  from public.ledger_snapshots
  where user_id = v_capture.user_id;

  return jsonb_build_object(
    'capture_id', v_capture.id,
    'raw_text', v_capture.raw_text,
    'created_at', v_capture.created_at,
    'categories', coalesce(v_categories, '[]'::jsonb)
  );
end;
$$;

create or replace function public.save_shortcut_capture(
  p_capture_id uuid,
  p_review_token text,
  p_amount numeric,
  p_direction text,
  p_merchant text,
  p_category_id text,
  p_occurred_at timestamptz,
  p_source text,
  p_note text
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_capture public.shortcut_captures%rowtype;
  v_payload jsonb;
  v_transaction jsonb;
begin
  if p_amount is null or p_amount <= 0 then
    raise exception 'amount must be positive' using errcode = '22023';
  end if;
  if p_direction not in ('expense', 'income') then
    raise exception 'invalid direction' using errcode = '22023';
  end if;

  select * into v_capture
  from public.shortcut_captures
  where id = p_capture_id
    and review_token_hash = encode(digest(p_review_token, 'sha256'), 'hex')
    and processed_at is null
    and review_expires_at > timezone('utc', now())
  for update;

  if not found then
    raise exception 'invalid or expired review link' using errcode = '28000';
  end if;

  v_transaction := jsonb_build_object(
    'id', gen_random_uuid()::text,
    'amount', p_amount,
    'direction', p_direction,
    'merchant', left(coalesce(nullif(trim(p_merchant), ''), '未命名账目'), 80),
    'categoryId', coalesce(nullif(trim(p_category_id), ''), 'other'),
    'occurredAt', p_occurred_at,
    'source', coalesce(nullif(trim(p_source), ''), '未注明'),
    'note', left(coalesce(p_note, ''), 500),
    'createdAt', timezone('utc', now()),
    'updatedAt', timezone('utc', now())
  );

  select payload into v_payload
  from public.ledger_snapshots
  where user_id = v_capture.user_id
  for update;

  if v_payload is null then
    v_payload := jsonb_build_object(
      'version', 1,
      'transactions', '[]'::jsonb,
      'categories', '[]'::jsonb,
      'deletedTransactionIds', '[]'::jsonb,
      'deletedCategoryIds', '[]'::jsonb,
      'savedAt', timezone('utc', now())
    );
  end if;

  v_payload := jsonb_set(
    v_payload,
    '{transactions}',
    coalesce(v_payload -> 'transactions', '[]'::jsonb) || jsonb_build_array(v_transaction),
    true
  );
  v_payload := jsonb_set(v_payload, '{savedAt}', to_jsonb(timezone('utc', now())), true);

  insert into public.ledger_snapshots(user_id, payload, updated_at)
  values (v_capture.user_id, v_payload, timezone('utc', now()))
  on conflict (user_id) do update
  set payload = excluded.payload, updated_at = excluded.updated_at;

  update public.shortcut_captures
  set processed_at = timezone('utc', now()), error = null
  where id = p_capture_id;

  return jsonb_build_object('ok', true, 'transaction', v_transaction);
end;
$$;

create or replace function public.skip_shortcut_capture(p_capture_id uuid, p_review_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  update public.shortcut_captures
  set processed_at = timezone('utc', now()), error = '用户跳过这次识别'
  where id = p_capture_id
    and review_token_hash = encode(digest(p_review_token, 'sha256'), 'hex')
    and processed_at is null;

  if not found then
    raise exception 'invalid or expired review link' using errcode = '28000';
  end if;

  return jsonb_build_object('ok', true);
end;
$$;

revoke all on function public.capture_shortcut(text, text) from public;
revoke all on function public.get_shortcut_capture(uuid, text) from public;
revoke all on function public.save_shortcut_capture(uuid, text, numeric, text, text, text, timestamptz, text, text) from public;
revoke all on function public.skip_shortcut_capture(uuid, text) from public;
grant execute on function public.capture_shortcut(text, text) to anon, authenticated;
grant execute on function public.get_shortcut_capture(uuid, text) to anon, authenticated;
grant execute on function public.save_shortcut_capture(uuid, text, numeric, text, text, text, timestamptz, text, text) to anon, authenticated;
grant execute on function public.skip_shortcut_capture(uuid, text) to anon, authenticated;
-- 单弹窗多字段编辑：返回 draft_text，并支持保存编辑后的 key=value 文本
create or replace function public.capture_shortcut(p_token text, p_text text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_user_id uuid;
  v_token_hash text;
  v_capture_id uuid;
  v_review_token text;
  v_amount text;
  v_merchant text;
  v_source text;
  v_time_text text;
  v_draft_text text;
  v_match text[];
begin
  if p_token is null or length(p_token) < 24 then
    raise exception 'invalid shortcut token' using errcode = '28000';
  end if;
  if p_text is null or length(trim(p_text)) = 0 then
    raise exception 'empty capture text' using errcode = '22023';
  end if;

  v_token_hash := encode(digest(p_token, 'sha256'), 'hex');
  select user_id into v_user_id
  from public.shortcut_tokens
  where token_hash = v_token_hash and revoked_at is null
  limit 1;

  if v_user_id is null then
    raise exception 'invalid shortcut token' using errcode = '28000';
  end if;

  v_review_token := rtrim(translate(encode(gen_random_bytes(24), 'base64'), '+/', '-_'), '=');

  insert into public.shortcut_captures(user_id, raw_text, review_token_hash, review_expires_at)
  values (v_user_id, left(trim(p_text), 12000), encode(digest(v_review_token, 'sha256'), 'hex'), timezone('utc', now()) + interval '30 minutes')
  returning id into v_capture_id;

  update public.shortcut_tokens
  set last_used_at = timezone('utc', now())
  where token_hash = v_token_hash;

  v_match := regexp_match(p_text, '[−-]\s*[¥￥]?\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)');
  if v_match is null then
    v_match := regexp_match(p_text, '(?:金额|实付|支付金额|订单金额|合计)[：:]?\s*[¥￥]?\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)');
  end if;
  v_amount := replace(coalesce(v_match[1], ''), ',', '');

  v_match := regexp_match(p_text, '(?:商户全称|商户名称|收款方|商品名称|商品)[：:]\s*([^\n\r]+)');
  if v_match is null then
    v_match := regexp_match(p_text, '(?:商户全称|商户名称|收款方|商品名称|商品)[：:]\s*([^\n\r]+)');
  end if;
  v_merchant := replace(coalesce(v_match[1], '未命名账目'), E'\n', ' ');

  v_match := regexp_match(p_text, '(?:支付方式|付款方式)[：:]\s*([^\n\r]+)');
  if v_match is not null then
    v_source := trim(v_match[1]);
  elsif p_text ~* '支付宝' then
    v_source := '支付宝';
  elsif p_text ~ '微信|零钱' then
    v_source := '微信';
  elsif p_text ~* 'apple pay' then
    v_source := 'Apple Pay';
  elsif p_text ~ '银行卡|储蓄卡|信用卡' then
    v_source := '银行卡';
  else
    v_source := '未注明';
  end if;

  v_match := regexp_match(p_text, '(20[0-9]{2}年[0-9]{1,2}月[0-9]{1,2}日\s*[0-9]{1,2}:[0-9]{2}(?::[0-9]{2})?)');
  v_time_text := coalesce(v_match[1], to_char(timezone('Asia/Shanghai', now()), 'YYYY-MM-DD HH24:MI'));

  v_draft_text :=
    '分类=其他' || E'\n' ||
    '商户=' || coalesce(v_merchant, '未命名账目') || E'\n' ||
    '金额=' || v_amount || E'\n' ||
    '账户=' || coalesce(v_source, '未注明') || E'\n' ||
    '备注=' || E'\n' ||
    '时间=' || v_time_text;

  return jsonb_build_object(
    'ok', true,
    'capture_id', v_capture_id,
    'review_token', v_review_token,
    'draft_text', v_draft_text,
    'review_url', 'https://liuyangcc0225-lang.github.io/jianji/review.html?capture=' || v_capture_id::text || '&token=' || v_review_token
  );
end;
$$;

create or replace function public.save_shortcut_multiline(
  p_capture_id uuid,
  p_review_token text,
  p_form_text text
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_fields jsonb;
  v_category text;
  v_category_id text;
  v_direction text;
  v_time timestamptz;
begin
  select jsonb_object_agg(
    trim(both from split_part(line, '=', 1)),
    trim(both from substr(line, position('=' in line) + 1))
  )
  into v_fields
  from regexp_split_to_table(coalesce(p_form_text, ''), E'\n+') as line
  where position('=' in line) > 0;

  if v_fields is null then
    raise exception 'invalid form text' using errcode = '22023';
  end if;

  v_category := coalesce(v_fields ->> '分类', '其他');
  v_category_id := case
    when v_category in ('餐饮', 'food') then 'food'
    when v_category in ('交通', 'transport') then 'transport'
    when v_category in ('购物', 'shopping') then 'shopping'
    when v_category in ('居住', 'home') then 'home'
    when v_category in ('娱乐', 'fun') then 'fun'
    when v_category in ('医疗', 'health') then 'health'
    when v_category in ('学习', 'study') then 'study'
    when v_category in ('人情', 'social') then 'social'
    when v_category in ('工资', 'salary') then 'salary'
    when v_category in ('退款', 'refund') then 'refund'
    else coalesce(nullif(v_fields ->> '分类ID', ''), 'other')
  end;
  v_direction := case when coalesce(v_fields ->> '收支', '支出') = '收入' then 'income' else 'expense' end;
  begin
    v_time := coalesce(nullif(v_fields ->> '时间', '')::timestamptz, timezone('utc', now()));
  exception when others then
    v_time := timezone('utc', now());
  end;

  return public.save_shortcut_capture(
    p_capture_id,
    p_review_token,
    nullif(regexp_replace(coalesce(v_fields ->> '金额', ''), '[^0-9.]', '', 'g'), '')::numeric,
    v_direction,
    coalesce(v_fields ->> '商户', '未命名账目'),
    v_category_id,
    v_time,
    coalesce(v_fields ->> '账户', '未注明'),
    coalesce(v_fields ->> '备注', '')
  );
end;
$$;

revoke all on function public.save_shortcut_multiline(uuid, text, text) from public;
grant execute on function public.save_shortcut_multiline(uuid, text, text) to anon, authenticated;

-- Muse AI / external agent write API. The caller must know a dedicated token.
create or replace function public.muse_write_transaction(p_token text, p_payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_user_id uuid;
  v_token_hash text;
  v_payload jsonb;
  v_transaction jsonb;
  v_existing jsonb;
  v_amount numeric;
  v_direction text;
  v_merchant text;
  v_category text;
  v_category_id text;
  v_time_text text;
  v_occurred_at timestamptz;
  v_source text;
  v_note text;
  v_external_id text;
  v_saved_at timestamptz := timezone('utc', now());
begin
  if p_token is null or length(p_token) < 24 then
    raise exception 'invalid muse token' using errcode = '28000';
  end if;
  if p_payload is null or jsonb_typeof(p_payload) <> 'object' then
    raise exception 'payload must be a JSON object' using errcode = '22023';
  end if;

  v_token_hash := encode(digest(p_token, 'sha256'), 'hex');
  select user_id into v_user_id
  from public.shortcut_tokens
  where token_hash = v_token_hash
    and revoked_at is null
    and label = 'Muse AI 写入接口'
    and 'write' = any(scopes)
  limit 1;

  if v_user_id is null then
    raise exception 'invalid muse token' using errcode = '28000';
  end if;

  v_amount := nullif(regexp_replace(coalesce(p_payload ->> 'amount', p_payload ->> '金额', ''), '[^0-9.-]', '', 'g'), '')::numeric;
  if v_amount is null or v_amount <= 0 then
    raise exception 'amount must be positive' using errcode = '22023';
  end if;

  v_direction := case
    when coalesce(p_payload ->> 'direction', p_payload ->> '收支', 'expense') in ('income', '收入') then 'income'
    else 'expense'
  end;
  v_merchant := left(coalesce(nullif(trim(coalesce(p_payload ->> 'merchant', p_payload ->> '商户')), ''), 'Muse 记账'), 80);
  v_category := coalesce(nullif(trim(coalesce(p_payload ->> 'category', p_payload ->> '分类')), ''), '其他');
  v_category_id := case
    when v_category in ('餐饮', 'food') then 'food'
    when v_category in ('交通', 'transport') then 'transport'
    when v_category in ('购物', 'shopping') then 'shopping'
    when v_category in ('居住', 'home') then 'home'
    when v_category in ('娱乐', 'fun') then 'fun'
    when v_category in ('医疗', 'health') then 'health'
    when v_category in ('学习', 'study') then 'study'
    when v_category in ('人情', 'social') then 'social'
    when v_category in ('工资', 'salary') then 'salary'
    when v_category in ('退款', 'refund') then 'refund'
    else coalesce(nullif(trim(p_payload ->> 'categoryId'), ''), nullif(trim(p_payload ->> '分类ID'), ''), 'other')
  end;

  v_time_text := nullif(trim(coalesce(p_payload ->> 'occurredAt', p_payload ->> '时间')), '');
  if v_time_text is null then
    v_occurred_at := v_saved_at;
  elsif v_time_text ~ '年.*月.*日' then
    v_occurred_at := (
      regexp_replace(regexp_replace(regexp_replace(v_time_text, '年', '-', 'g'), '月', '-', 'g'), '日', ' ', 'g')
    )::timestamp at time zone 'Asia/Shanghai';
  elsif v_time_text ~* '(z|[+-][0-9]{2}:?[0-9]{2})$' then
    v_occurred_at := v_time_text::timestamptz;
  else
    v_occurred_at := regexp_replace(v_time_text, 'T', ' ', 'g')::timestamp at time zone 'Asia/Shanghai';
  end if;

  v_source := left(coalesce(nullif(trim(coalesce(p_payload ->> 'source', p_payload ->> '账户')), ''), 'Muse'), 40);
  v_note := left(coalesce(p_payload ->> 'note', p_payload ->> '备注', ''), 500);
  v_external_id := left(coalesce(
    nullif(trim(p_payload ->> 'idempotencyKey'), ''),
    'muse:' || md5(concat_ws('|', v_amount::text, v_direction, v_merchant, v_category_id, v_occurred_at::text))
  ), 160);

  insert into public.ledger_snapshots(user_id, payload, updated_at)
  values (
    v_user_id,
    jsonb_build_object(
      'version', 1,
      'transactions', '[]'::jsonb,
      'categories', '[]'::jsonb,
      'deletedTransactionIds', '[]'::jsonb,
      'deletedCategoryIds', '[]'::jsonb,
      'savedAt', v_saved_at
    ),
    v_saved_at
  )
  on conflict (user_id) do nothing;

  select payload into v_payload
  from public.ledger_snapshots
  where user_id = v_user_id
  for update;

  select item into v_existing
  from jsonb_array_elements(coalesce(v_payload -> 'transactions', '[]'::jsonb)) as item
  where item ->> 'externalId' = v_external_id
  limit 1;

  if v_existing is not null then
    return jsonb_build_object('ok', true, 'duplicate', true, 'transaction', v_existing);
  end if;

  v_transaction := jsonb_build_object(
    'id', gen_random_uuid()::text,
    'amount', v_amount,
    'direction', v_direction,
    'merchant', v_merchant,
    'categoryId', v_category_id,
    'occurredAt', v_occurred_at,
    'source', v_source,
    'note', v_note,
    'createdAt', v_saved_at,
    'updatedAt', v_saved_at,
    'externalId', v_external_id
  );

  v_payload := jsonb_set(
    v_payload,
    '{transactions}',
    coalesce(v_payload -> 'transactions', '[]'::jsonb) || jsonb_build_array(v_transaction),
    true
  );
  v_payload := jsonb_set(v_payload, '{savedAt}', to_jsonb(v_saved_at), true);

  update public.ledger_snapshots
  set payload = v_payload, updated_at = v_saved_at
  where user_id = v_user_id;

  update public.shortcut_tokens
  set last_used_at = v_saved_at
  where token_hash = v_token_hash;

  return jsonb_build_object('ok', true, 'duplicate', false, 'transaction', v_transaction);
end;
$$;

revoke all on function public.muse_write_transaction(text, jsonb) from public;
grant execute on function public.muse_write_transaction(text, jsonb) to anon, authenticated;

-- Delete only transactions that were created through the Muse write API.
create or replace function public.muse_delete_transaction(
  p_token text,
  p_transaction_id text default null,
  p_external_id text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_user_id uuid;
  v_token_hash text;
  v_payload jsonb;
  v_transaction jsonb;
  v_tombstones jsonb;
  v_transaction_id text;
  v_saved_at timestamptz := timezone('utc', now());
begin
  if p_token is null or length(p_token) < 24 then
    raise exception 'invalid muse token' using errcode = '28000';
  end if;
  if nullif(trim(p_transaction_id), '') is null and nullif(trim(p_external_id), '') is null then
    raise exception 'transactionId or idempotencyKey is required' using errcode = '22023';
  end if;

  v_token_hash := encode(digest(p_token, 'sha256'), 'hex');
  select user_id into v_user_id
  from public.shortcut_tokens
  where token_hash = v_token_hash
    and revoked_at is null
    and label = 'Muse AI 写入接口'
    and 'delete' = any(scopes)
  limit 1;

  if v_user_id is null then
    raise exception 'invalid muse token' using errcode = '28000';
  end if;

  select payload into v_payload
  from public.ledger_snapshots
  where user_id = v_user_id
  for update;

  if v_payload is null then
    raise exception 'transaction not found' using errcode = 'P0002';
  end if;

  select item into v_transaction
  from jsonb_array_elements(coalesce(v_payload -> 'transactions', '[]'::jsonb)) as item
  where nullif(trim(p_transaction_id), '') is not null
    and item ->> 'id' = trim(p_transaction_id)
    and nullif(item ->> 'externalId', '') is not null
  or nullif(trim(p_external_id), '') is not null
    and item ->> 'externalId' = trim(p_external_id)
  limit 1;

  if v_transaction is null then
    v_tombstones := coalesce(v_payload -> 'deletedTransactionIds', '[]'::jsonb);
    if nullif(trim(p_transaction_id), '') is not null
      and v_tombstones ? trim(p_transaction_id) then
      return jsonb_build_object('ok', true, 'deleted', false, 'alreadyDeleted', true, 'transactionId', trim(p_transaction_id));
    end if;
    raise exception 'muse transaction not found' using errcode = 'P0002';
  end if;

  v_transaction_id := v_transaction ->> 'id';
  v_payload := jsonb_set(
    v_payload,
    '{transactions}',
    (select coalesce(jsonb_agg(item), '[]'::jsonb)
     from jsonb_array_elements(coalesce(v_payload -> 'transactions', '[]'::jsonb)) as item
     where item ->> 'id' <> v_transaction_id),
    true
  );
  v_tombstones := coalesce(v_payload -> 'deletedTransactionIds', '[]'::jsonb);
  if not v_tombstones ? v_transaction_id then
    v_tombstones := v_tombstones || jsonb_build_array(v_transaction_id);
  end if;
  v_payload := jsonb_set(v_payload, '{deletedTransactionIds}', v_tombstones, true);
  v_payload := jsonb_set(v_payload, '{savedAt}', to_jsonb(v_saved_at), true);

  update public.ledger_snapshots
  set payload = v_payload, updated_at = v_saved_at
  where user_id = v_user_id;

  update public.shortcut_tokens
  set last_used_at = v_saved_at
  where token_hash = v_token_hash;

  return jsonb_build_object(
    'ok', true,
    'deleted', true,
    'alreadyDeleted', false,
    'transactionId', v_transaction_id,
    'externalId', v_transaction ->> 'externalId',
    'transaction', v_transaction
  );
end;
$$;

revoke all on function public.muse_delete_transaction(text, text, text) from public;
grant execute on function public.muse_delete_transaction(text, text, text) to anon, authenticated;

-- Read-only transaction/category query for Muse.
create or replace function public.muse_list_transactions(p_token text, p_query jsonb default '{}'::jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_user_id uuid;
  v_token_hash text;
  v_payload jsonb;
  v_transactions jsonb;
  v_from text;
  v_to text;
  v_from_at timestamptz;
  v_to_at timestamptz;
  v_direction text;
  v_category_id text;
  v_search text;
  v_limit integer;
  v_offset integer;
begin
  if p_token is null or length(p_token) < 24 then
    raise exception 'invalid muse token' using errcode = '28000';
  end if;
  if p_query is not null and jsonb_typeof(p_query) <> 'object' then
    raise exception 'query must be a JSON object' using errcode = '22023';
  end if;

  v_token_hash := encode(digest(p_token, 'sha256'), 'hex');
  select user_id into v_user_id
  from public.shortcut_tokens
  where token_hash = v_token_hash
    and revoked_at is null
    and label = 'Muse AI 写入接口'
    and 'read' = any(scopes)
  limit 1;
  if v_user_id is null then
    raise exception 'invalid muse token' using errcode = '28000';
  end if;

  select payload into v_payload
  from public.ledger_snapshots
  where user_id = v_user_id;

  v_from := nullif(trim(coalesce(p_query ->> 'from', p_query ->> '开始时间')), '');
  if v_from is not null then
    if v_from ~ '年.*月.*日' then
      v_from_at := regexp_replace(regexp_replace(regexp_replace(v_from, '年', '-', 'g'), '月', '-', 'g'), '日', ' ', 'g')::timestamp at time zone 'Asia/Shanghai';
    elsif v_from ~* '(z|[+-][0-9]{2}:?[0-9]{2})$' then
      v_from_at := v_from::timestamptz;
    else
      v_from_at := regexp_replace(v_from, 'T', ' ', 'g')::timestamp at time zone 'Asia/Shanghai';
    end if;
  end if;

  v_to := nullif(trim(coalesce(p_query ->> 'to', p_query ->> '结束时间')), '');
  if v_to is not null then
    if v_to ~ '年.*月.*日' then
      v_to_at := regexp_replace(regexp_replace(regexp_replace(v_to, '年', '-', 'g'), '月', '-', 'g'), '日', ' ', 'g')::timestamp at time zone 'Asia/Shanghai';
    elsif v_to ~* '(z|[+-][0-9]{2}:?[0-9]{2})$' then
      v_to_at := v_to::timestamptz;
    else
      v_to_at := regexp_replace(v_to, 'T', ' ', 'g')::timestamp at time zone 'Asia/Shanghai';
    end if;
  end if;

  v_direction := nullif(trim(coalesce(p_query ->> 'direction', p_query ->> '收支')), '');
  v_category_id := nullif(trim(coalesce(p_query ->> 'categoryId', p_query ->> '分类ID')), '');
  v_search := nullif(trim(coalesce(p_query ->> 'search', p_query ->> 'query', p_query ->> '搜索')), '');
  v_limit := least(greatest(coalesce(nullif(regexp_replace(coalesce(p_query ->> 'limit', ''), '[^0-9]', '', 'g'), '')::integer, 100), 1), 200);
  v_offset := greatest(coalesce(nullif(regexp_replace(coalesce(p_query ->> 'offset', ''), '[^0-9]', '', 'g'), '')::integer, 0), 0);

  select coalesce(jsonb_agg(item order by (item ->> 'occurredAt')::timestamptz desc), '[]'::jsonb)
  into v_transactions
  from (
    select item
    from jsonb_array_elements(coalesce(v_payload -> 'transactions', '[]'::jsonb)) as item
    where not (coalesce(v_payload -> 'deletedTransactionIds', '[]'::jsonb) ? (item ->> 'id'))
      and (v_from_at is null or (item ->> 'occurredAt')::timestamptz >= v_from_at)
      and (v_to_at is null or (item ->> 'occurredAt')::timestamptz <= v_to_at)
      and (
        v_direction is null
        or (case when v_direction in ('income', '收入') then 'income' else 'expense' end) = item ->> 'direction'
      )
      and (v_category_id is null or item ->> 'categoryId' = v_category_id)
      and (
        v_search is null
        or item ->> 'merchant' ilike '%' || v_search || '%'
        or item ->> 'note' ilike '%' || v_search || '%'
        or item ->> 'source' ilike '%' || v_search || '%'
      )
    order by (item ->> 'occurredAt')::timestamptz desc
    limit v_limit offset v_offset
  ) as filtered;

  update public.shortcut_tokens
  set last_used_at = timezone('utc', now())
  where token_hash = v_token_hash;

  return jsonb_build_object(
    'ok', true,
    'count', jsonb_array_length(v_transactions),
    'transactions', v_transactions,
    'categories', coalesce(v_payload -> 'categories', '[]'::jsonb)
  );
end;
$$;

revoke all on function public.muse_list_transactions(text, jsonb) from public;
grant execute on function public.muse_list_transactions(text, jsonb) to anon, authenticated;

-- Update only transactions that were created through the Muse write API.
create or replace function public.muse_update_transaction(
  p_token text,
  p_transaction_id text,
  p_external_id text,
  p_payload jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_user_id uuid;
  v_token_hash text;
  v_payload jsonb;
  v_old jsonb;
  v_updated jsonb;
  v_transaction_id text;
  v_amount numeric;
  v_direction text;
  v_merchant text;
  v_category text;
  v_category_id text;
  v_time_text text;
  v_occurred_at timestamptz;
  v_source text;
  v_note text;
  v_saved_at timestamptz := timezone('utc', now());
begin
  if p_token is null or length(p_token) < 24 then
    raise exception 'invalid muse token' using errcode = '28000';
  end if;
  if nullif(trim(p_transaction_id), '') is null and nullif(trim(p_external_id), '') is null then
    raise exception 'transactionId or idempotencyKey is required' using errcode = '22023';
  end if;
  if p_payload is null or jsonb_typeof(p_payload) <> 'object' then
    raise exception 'payload must be a JSON object' using errcode = '22023';
  end if;

  v_token_hash := encode(digest(p_token, 'sha256'), 'hex');
  select user_id into v_user_id
  from public.shortcut_tokens
  where token_hash = v_token_hash
    and revoked_at is null
    and label = 'Muse AI 写入接口'
    and 'update' = any(scopes)
  limit 1;
  if v_user_id is null then
    raise exception 'invalid muse token' using errcode = '28000';
  end if;

  select payload into v_payload
  from public.ledger_snapshots
  where user_id = v_user_id
  for update;
  if v_payload is null then
    raise exception 'muse transaction not found' using errcode = 'P0002';
  end if;

  select item into v_old
  from jsonb_array_elements(coalesce(v_payload -> 'transactions', '[]'::jsonb)) as item
  where nullif(item ->> 'externalId', '') is not null
    and (
      (nullif(trim(p_transaction_id), '') is not null and item ->> 'id' = trim(p_transaction_id))
      or (nullif(trim(p_external_id), '') is not null and item ->> 'externalId' = trim(p_external_id))
    )
  limit 1;
  if v_old is null then
    raise exception 'muse transaction not found' using errcode = 'P0002';
  end if;

  v_transaction_id := v_old ->> 'id';
  v_amount := coalesce(nullif(trim(coalesce(p_payload ->> 'amount', p_payload ->> '金额')), '')::numeric, (v_old ->> 'amount')::numeric);
  if v_amount <= 0 then
    raise exception 'amount must be positive' using errcode = '22023';
  end if;
  v_direction := case
    when nullif(trim(coalesce(p_payload ->> 'direction', p_payload ->> '收支')), '') is null then v_old ->> 'direction'
    when coalesce(p_payload ->> 'direction', p_payload ->> '收支') in ('income', '收入') then 'income'
    else 'expense'
  end;
  v_merchant := left(coalesce(nullif(trim(coalesce(p_payload ->> 'merchant', p_payload ->> '商户')), ''), v_old ->> 'merchant'), 80);
  v_category := nullif(trim(coalesce(p_payload ->> 'category', p_payload ->> '分类')), '');
  v_category_id := case
    when v_category is null then coalesce(nullif(trim(coalesce(p_payload ->> 'categoryId', p_payload ->> '分类ID')), ''), v_old ->> 'categoryId')
    when v_category in ('餐饮', 'food') then 'food'
    when v_category in ('交通', 'transport') then 'transport'
    when v_category in ('购物', 'shopping') then 'shopping'
    when v_category in ('居住', 'home') then 'home'
    when v_category in ('娱乐', 'fun') then 'fun'
    when v_category in ('医疗', 'health') then 'health'
    when v_category in ('学习', 'study') then 'study'
    when v_category in ('人情', 'social') then 'social'
    when v_category in ('工资', 'salary') then 'salary'
    when v_category in ('退款', 'refund') then 'refund'
    else coalesce(nullif(trim(p_payload ->> 'categoryId'), ''), nullif(trim(p_payload ->> '分类ID'), ''), 'other')
  end;
  v_time_text := nullif(trim(coalesce(p_payload ->> 'occurredAt', p_payload ->> '时间')), '');
  if v_time_text is null then
    v_occurred_at := (v_old ->> 'occurredAt')::timestamptz;
  elsif v_time_text ~ '年.*月.*日' then
    v_occurred_at := regexp_replace(regexp_replace(regexp_replace(v_time_text, '年', '-', 'g'), '月', '-', 'g'), '日', ' ', 'g')::timestamp at time zone 'Asia/Shanghai';
  elsif v_time_text ~* '(z|[+-][0-9]{2}:?[0-9]{2})$' then
    v_occurred_at := v_time_text::timestamptz;
  else
    v_occurred_at := regexp_replace(v_time_text, 'T', ' ', 'g')::timestamp at time zone 'Asia/Shanghai';
  end if;
  v_source := left(coalesce(nullif(trim(coalesce(p_payload ->> 'source', p_payload ->> '账户')), ''), v_old ->> 'source'), 40);
  v_note := left(coalesce(p_payload ->> 'note', p_payload ->> '备注', v_old ->> 'note', ''), 500);

  v_updated := v_old || jsonb_build_object(
    'amount', v_amount,
    'direction', v_direction,
    'merchant', v_merchant,
    'categoryId', v_category_id,
    'occurredAt', v_occurred_at,
    'source', v_source,
    'note', v_note,
    'updatedAt', v_saved_at
  );
  v_payload := jsonb_set(
    v_payload,
    '{transactions}',
    (select coalesce(jsonb_agg(case when item ->> 'id' = v_transaction_id then v_updated else item end), '[]'::jsonb)
     from jsonb_array_elements(coalesce(v_payload -> 'transactions', '[]'::jsonb)) as item),
    true
  );
  v_payload := jsonb_set(v_payload, '{savedAt}', to_jsonb(v_saved_at), true);

  update public.ledger_snapshots
  set payload = v_payload, updated_at = v_saved_at
  where user_id = v_user_id;
  update public.shortcut_tokens
  set last_used_at = v_saved_at
  where token_hash = v_token_hash;

  return jsonb_build_object('ok', true, 'transaction', v_updated);
end;
$$;

revoke all on function public.muse_update_transaction(text, text, text, jsonb) from public;
grant execute on function public.muse_update_transaction(text, text, text, jsonb) to anon, authenticated;
create or replace function public.save_shortcut_multiline(
  p_capture_id uuid,
  p_review_token text,
  p_form_text text
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_fields jsonb;
  v_category text;
  v_category_id text;
  v_direction text;
  v_time text;
  v_parsed_time timestamptz;
begin
  select jsonb_object_agg(
    trim(both from split_part(line, '=', 1)),
    trim(both from substr(line, position('=' in line) + 1))
  )
  into v_fields
  from regexp_split_to_table(coalesce(p_form_text, ''), E'\n+') as line
  where position('=' in line) > 0;

  if v_fields is null then
    raise exception 'invalid form text' using errcode = '22023';
  end if;

  v_category := coalesce(v_fields ->> '分类', '其他');
  v_category_id := case
    when v_category in ('餐饮', 'food') then 'food'
    when v_category in ('交通', 'transport') then 'transport'
    when v_category in ('购物', 'shopping') then 'shopping'
    when v_category in ('居住', 'home') then 'home'
    when v_category in ('娱乐', 'fun') then 'fun'
    when v_category in ('医疗', 'health') then 'health'
    when v_category in ('学习', 'study') then 'study'
    when v_category in ('人情', 'social') then 'social'
    when v_category in ('工资', 'salary') then 'salary'
    when v_category in ('退款', 'refund') then 'refund'
    else coalesce(nullif(v_fields ->> '分类ID', ''), 'other')
  end;
  v_direction := case when coalesce(v_fields ->> '收支', '支出') = '收入' then 'income' else 'expense' end;

  v_time := nullif(v_fields ->> '时间', '');
  if v_time is null then
    v_parsed_time := timezone('utc', now());
  elsif v_time ~ '年.*月.*日' then
    v_parsed_time := (
      regexp_replace(regexp_replace(regexp_replace(v_time, '年', '-', 'g'), '月', '-', 'g'), '日', ' ', 'g')
    )::timestamp at time zone 'Asia/Shanghai';
  elsif v_time ~* '(z|[+-][0-9]{2}:?[0-9]{2})$' then
    begin
      v_parsed_time := v_time::timestamptz;
    exception when others then
      v_parsed_time := timezone('utc', now());
    end;
  else
    begin
      -- The native Shortcuts input contains Beijing wall-clock time with no offset.
      v_parsed_time := regexp_replace(v_time, 'T', ' ', 'g')::timestamp at time zone 'Asia/Shanghai';
    exception when others then
      v_parsed_time := timezone('utc', now());
    end;
  end if;

  return public.save_shortcut_capture(
    p_capture_id,
    p_review_token,
    nullif(regexp_replace(coalesce(v_fields ->> '金额', ''), '[^0-9.]', '', 'g'), '')::numeric,
    v_direction,
    coalesce(v_fields ->> '商户', '未命名账目'),
    v_category_id,
    v_parsed_time,
    coalesce(v_fields ->> '账户', '未注明'),
    coalesce(v_fields ->> '备注', '')
  );
end;
$$;

revoke all on function public.save_shortcut_multiline(uuid, text, text) from public;
grant execute on function public.save_shortcut_multiline(uuid, text, text) to anon, authenticated;
