import { createClient } from 'jsr:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const DEFAULT_CATEGORIES = [
  { id: 'food', name: '餐饮', keywords: ['咖啡', '餐厅', '饭店', '外卖', '奶茶', '早餐', '午餐', '晚餐', '美团', '饿了么', '瑞幸', '星巴克'] },
  { id: 'transport', name: '交通', keywords: ['地铁', '公交', '滴滴', '出租', '打车', '高铁', '火车', '机票', '加油', '停车', '共享单车'] },
  { id: 'shopping', name: '购物', keywords: ['淘宝', '京东', '拼多多', '商城', '超市', '购物', '便利店', '天猫', '盒马', '山姆'] },
  { id: 'home', name: '居住', keywords: ['房租', '水电', '水费', '电费', '燃气', '物业', '宽带', '家居'] },
  { id: 'fun', name: '娱乐', keywords: ['电影', '游戏', '视频', '会员', '音乐', '演出', '门票', 'ktv'] },
  { id: 'health', name: '医疗', keywords: ['医院', '药店', '挂号', '体检', '医疗', '牙科', '诊所'] },
  { id: 'study', name: '学习', keywords: ['书店', '课程', '教育', '学费', '培训', '考试', '书'] },
  { id: 'social', name: '人情', keywords: ['红包', '礼物', '请客', '份子', '转账'] },
  { id: 'salary', name: '工资', keywords: ['工资', '薪水', '奖金', '报销', '兼职', '收入'] },
  { id: 'refund', name: '退款', keywords: ['退款', '退回', '返现', '退货'] },
  { id: 'other', name: '其他', keywords: [] },
];

type CategoryRule = { id: string; name: string; keywords: string[] };

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json; charset=utf-8' },
  });
}

function fail(error: string, status: number): Response {
  return json({ ok: false, error }, status);
}

function asText(value: unknown, maxLength: number): string {
  return typeof value === 'string' ? value.trim().slice(0, maxLength) : '';
}

async function sha256Hex(value: string): Promise<string> {
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value)));
  return Array.from(digest, (byte) => byte.toString(16).padStart(2, '0')).join('');
}

function beijingParts(date: Date): Record<string, string> {
  return Object.fromEntries(new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Shanghai',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(date).map((part) => [part.type, part.value]));
}

function beijingIso(date = new Date()): string {
  const parts = beijingParts(date);
  return `${parts.year}-${parts.month}-${parts.day}T${parts.hour}:${parts.minute}:${parts.second}+08:00`;
}

function normalizeCategory(value: unknown): CategoryRule[] {
  if (!Array.isArray(value)) return DEFAULT_CATEGORIES;
  const categories = value
    .filter((item): item is Record<string, unknown> => Boolean(item && typeof item === 'object'))
    .map((item) => ({
      id: asText(item.id, 80),
      name: asText(item.name, 80),
      keywords: Array.isArray(item.keywords) ? item.keywords.map((keyword) => asText(keyword, 80)).filter(Boolean).slice(0, 80) : [],
    }))
    .filter((item) => item.id && item.name)
    .slice(0, 80);
  return categories.length ? categories : DEFAULT_CATEGORIES;
}

function normalizeForHash(value: string): string {
  return value.toLowerCase().replace(/\s+/g, '').replace(/[，。！？、,.!?;；:：()（）\[\]【】]/g, '');
}

type AmountCandidate = { value: number; score: number; source: string };

function findAmount(text: string): { amount: number | null; score: number; ambiguous: boolean } {
  const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const candidates: AmountCandidate[] = [];
  const finalAmount = /(实付|实际支付|最终支付|付款金额|支付金额)/i;
  const strong = /(交易金额|订单金额|合计|总计|消费金额)/i;
  const medium = /(金额|消费|付款|支付)/i;
  const negative = /(余额|可用|额度|优惠|原价|已省|积分|红包|立减|折扣)/i;
  const currencyAmount = /[-−]?\s*[¥￥]\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)/g;

  for (const line of lines) {
    let baseScore = 0;
    if (finalAmount.test(line)) baseScore = 18;
    else if (strong.test(line)) baseScore = 11;
    else if (medium.test(line)) baseScore = 7;
    if (negative.test(line)) baseScore -= 12;
    const matches = Array.from(line.matchAll(currencyAmount));
    for (const match of matches) {
      const value = Number(match[1].replace(/,/g, ''));
      if (Number.isFinite(value) && value > 0 && value < 100_000_000) {
        candidates.push({ value, score: baseScore + (match[0].includes('-') || match[0].includes('−') ? 5 : 3), source: line });
      }
    }
    if (!matches.length && (strong.test(line) || medium.test(line))) {
      const numbers = Array.from(line.matchAll(/(?:^|[^0-9])([0-9][0-9,]*(?:\.[0-9]{1,2})?)(?![0-9])/g));
      for (const match of numbers) {
        const value = Number(match[1].replace(/,/g, ''));
        if (Number.isFinite(value) && value > 0 && value < 100_000_000) {
          candidates.push({ value, score: baseScore, source: line });
        }
      }
    }
  }

  candidates.sort((a, b) => b.score - a.score || b.value - a.value);
  const best = candidates[0];
  if (!best || best.score <= 0) return { amount: null, score: 0, ambiguous: false };
  const ambiguous = candidates.filter((candidate) => candidate.score >= best.score - 1 && candidate.value !== best.value).length > 0;
  return { amount: Math.round(best.value * 100) / 100, score: best.score, ambiguous };
}

function findLabeledValue(text: string, labelPattern: RegExp): string {
  const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  for (let index = 0; index < lines.length; index += 1) {
    const label = lines[index].match(labelPattern);
    if (!label) continue;
    const inline = lines[index].slice(label[0].length).replace(/^[：:\s]+/, '').trim();
    if (inline) return inline;
    const next = lines[index + 1];
    if (next && !/[:：]$/.test(next)) return next;
  }
  return '';
}

function findMerchant(text: string): { merchant: string; labeled: boolean } {
  const merchant = findLabeledValue(text, /(?:商户全称|商户名称|收款方|付款给|转账给|店铺名称|店铺|商家名称|商品名称|订单商家)\s*[：:]?/i);
  if (merchant) return { merchant: merchant.slice(0, 80), labeled: true };
  const excluded = /(微信支付|支付宝|支付成功|付款成功|交易成功|账单详情|订单详情|余额|银行卡|零钱|花呗|信用卡|云闪付|apple pay)/i;
  const fallback = text.split(/\r?\n/).map((line) => line.trim()).find((line) => line.length >= 2 && line.length <= 80 && !excluded.test(line) && !/[0-9]{2,}/.test(line));
  return { merchant: (fallback || '未命名账目').slice(0, 80), labeled: false };
}

function findSource(text: string, hint: string): string {
  if (hint) return hint.slice(0, 40);
  if (/apple\s*pay/i.test(text)) return 'Apple Pay';
  if (/云闪付/i.test(text)) return '云闪付';
  if (/支付宝|花呗|借呗/i.test(text)) return '支付宝';
  if (/微信支付|零钱|微信/i.test(text)) return '微信';
  if (/美团月付/i.test(text)) return '美团月付';
  if (/信用卡/i.test(text)) return '信用卡';
  if (/银行卡|储蓄卡|借记卡/i.test(text)) return '银行卡';
  if (/现金/i.test(text)) return '现金';
  return '未注明';
}

function findDirection(text: string): 'expense' | 'income' {
  if (/(退款|退回|返现|收入|收款到账|入账成功|到账)/i.test(text) && !/(付款成功|支付成功|消费|实付)/i.test(text)) return 'income';
  return 'expense';
}

function findOccurredAt(text: string, capturedAt: string): { occurredAt: string; found: boolean } {
  const full = text.match(/(20[0-9]{2})[-年/.](\d{1,2})[-月/.](\d{1,2})日?\s*(?:上午|下午)?\s*(\d{1,2})[:：](\d{2})/);
  const short = text.match(/(\d{1,2})月(\d{1,2})日\s*(?:上午|下午)?\s*(\d{1,2})[:：](\d{2})/);
  const now = beijingParts(new Date());
  let year = Number(now.year);
  let month = 0;
  let day = 0;
  let hour = 0;
  let minute = 0;
  let found = false;
  if (full) {
    year = Number(full[1]); month = Number(full[2]); day = Number(full[3]); hour = Number(full[4]); minute = Number(full[5]); found = true;
  } else if (short) {
    month = Number(short[1]); day = Number(short[2]); hour = Number(short[3]); minute = Number(short[4]); found = true;
  }
  if (found && month >= 1 && month <= 12 && day >= 1 && day <= 31 && hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59) {
    return { occurredAt: `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}T${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}:00+08:00`, found: true };
  }
  const parsedCapturedAt = capturedAt ? new Date(capturedAt) : new Date();
  return { occurredAt: beijingIso(Number.isNaN(parsedCapturedAt.getTime()) ? new Date() : parsedCapturedAt), found: false };
}

function findCategory(text: string, categories: CategoryRule[], direction: 'expense' | 'income'): { id: string; name: string; matched: boolean } {
  if (direction === 'income' && /退款|退回|返现/.test(text)) {
    const refund = categories.find((category) => category.id === 'refund' || category.name === '退款');
    if (refund) return { id: refund.id, name: refund.name, matched: true };
  }
  const haystack = normalizeForHash(text);
  let best: { category: CategoryRule; score: number } | null = null;
  for (const category of categories) {
    if (category.id === 'other') continue;
    let score = 0;
    if (haystack.includes(normalizeForHash(category.name))) score += 8;
    for (const keyword of category.keywords) {
      if (keyword && haystack.includes(normalizeForHash(keyword))) score += Math.max(2, Math.min(8, keyword.length));
    }
    if (!best || score > best.score) best = { category, score };
  }
  if (best && best.score > 0) return { id: best.category.id, name: best.category.name, matched: true };
  const other = categories.find((category) => category.id === 'other') ?? DEFAULT_CATEGORIES[DEFAULT_CATEGORIES.length - 1];
  return { id: other.id, name: other.name, matched: false };
}

Deno.serve(async (request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (request.method !== 'POST') return fail('method not allowed', 405);

  const authorization = request.headers.get('authorization') ?? '';
  const token = authorization.match(/^Bearer\s+(muse_[A-Za-z0-9_-]{20,})$/i)?.[1];
  if (!token) return fail('missing or invalid muse token', 401);
  if (Number(request.headers.get('content-length') ?? 0) > 32_768) return fail('payload too large', 413);

  let body: Record<string, unknown>;
  try { body = await request.json(); } catch { return fail('invalid JSON body', 400); }
  const rawText = asText(body.text, 12_000);
  if (!rawText) return fail('text is required', 400);

  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!supabaseUrl || !serviceRoleKey) return fail('server is not configured', 500);
  const admin = createClient(supabaseUrl, serviceRoleKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const tokenHash = await sha256Hex(token);
  const { data: tokenRow, error: tokenError } = await admin
    .from('shortcut_tokens')
    .select('user_id, scopes')
    .eq('token_hash', tokenHash)
    .eq('label', 'Muse AI 写入接口')
    .is('revoked_at', null)
    .maybeSingle();
  if (tokenError) return fail('could not validate muse token', 500);
  if (!tokenRow || !Array.isArray(tokenRow.scopes) || !tokenRow.scopes.includes('write')) return fail('invalid muse token', 401);

  const { data: snapshot } = await admin.from('ledger_snapshots').select('payload').eq('user_id', tokenRow.user_id).maybeSingle();
  const payload = snapshot?.payload && typeof snapshot.payload === 'object' ? snapshot.payload as Record<string, unknown> : {};
  const categories = normalizeCategory(payload.categories);

  const amountResult = findAmount(rawText);
  const merchantResult = findMerchant(rawText);
  const source = findSource(rawText, asText(body.sourceHint, 40));
  const direction = findDirection(rawText);
  const timeResult = findOccurredAt(rawText, asText(body.capturedAt, 50));
  const category = findCategory(`${merchantResult.merchant}\n${rawText}`, categories, direction);
  const repaymentLike = /(还款|已还清|自动还款|最低还款|信用卡账单|账单分期|花呗还款|白条还款|借呗还款)/i.test(rawText);
  const reviewReasons: string[] = [];
  if (amountResult.amount === null) reviewReasons.push('没有找到可靠金额');
  if (amountResult.ambiguous) reviewReasons.push('截图中有多个候选金额');
  if (!merchantResult.labeled) reviewReasons.push('商户不是明确标注字段');
  if (!timeResult.found) reviewReasons.push('没有识别到交易时间，已使用当前时间');
  if (repaymentLike) reviewReasons.push('疑似还款类截图，禁止自动入账');

  let confidence = 0;
  if (amountResult.amount !== null) confidence += amountResult.score >= 10 ? 0.38 : 0.26;
  if (merchantResult.labeled) confidence += 0.22;
  if (source !== '未注明') confidence += 0.15;
  if (timeResult.found) confidence += 0.12;
  if (category.matched) confidence += 0.08;
  if (amountResult.ambiguous) confidence -= 0.18;
  confidence = Math.round(Math.max(0, Math.min(0.98, confidence)) * 100) / 100;
  if (confidence < 0.72 && !reviewReasons.includes('识别置信度偏低')) reviewReasons.push('识别置信度偏低');
  const requiresReview = reviewReasons.length > 0;
  const idempotencyKey = `ocr-${(await sha256Hex(normalizeForHash(rawText))).slice(0, 40)}`;
  const writePayload = amountResult.amount === null ? null : {
    amount: amountResult.amount,
    direction,
    merchant: merchantResult.merchant,
    categoryId: category.id,
    occurredAt: timeResult.occurredAt,
    source,
    note: '',
    idempotencyKey,
  };

  if (writePayload && !requiresReview) {
    const { data, error } = await admin.rpc('muse_write_transaction', { p_token: token, p_payload: writePayload });
    if (error) {
      const status = error.code === '28000' ? 401 : error.code === '22023' ? 400 : 500;
      return fail(error.message, status);
    }
    return json({
      ok: true,
      written: true,
      duplicate: Boolean(data?.duplicate),
      requiresReview: false,
      reviewReasons: [],
      confidence,
      transaction: data?.transaction ?? writePayload,
      writePayload,
      reviewUrl: null,
    });
  }

  const { data: capture, error: captureError } = await admin.rpc('capture_shortcut', { p_token: token, p_text: rawText });
  if (captureError) return fail(captureError.message, captureError.code === '28000' ? 401 : 500);
  return json({
    ok: true,
    written: false,
    duplicate: false,
    requiresReview: true,
    reviewReasons,
    confidence,
    transaction: writePayload,
    writePayload,
    reviewUrl: capture?.review_url ?? null,
  });
});
