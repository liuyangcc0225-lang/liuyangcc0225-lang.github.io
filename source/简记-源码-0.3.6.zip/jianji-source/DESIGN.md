# Design

<!-- impeccable:design-schema 1 -->

## Visual World

Monochrome personal-finance control panel: white surfaces, soft off-white cards, large black numerals, simple line icons, and data views built from bars, rings, and a calendar heatmap. It should feel quiet, fast, and precise, with enough personality through typography and spacing rather than decoration.

The user pinned this direction by supplying reference screenshots from a minimal black-and-white iPhone bookkeeping app. We reproduce the visual grammar, not its brand assets or exact layouts.

## Visual Truth

- White or near-white page background with soft gray `#f2f2f2` cards.
- Black is the primary semantic color; gray is secondary information.
- Large rounded cards, generous internal spacing, and 20–28px radii.
- Charts use a grayscale ramp rather than saturated category colors.
- Data density is compact but not cramped; the eye lands on the number first.
- No paper texture, serif Chinese display faces, beige surfaces, or decorative red ledger lines.
- The app icon/mark is a black rounded square with a white character, paired with a clean sans-serif wordmark.

## Palette

- Canvas: `#ffffff`
- Surface: `#f2f2f2`
- Surface secondary: `#ededed`
- Ink: `#111111`
- Secondary text: `#858585`
- Muted text: `#a0a0a0`
- Rule: `#e6e6e6`
- Dark fill: `#111111`
- Error: `#b73535`
- No bright accent is required; action hierarchy comes from filled black vs gray.

## Typography

- Display and UI: `PingFang SC`, `Hiragino Sans GB`, `Noto Sans CJK SC`, `-apple-system`.
- Headings are bold sans-serif with tracking between `-0.03em` and `-0.05em` on large numerals.
- Amounts use tabular numerals and very large weight contrast.
- Avoid Kaiti, serif display, monospace costume, and gradient text.

## Composition

- Mobile app shell with a simple header: black app square, product name, date.
- Home starts with a soft-gray balance card and a grayscale daily bar chart.
- Shortcut automation is a compact card directly under the balance card.
- Category statistics combine a grayscale donut with a ranked list.
- Monthly ledger uses a rounded calendar heatmap with black intensity cells.
- Recent transactions remain plain rows, not nested cards.
- Bottom navigation is white, borderless, and uses simple black line icons.

## Components

- Balance card with a large signed amount and compact income/expense metadata.
- Seven-column daily bar chart; bars are charcoal, labels are light gray.
- Donut chart built from grayscale segments with a light center label.
- Calendar grid with white empty days and charcoal spend days.
- Category list rows with a small monochrome glyph, name, share, and amount.
- Filled black primary buttons with rounded rectangles; gray secondary buttons.
- Capture and review screens use the same gray card surfaces and black iconography.

## Interaction

- Primary buttons are black with a subtle lift; disabled states fade to gray.
- Page changes reset scroll and focus the heading.
- Modals trap focus, restore it on close, and lock background scroll.
- Charts use short, purposeful entrance transitions only; no shimmer or constant motion.
- Respect reduced-motion preferences.

## Privacy Language

- “原图不进入简记。”
- “快捷指令只传识别后的文字。”
- “截屏不进入相册 · 只传识别后的文字。”
- Avoid implying that the PWA can read screenshots directly from Shortcuts.

## Anti-patterns

- No beige paper, notebook lines, seals, or calligraphy.
- No bright multicolor category palette; categories use grayscale.
- No neon gradients, glassmorphism, oversized hero cards, or decorative glow.
- No emoji used as interface icons.
- No deeply nested cards or multiple competing chart treatments on the same surface.
