# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Stack

delegated: Vite + React + TypeScript PWA, with local IndexedDB storage and browser-side OCR. Chosen because the user explicitly requested a phone-browser PWA and an iPhone-first shortcut entry.

## Users

Primary user: a Chinese iPhone user who wants to record everyday spending quickly without opening a full finance app. The assumed core scene is: after paying, the user already has a payment screenshot, then uses a Shortcut or the installed PWA to capture it, verify a compact draft, and save the transaction. This user profile is inferred from the request because no fuller interview was available.

## Product Purpose

A private, fast, screenshot-first personal ledger. Success means a payment screenshot can become an editable transaction draft in a few seconds, with clear evidence, suggested category, duplicate warnings, and one-tap confirmation. The product is useful even before it has beautiful reports or cloud sync.

## Positioning

The mechanism is local-first screenshot recognition: OCR and parsing happen in the browser, the user always reviews the extracted fields, and corrections train the user's own category rules. It is not a bank-connection product, a notification scraper, or a dashboard-first finance app.

## Operating Context

- iPhone Safari and home-screen PWA are the first-class environment.
- A shortcut can open `/?capture=1` directly; users can also use the photo picker, camera, or clipboard image action.
- Most sessions are short, one-handed, and happen immediately after a payment.
- Connectivity is not guaranteed; core ledger and recognition should continue locally after assets are cached.
- The product must remain honest about iOS limits: a browser cannot silently capture screenshots or read other apps in the background.

## Capabilities and Constraints

Confirmed for the first build:

- Installable PWA with a custom manifest and service worker.
- Screenshot/image capture through file picker, camera, and clipboard paste where supported.
- Browser-side Chinese + English OCR using a bundled Tesseract.js pipeline.
- Extraction of amount, merchant/title, date/time, payment source, income/expense direction, and category candidates.
- Natural-language text entry as a fallback path.
- Editable confirmation sheet before saving.
- Category matching with user-created rules that improve from corrections.
- Duplicate detection based on amount + date proximity + merchant similarity.
- Local transaction ledger, category management, monthly totals, daily grouping, search, and CSV export/import.
- Offline data access and install guidance.

Explicit non-goals for the first build:

- No bank account connection, automatic notification listening, or screenshot monitoring.
- No mandatory account registration or cloud storage.
- No claim that iOS shortcuts can upload a screenshot without user interaction in a pure frontend build.
- No fake AI provider or hidden network calls.

## Brand Commitments

Working product name: 简记. The name is provisional, not a copied brand. The interface may learn from the clarity and restraint of compact ledger apps, but must not copy 简计's brand, illustrations, proprietary copy, or exact layouts.

## Evidence on Hand

- User request: an iPhone-first PWA inspired by the interaction quality of 简计.
- Prior product analysis: the useful mechanism is screenshot ➜ recognition ➜ category match ➜ review ➜ ledger.
- No real user transactions, testimonials, bank data, or proprietary assets are available. Demo content must be clearly marked as sample data.

## Product Principles

1. Capture first, analysis second. The next transaction must always be faster to finish than the last.
2. Recognition is a draft, not truth. Show what was inferred and make correction effortless.
3. Local by default. Private financial data stays on the device unless the user explicitly exports it.
4. Use familiar ledger language. Amount, merchant, date, source, note, and category should read like a real account book.
5. Do not imitate native powers the web does not have. Explain shortcut limits honestly and design the best available flow.

## Accessibility & Inclusion

- Mobile-first, one-handed controls with a minimum 44px touch target.
- Strong contrast and no color-only status encoding.
- Chinese-first copy with a clear numeric hierarchy and tabular numerals.
- Keyboard navigation and visible focus states for desktop testing.
- Reduced-motion support.
