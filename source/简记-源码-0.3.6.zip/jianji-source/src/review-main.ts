import type { Category, Direction } from './types';
import { DEFAULT_CATEGORIES } from './categories';
import { beijingDateTimeToIso, parseTransactionText, toDateTimeInput } from './parser';

const SUPABASE_URL = (import.meta.env.VITE_SUPABASE_URL ?? '').trim();
const SUPABASE_KEY = (import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ?? import.meta.env.VITE_SUPABASE_ANON_KEY ?? '').trim();

type CapturePayload = { capture_id: string; raw_text: string; created_at: string; categories: Category[] };
const params = new URLSearchParams(window.location.search);
const captureId = params.get('capture') ?? '';
const reviewToken = params.get('token') ?? '';
const form = document.querySelector<HTMLFormElement>('#review-form')!;
const status = document.querySelector<HTMLElement>('#review-status')!;
const errorBox = document.querySelector<HTMLElement>('#review-error')!;
const result = document.querySelector<HTMLElement>('#review-result')!;
const resultTitle = document.querySelector<HTMLElement>('#result-title')!;
const resultCopy = document.querySelector<HTMLElement>('#result-copy')!;
const merchantInput = document.querySelector<HTMLInputElement>('#merchant')!;
const categorySelect = document.querySelector<HTMLSelectElement>('#category')!;
const amountInput = document.querySelector<HTMLInputElement>('#amount')!;
const directionSelect = document.querySelector<HTMLSelectElement>('#direction')!;
const sourceInput = document.querySelector<HTMLInputElement>('#source')!;
const noteInput = document.querySelector<HTMLInputElement>('#note')!;
const occurredInput = document.querySelector<HTMLInputElement>('#occurred-at')!;
const confirmButton = document.querySelector<HTMLButtonElement>('#confirm')!;
const skipButton = document.querySelector<HTMLButtonElement>('#skip')!;

async function rpc<T>(name: string, body: Record<string, unknown>): Promise<T> {
  if (!SUPABASE_URL || !SUPABASE_KEY) throw new Error('云同步尚未配置');
  const response = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${name}`, {
    method: 'POST',
    headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const text = await response.text();
  let payload: unknown = null;
  try { payload = text ? JSON.parse(text) : null; } catch { payload = text; }
  if (!response.ok) {
    const message = typeof payload === 'object' && payload && 'message' in payload
      ? String((payload as { message: unknown }).message)
      : text;
    throw new Error(message || '请求失败');
  }
  return payload as T;
}

function usableCategories(value: unknown): Category[] {
  if (!Array.isArray(value)) return DEFAULT_CATEGORIES;
  const categories = value.filter((item): item is Category => Boolean(item && typeof item === 'object' && 'id' in item && 'name' in item));
  return categories.length ? categories : DEFAULT_CATEGORIES;
}

function showError(message: string) {
  status.textContent = '无法读取';
  errorBox.textContent = message;
  errorBox.hidden = false;
  form.hidden = true;
  resultTitle.textContent = '核对链接不可用';
  resultCopy.textContent = '链接可能已过期、已被使用，或快捷指令令牌不匹配。';
  result.hidden = false;
  resultTitle.focus();
}

function showCompleted(title: string, copy: string) {
  form.hidden = true;
  result.hidden = false;
  status.textContent = '已完成';
  resultTitle.textContent = title;
  resultCopy.textContent = copy;
  resultTitle.focus();
}

async function init() {
  if (!captureId || !reviewToken) { showError('缺少一次性核验参数'); return; }
  try {
    const payload = await rpc<CapturePayload>('get_shortcut_capture', { p_capture_id: captureId, p_review_token: reviewToken });
    const categories = usableCategories(payload.categories);
    const draft = parseTransactionText(payload.raw_text, categories, new Date(payload.created_at), 'ocr');
    categorySelect.replaceChildren(...categories.map((category) => {
      const option = document.createElement('option');
      option.value = category.id;
      option.textContent = category.name;
      option.selected = category.id === draft.categoryId;
      return option;
    }));
    merchantInput.value = draft.merchant;
    amountInput.value = draft.amount === null ? '' : String(draft.amount);
    directionSelect.value = draft.direction;
    sourceInput.value = draft.source;
    noteInput.value = draft.note;
    occurredInput.value = toDateTimeInput(draft.occurredAt);
    status.textContent = '可修改';
    form.hidden = false;
    amountInput.focus();
  } catch (error) {
    showError(error instanceof Error ? error.message : '无法读取识别结果');
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  errorBox.hidden = true;
  confirmButton.disabled = true;
  skipButton.disabled = true;
  const amount = Number(amountInput.value);
  if (!Number.isFinite(amount) || amount <= 0) {
    errorBox.textContent = '请输入有效金额';
    errorBox.hidden = false;
    confirmButton.disabled = false;
    skipButton.disabled = false;
    return;
  }
  try {
    await rpc('save_shortcut_capture', {
      p_capture_id: captureId,
      p_review_token: reviewToken,
      p_amount: amount,
      p_direction: directionSelect.value as Direction,
      p_merchant: merchantInput.value.trim(),
      p_category_id: categorySelect.value,
      p_occurred_at: beijingDateTimeToIso(occurredInput.value),
      p_source: sourceInput.value.trim(),
      p_note: noteInput.value.trim(),
    });
    showCompleted('已记入简记', '下次打开简记时会自动同步这笔账目。');
  } catch (error) {
    errorBox.textContent = error instanceof Error ? error.message : '保存失败';
    errorBox.hidden = false;
    confirmButton.disabled = false;
    skipButton.disabled = false;
  }
});

skipButton.addEventListener('click', async () => {
  skipButton.disabled = true;
  try {
    await rpc('skip_shortcut_capture', { p_capture_id: captureId, p_review_token: reviewToken });
    showCompleted('已跳过', '这条识别结果不会记入账页。');
  } catch (error) {
    errorBox.textContent = error instanceof Error ? error.message : '操作失败';
    errorBox.hidden = false;
    skipButton.disabled = false;
  }
});

void init();
