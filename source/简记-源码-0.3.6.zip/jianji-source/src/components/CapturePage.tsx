import { useRef, useState } from 'react';
import { ArrowLeft, ClipboardPaste, Keyboard, LockKeyhole, ScanLine, ShieldCheck } from 'lucide-react';
import type { CaptureStage } from '../types';
import { imageFromPasteEvent } from '../ocr';

type Props = {
  stage: CaptureStage;
  progress: number;
  status: string;
  error: string;
  onBack: () => void;
  onReadClipboard: () => void;
  onPasteImage: (blob: Blob) => void;
  onTextDraft: (text: string) => void;
};

export default function CapturePage({ stage, progress, status, error, onBack, onReadClipboard, onPasteImage, onTextDraft }: Props) {
  const [mode, setMode] = useState<'clipboard' | 'text'>('clipboard');
  const [text, setText] = useState('');
  const [pasteHint, setPasteHint] = useState('长按这里，选择“粘贴”');
  const pasteRef = useRef<HTMLDivElement>(null);
  const busy = stage === 'reading' || stage === 'ocr' || stage === 'parsing';

  function handlePaste(event: React.ClipboardEvent<HTMLDivElement>) {
    const blob = imageFromPasteEvent(event.nativeEvent as ClipboardEvent);
    if (blob) {
      event.preventDefault();
      setPasteHint('已读取剪贴板图片');
      onPasteImage(blob);
    } else {
      setPasteHint('这里没有图片，请确认快捷指令已复制截屏');
    }
  }

  return (
    <main className="page capture-page">
      <header className="page-top compact-top">
        <button type="button" className="icon-button" onClick={onBack} aria-label="返回"><ArrowLeft size={21} /></button>
        <div>
          <p className="brand-line">简记 <span>CAPTURE</span></p>
          <h1>识别一笔。</h1>
        </div>
        <span className="header-spacer" />
      </header>

      <section className={`scan-sheet ${busy ? 'is-busy' : ''}`} aria-live="polite">
        <div className="scan-sheet-top">
          <span className="scan-badge"><ScanLine size={15} /> {busy ? '正在识别' : '等待截图'}</span>
          <span className="privacy-line compact"><LockKeyhole size={13} /> 不存原图</span>
        </div>

        {mode === 'clipboard' ? (
          <>
            <div className="scan-tray" onClick={() => pasteRef.current?.focus()}>
              <div className="scan-corner top-left" />
              <div className="scan-corner top-right" />
              <div className="scan-corner bottom-left" />
              <div className="scan-corner bottom-right" />
              <div className="scan-tray-icon"><ClipboardPaste size={30} strokeWidth={1.6} /></div>
              <strong>{busy ? status || '正在处理截屏' : '把支付截图放进这里'}</strong>
              <span>快捷指令截屏 → 复制到剪贴板 → 打开简记</span>
              <div
                ref={pasteRef}
                className="paste-target"
                contentEditable={!busy}
                role="textbox"
                aria-label="粘贴截图区域"
                suppressContentEditableWarning
                onPaste={handlePaste}
                onFocus={() => setPasteHint('在 iPhone 上长按后选择“粘贴”')}
              >
                {pasteHint}
              </div>
            </div>

            {busy ? (
              <div className="scan-progress">
                <div className="scan-progress-label"><span>{status || '读取截图中'}</span><span>{Math.round(progress * 100)}%</span></div>
                <div className="progress-track"><i style={{ transform: `scaleX(${Math.max(0.04, Math.min(1, progress))})` }} /></div>
                <div className="scan-steps">
                  <span className={progress > 0.02 ? 'done' : ''}>读取剪贴板</span>
                  <span className={progress > 0.1 ? 'done' : ''}>文字识别</span>
                  <span className={progress >= 0.96 ? 'done' : ''}>生成账单草稿</span>
                </div>
              </div>
            ) : (
              <button type="button" className="primary-stamp" onClick={onReadClipboard}>
                <ClipboardPaste size={18} /> 读取剪贴板截图
              </button>
            )}

            {error ? <div className="inline-error" role="alert">{error}</div> : null}
            <p className="microcopy">如果按钮无法读取剪贴板，请点开上方粘贴区，长按后选择“粘贴”。这是 iOS Safari 的安全限制。</p>
          </>
        ) : (
          <div className="text-draft">
            <div className="text-draft-heading"><Keyboard size={20} /><div><strong>直接描述这一笔</strong><span>没有截图时，也可以用一句话记账。</span></div></div>
            <textarea
              value={text}
              onChange={(event) => setText(event.target.value)}
              placeholder="例如：今天午餐花了 28 元，微信支付"
              rows={5}
              autoFocus
            />
            <button type="button" className="primary-stamp" disabled={!text.trim()} onClick={() => onTextDraft(text)}>生成账单草稿</button>
          </div>
        )}

        <button type="button" className="mode-switch" onClick={() => setMode(mode === 'clipboard' ? 'text' : 'clipboard')}>
          {mode === 'clipboard' ? <><Keyboard size={16} /> 改成文字描述</> : <><ClipboardPaste size={16} /> 回到截图识别</>}
        </button>
      </section>

      <aside className="privacy-panel">
        <div><ShieldCheck size={19} /></div>
        <p><strong>这是一块只读内存托盘。</strong><br />图片不会写入相册、IndexedDB 或 localStorage。识别结束后只保留你确认过的金额、商户和分类。</p>
      </aside>
    </main>
  );
}
