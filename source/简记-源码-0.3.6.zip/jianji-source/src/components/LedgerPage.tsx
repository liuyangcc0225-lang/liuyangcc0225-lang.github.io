import { useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, Download, Search, X } from 'lucide-react';
import type { Category, Transaction } from '../types';
import { beijingDateKey, formatDayLabel, formatMoney, getBeijingDateParts } from '../parser';
import LedgerRow from './LedgerRow';

type Props = {
  transactions: Transaction[];
  categories: Category[];
  onOpenTransaction: (transaction: Transaction) => void;
  onExport: () => void;
};

type Filter = 'all' | 'expense' | 'income';

export default function LedgerPage({ transactions, categories, onOpenTransaction, onExport }: Props) {
  const [monthOffset, setMonthOffset] = useState(0);
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<Filter>('all');
  const [sourceFilter, setSourceFilter] = useState('all');
  const anchor = useMemo(() => {
    const now = getBeijingDateParts();
    const date = new Date(Date.UTC(now.year, now.month - 1 + monthOffset, 1));
    return { year: date.getUTCFullYear(), month: date.getUTCMonth() + 1 };
  }, [monthOffset]);
  const monthLabel = `${anchor.year} 年 ${anchor.month} 月`;

  const sources = useMemo(() => {
    const values = new Set<string>();
    for (const transaction of transactions) {
      const date = getBeijingDateParts(transaction.occurredAt);
      if (date.year === anchor.year && date.month === anchor.month && transaction.source.trim()) values.add(transaction.source.trim());
    }
    return [...values].sort((a, b) => a.localeCompare(b, 'zh-CN'));
  }, [anchor, transactions]);

  const trend = useMemo(() => {
    const now = getBeijingDateParts();
    return Array.from({ length: 6 }, (_, index) => {
      const date = new Date(Date.UTC(now.year, now.month - 1 - (5 - index), 1));
      const year = date.getUTCFullYear();
      const month = date.getUTCMonth() + 1;
      let expense = 0;
      let income = 0;
      for (const transaction of transactions) {
        const parts = getBeijingDateParts(transaction.occurredAt);
        if (parts.year !== year || parts.month !== month) continue;
        if (transaction.direction === 'expense') expense += transaction.amount;
        else income += transaction.amount;
      }
      return { key: `${year}-${month}`, label: `${month}月`, expense, income };
    });
  }, [transactions]);
  const expenseMax = Math.max(...trend.map((item) => item.expense), 1);
  const incomeMax = Math.max(...trend.map((item) => item.income), 1);

  const rows = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return transactions
      .filter((transaction) => {
        const date = getBeijingDateParts(transaction.occurredAt);
        if (date.year !== anchor.year || date.month !== anchor.month) return false;
        if (filter !== 'all' && transaction.direction !== filter) return false;
        if (sourceFilter !== 'all' && transaction.source !== sourceFilter) return false;
        if (!normalized) return true;
        return `${transaction.merchant} ${transaction.note} ${transaction.source}`.toLowerCase().includes(normalized);
      })
      .sort((a, b) => new Date(b.occurredAt).getTime() - new Date(a.occurredAt).getTime());
  }, [transactions, anchor, filter, sourceFilter, query]);

  const expense = rows.filter((item) => item.direction === 'expense').reduce((sum, item) => sum + item.amount, 0);
  const income = rows.filter((item) => item.direction === 'income').reduce((sum, item) => sum + item.amount, 0);

  const groups = useMemo(() => {
    const map = new Map<string, Transaction[]>();
    for (const transaction of rows) {
      const key = beijingDateKey(transaction.occurredAt);
      const list = map.get(key) ?? [];
      list.push(transaction);
      map.set(key, list);
    }
    return Array.from(map.entries());
  }, [rows]);

  return (
    <main className="page ledger-page">
      <header className="page-top">
        <div>
          <p className="brand-line">简记 <span>LEDGER</span></p>
          <h1>整页账本。</h1>
        </div>
        <button type="button" className="icon-button" onClick={onExport} aria-label="导出 CSV"><Download size={19} /></button>
      </header>

      <div className="month-switcher">
        <button type="button" className="icon-button" onClick={() => setMonthOffset((value) => value - 1)} aria-label="上个月"><ChevronLeft size={19} /></button>
        <button type="button" className="month-label" onClick={() => setMonthOffset(0)}>{monthLabel}<span>{monthOffset === 0 ? '本月' : '回到本月'}</span></button>
        <button type="button" className="icon-button" onClick={() => setMonthOffset((value) => value + 1)} aria-label="下个月"><ChevronRight size={19} /></button>
      </div>

      <section className="monthly-trend-card" aria-label="近六个月收支趋势">
        <div className="monthly-trend-heading"><div><strong>近 6 月趋势</strong><span>支出与收入</span></div><div className="trend-legend"><span><i className="expense" />支出</span><span><i className="income" />收入</span></div></div>
        <div className="monthly-trend-chart">
          {trend.map((item) => (
            <div className="monthly-trend-column" key={item.key} title={`${item.label}：支 ¥${formatMoney(item.expense)} / 收 ¥${formatMoney(item.income)}`}>
              <span className="monthly-trend-value">{item.expense ? Math.round(item.expense) : ''}</span>
              <div className="monthly-trend-bars">
                <i className="expense" style={{ height: `${item.expense ? Math.max(5, (item.expense / expenseMax) * 100) : 2}%` }} />
                <i className="income" style={{ height: `${item.income ? Math.max(5, (item.income / incomeMax) * 100) : 2}%` }} />
              </div>
              <small>{item.label}</small>
            </div>
          ))}
        </div>
      </section>

      <div className="ledger-total-line">
        <span>支出 <strong>¥{formatMoney(expense)}</strong></span>
        <span>收入 <strong className="income-text">¥{formatMoney(income)}</strong></span>
        <span>结余 <strong>{expense > income ? '−' : '+'}¥{formatMoney(Math.abs(income - expense))}</strong></span>
      </div>

      <div className="ledger-filter-bar">
        <label className="search-field">
          <Search size={17} />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索商家、备注或支付方式" />
        </label>
        <label className="source-filter-field">
          <span>支付方式</span>
          <select value={sourceFilter} onChange={(event) => setSourceFilter(event.target.value)}>
            <option value="all">全部方式</option>
            {sources.map((source) => <option value={source} key={source}>{source}</option>)}
          </select>
        </label>
        {(query || sourceFilter !== 'all' || filter !== 'all') ? (
          <button type="button" className="clear-ledger-filters" onClick={() => { setQuery(''); setSourceFilter('all'); setFilter('all'); }} aria-label="清空筛选"><X size={15} /></button>
        ) : null}
      </div>

      <div className="filter-tabs" role="tablist" aria-label="收支筛选">
        {([['all', '全部'], ['expense', '支出'], ['income', '收入']] as const).map(([id, label]) => (
          <button type="button" role="tab" aria-selected={filter === id} className={filter === id ? 'is-active' : ''} key={id} onClick={() => setFilter(id)}>{label}</button>
        ))}
      </div>

      {groups.length ? (
        <div className="ledger-groups">
          {groups.map(([key, items]) => {
            const dayLabel = formatDayLabel(items[0].occurredAt);
            const dayExpense = items.filter((item) => item.direction === 'expense').reduce((sum, item) => sum + item.amount, 0);
            const dayIncome = items.filter((item) => item.direction === 'income').reduce((sum, item) => sum + item.amount, 0);
            const daySummary = dayExpense && dayIncome
              ? `收 ¥${formatMoney(dayIncome)} · 支 ¥${formatMoney(dayExpense)}`
              : dayIncome
                ? `收 +¥${formatMoney(dayIncome)}`
                : `支 ¥${formatMoney(dayExpense)}`;
            return (
              <section className="ledger-day" key={key}>
                <div className="day-rule"><span>{dayLabel}</span><span>{daySummary}</span></div>
                <div className="ledger-list">
                  {items.map((transaction) => <LedgerRow key={transaction.id} transaction={transaction} categories={categories} onClick={onOpenTransaction} />)}
                </div>
              </section>
            );
          })}
        </div>
      ) : (
        <div className="empty-ledger">
          <p className="empty-ledger-number">空白页</p>
          <strong>这个月还没有找到记录。</strong>
          <span>换个月份、清空搜索，或者从截屏记下第一笔。</span>
        </div>
      )}
    </main>
  );
}
