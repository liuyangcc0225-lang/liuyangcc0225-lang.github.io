import { useMemo, useState } from 'react';
import { AlertTriangle, ArrowLeft, Check, ChevronDown, CircleHelp, PencilLine, ScanText, ShieldCheck } from 'lucide-react';
import type { Category, Draft, DuplicateMatch } from '../types';
import { categoryById } from '../categories';
import { beijingDateTimeToIso, formatMoney, toDateTimeInput } from '../parser';
import { CategoryGlyph } from './CategoryGlyph';

type Props = {
  draft: Draft;
  categories: Category[];
  duplicate: DuplicateMatch | null;
  onBack: () => void;
  onConfirm: (draft: Draft) => void;
};

function confidenceLabel(value: number): string {
  if (value >= 0.82) return '把握较大';
  if (value >= 0.58) return '需要核对';
  return '信息较少';
}

export default function ReviewPage({ draft, categories, duplicate, onBack, onConfirm }: Props) {
  const [form, setForm] = useState<Draft>(draft);
  const [showRaw, setShowRaw] = useState(false);
  const amountValue = form.amount === null ? '' : String(form.amount);
  const selectedCategory = categoryById(categories, form.categoryId);
  const canSave = form.amount !== null && form.amount > 0 && form.merchant.trim().length > 0;
  const candidateCategories = useMemo(() => form.categoryCandidates.slice(0, 4), [form.categoryCandidates]);

  function update<K extends keyof Draft>(key: K, value: Draft[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!canSave) return;
    onConfirm({ ...form, merchant: form.merchant.trim(), note: form.note.trim() });
  }

  return (
    <main className="page review-page">
      <header className="page-top compact-top">
        <button type="button" className="icon-button" onClick={onBack} aria-label="返回识别"><ArrowLeft size={21} /></button>
        <div>
          <p className="brand-line">简记 <span>CHECK</span></p>
          <h1>核对这一笔。</h1>
        </div>
        <span className={`confidence-stamp ${form.confidence >= 0.82 ? 'high' : form.confidence >= 0.58 ? 'mid' : 'low'}`}>
          {confidenceLabel(form.confidence)}
        </span>
      </header>

      <form onSubmit={submit} className="review-form">
        <section className={`receipt-draft ${form.sourceType === 'ocr' ? 'from-ocr' : ''}`}>
          <div className="receipt-notch left" /><div className="receipt-notch right" />
          <div className="receipt-head">
            <span className="receipt-label"><ScanText size={15} /> {form.sourceType === 'ocr' ? '截图识别草稿' : form.sourceType === 'text' ? '文字草稿' : '手动账目'}</span>
            <span className="receipt-confidence">置信度 {Math.round(form.confidence * 100)}%</span>
          </div>

          <label className="field-label" htmlFor="merchant">商户 / 摘要</label>
          <input id="merchant" className="merchant-input" value={form.merchant} onChange={(event) => update('merchant', event.target.value)} placeholder="这一笔是给谁的" autoComplete="off" />

          <div className="amount-editor">
            <span className="currency-symbol">¥</span>
            <input
              aria-label="金额"
              className="amount-input"
              type="number"
              inputMode="decimal"
              min="0"
              step="0.01"
              value={amountValue}
              onChange={(event) => update('amount', event.target.value === '' ? null : Number(event.target.value))}
              placeholder="0.00"
            />
            <div className="direction-toggle" role="group" aria-label="收支方向">
              <button type="button" className={form.direction === 'expense' ? 'is-active' : ''} onClick={() => update('direction', 'expense')}>支出</button>
              <button type="button" className={form.direction === 'income' ? 'is-active income' : ''} onClick={() => update('direction', 'income')}>收入</button>
            </div>
          </div>

          <div className="field-row">
            <label>
              <span className="field-label">时间</span>
              <input type="datetime-local" value={toDateTimeInput(form.occurredAt)} onChange={(event) => update('occurredAt', beijingDateTimeToIso(event.target.value))} />
            </label>
            <label>
              <span className="field-label">支付方式</span>
              <input value={form.source} onChange={(event) => update('source', event.target.value)} placeholder="微信 / 支付宝 / 银行卡" />
            </label>
          </div>

          <label>
            <span className="field-label">备注（可选）</span>
            <input value={form.note} onChange={(event) => update('note', event.target.value)} placeholder="给未来的自己留一句话" />
          </label>
        </section>

        {duplicate ? (
          <div className="duplicate-alert" role="alert">
            <AlertTriangle size={19} />
            <div><strong>可能是重复账单</strong><span>{duplicate.reason}：{duplicate.transaction.merchant} · ¥{formatMoney(duplicate.transaction.amount)}</span></div>
          </div>
        ) : null}

        <section className="section-block review-category">
          <div className="section-heading">
            <h2>归到哪一页？</h2>
            <span>当前：{selectedCategory.name}</span>
          </div>
          <div className="category-chip-row" role="listbox" aria-label="选择分类">
            {categories.map((category) => (
              <button
                type="button"
                key={category.id}
                role="option"
                aria-selected={category.id === form.categoryId}
                className={`category-chip ${category.id === form.categoryId ? 'is-selected' : ''}`}
                onClick={() => update('categoryId', category.id)}
                style={{ '--chip-color': category.color } as React.CSSProperties}
              >
                <CategoryGlyph category={category} size={16} />{category.name}
              </button>
            ))}
          </div>
          {candidateCategories.some((candidate) => candidate.score > 0) ? (
            <div className="suggestion-note">
              <PencilLine size={15} />
              <span>识别建议：{candidateCategories.filter((candidate) => candidate.score > 0).map((candidate) => categoryById(categories, candidate.id).name).join(' / ')}</span>
            </div>
          ) : null}
        </section>

        <section className="evidence-block">
          <div className="evidence-heading"><CircleHelp size={16} /><strong>识别依据</strong><span>金额、商户和时间都可以直接改</span></div>
          {form.evidence.length ? (
            <ul>{form.evidence.map((item, index) => <li key={`${item}-${index}`}>{item}</li>)}</ul>
          ) : <p>没有找到明确的识别依据，请手动核对。</p>}
          <button type="button" className="raw-toggle" onClick={() => setShowRaw((value) => !value)}>
            查看 OCR 原文 <ChevronDown size={15} className={showRaw ? 'rotate' : ''} />
          </button>
          {showRaw ? <pre>{form.rawText || '没有 OCR 文本'}</pre> : null}
        </section>

        <div className="privacy-footnote"><ShieldCheck size={16} /><span>截图未保存；这里只会写入你确认后的账目字段。</span></div>

        <div className="sticky-action-bar">
          <button type="button" className="secondary-button" onClick={onBack}>放弃</button>
          <button type="submit" className="primary-stamp save-stamp" disabled={!canSave}><Check size={18} /> 记入账页</button>
        </div>
      </form>
    </main>
  );
}
