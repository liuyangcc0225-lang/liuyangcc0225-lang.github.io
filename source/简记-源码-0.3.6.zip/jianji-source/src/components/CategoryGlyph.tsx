import type { LucideIcon } from 'lucide-react';
import {
  Baby,
  BookOpen,
  Briefcase,
  BusFront,
  CarFront,
  CircleDollarSign,
  Coffee,
  Dumbbell,
  Gamepad2,
  Gift,
  GraduationCap,
  HeartPulse,
  House,
  PawPrint,
  Plane,
  RotateCcw,
  Shapes,
  ShoppingBag,
  Tag,
  Utensils,
  WalletCards,
  Wrench,
} from 'lucide-react';
import type { Category } from '../types';

export const CATEGORY_ICON_OPTIONS: { id: string; label: string; Icon: LucideIcon }[] = [
  { id: 'tag', label: '标签', Icon: Tag },
  { id: 'utensils', label: '餐饮', Icon: Utensils },
  { id: 'coffee', label: '咖啡', Icon: Coffee },
  { id: 'shopping-bag', label: '购物', Icon: ShoppingBag },
  { id: 'bus-front', label: '公交', Icon: BusFront },
  { id: 'car-front', label: '汽车', Icon: CarFront },
  { id: 'house', label: '居住', Icon: House },
  { id: 'gamepad-2', label: '娱乐', Icon: Gamepad2 },
  { id: 'heart-pulse', label: '健康', Icon: HeartPulse },
  { id: 'book-open', label: '学习', Icon: BookOpen },
  { id: 'gift', label: '礼物', Icon: Gift },
  { id: 'wallet-cards', label: '收入', Icon: WalletCards },
  { id: 'rotate-ccw', label: '退款', Icon: RotateCcw },
  { id: 'paw-print', label: '宠物', Icon: PawPrint },
  { id: 'plane', label: '旅行', Icon: Plane },
  { id: 'dumbbell', label: '运动', Icon: Dumbbell },
  { id: 'briefcase', label: '工作', Icon: Briefcase },
  { id: 'wrench', label: '维修', Icon: Wrench },
  { id: 'baby', label: '家庭', Icon: Baby },
  { id: 'graduation-cap', label: '教育', Icon: GraduationCap },
  { id: 'circle-dollar-sign', label: '金钱', Icon: CircleDollarSign },
  { id: 'shapes', label: '其他', Icon: Shapes },
];

const ICONS = new Map(CATEGORY_ICON_OPTIONS.map((option) => [option.id, option.Icon]));
const SHORT_FALLBACK: Record<string, string> = {
  餐: 'utensils',
  行: 'bus-front',
  购: 'shopping-bag',
  住: 'house',
  娱: 'gamepad-2',
  医: 'heart-pulse',
  学: 'book-open',
  人: 'gift',
  薪: 'wallet-cards',
  退: 'rotate-ccw',
  其: 'shapes',
};
const ID_FALLBACK: Record<string, string> = {
  food: 'utensils',
  transport: 'bus-front',
  shopping: 'shopping-bag',
  home: 'house',
  fun: 'gamepad-2',
  health: 'heart-pulse',
  study: 'book-open',
  social: 'gift',
  salary: 'wallet-cards',
  refund: 'rotate-ccw',
  other: 'shapes',
};

export function resolveCategoryIcon(category: Category): LucideIcon {
  return ICONS.get(category.icon ?? '') ?? ICONS.get(ID_FALLBACK[category.id] ?? '') ?? ICONS.get(SHORT_FALLBACK[category.short] ?? '') ?? Tag;
}

export function CategoryGlyph({ category, size = 18, className = '' }: { category: Category; size?: number; className?: string }) {
  const Icon = resolveCategoryIcon(category);
  return <Icon size={size} strokeWidth={1.9} className={className} aria-hidden="true" />;
}