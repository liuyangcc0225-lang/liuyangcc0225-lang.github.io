import { useEffect, useMemo, useRef, useState } from 'react';
import { AlertTriangle, ArrowRight, Check, ChevronRight, ClipboardCopy, Info, ScanLine, X } from 'lucide-react';
import type { Category, Transaction } from '../types';
import { categoryById } from '../categories';
import { beijingDateKey, formatFullDate, formatMoney, getBeijingDateParts } from '../parser';
import LedgerRow, { CategoryMark } from './LedgerRow';

type Props = {
  transactions: Transaction[];
  categories: Category[];

  onOpenLedger: () => void;
  onOpenTransaction: (transaction: Transaction) => void;
  onOpenSettings: () => void;
};

const GRAY_SCALE = ['#111111', '#4f4f4f', '#7b7b7b', '#a8a8a8', '#d0d0d0'];
const WEEKDAYS = ['一', '二', '三', '四', '五', '六', '日'];

function ShortcutHelpSheet({ template, onClose }: { template: string; onClose: () => void }) {
  const [copied, setCopied] = useState(false);
  const dialogRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const dialog = dialogRef.current;
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const background = document.querySelector<HTMLElement>('.desk-surface');
    const navigation = document.querySelector<HTMLElement>('.bottom-nav');
    const previousOverflow = document.body.style.overflow;
    background?.setAttribute('inert', '');
    navigation?.setAttribute('inert', '');
    document.body.style.overflow = 'hidden';
    const focusables = () => Array.from(dialog?.querySelectorAll<HTMLElement>('button:not([disabled]), [href], [tabindex]:not([tabindex="-1"])') ?? []);
    window.requestAnimationFrame(() => focusables()[0]?.focus());

    function onKey(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        event.preventDefault();
        onClose();
        return;
      }
      if (event.key !== 'Tab') return;
      const items = focusables();
      if (!items.length) return;
      const first = items[0];
      const last = items[items.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }

    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('keydown', onKey);
      background?.removeAttribute('inert');
      navigation?.removeAttribute('inert');
      document.body.style.overflow = previousOverflow;
      previousFocus?.focus({ preventScroll: true });
    };
  }, [onClose]);

  async function copyTemplate() {
    try {
      await navigator.clipboard.writeText(template);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  }

  return (
    <div className="sheet-backdrop" role="presentation" onMouseDown={(event) => { if (event.currentTarget === event.target) onClose(); }}>
      <section ref={dialogRef} className="shortcut-help-sheet" role="dialog" aria-modal="true" aria-labelledby="shortcut-help-title" tabIndex={-1}>
        <div className="sheet-drag-handle" aria-hidden="true" />
        <header className="shortcut-help-head">
          <div className="shortcut-help-mark"><ScanLine size={22} /></div>
          <div><h2 id="shortcut-help-title">快捷指令自动记账</h2><p>在 iPhone 快捷指令里运行简记，截屏只在系统内识别。</p></div>
          <button type="button" className="icon-button" onClick={onClose} aria-label="关闭"><X size={19} /></button>
        </header>
        <div className="shortcut-help-status"><Check size={17} /><span><strong>自动记账已接入</strong><small>识别后自动入账，低置信度时进入核对</small></span></div>
        <span className="shortcut-url-label">快捷指令写入地址</span>
        <div className="url-box" id="shortcut-template"><code>{template}</code></div>
        <p className="shortcut-help-privacy">只传识别后的文字；原图不进入简记，也不写入相册或服务器。</p>
        <div className="shortcut-help-actions">
          <button type="button" className="secondary-button" onClick={() => void copyTemplate()}>
            {copied ? <Check size={16} /> : <ClipboardCopy size={16} />} {copied ? '地址已复制' : '复制地址'}
          </button>
          <button type="button" className="primary-stamp compact" onClick={onClose}>完成</button>
        </div>
      </section>
    </div>
  );
}

function monthTransactions(transactions: Transaction[]) {
  const now = getBeijingDateParts();
  return transactions.filter((transaction) => {
    const date = getBeijingDateParts(transaction.occurredAt);
    return date.year === now.year && date.month === now.month;
  });
}

function DailyBars({ transactions }: { transactions: Transaction[] }) {
  const days = useMemo(() => {
    const now = getBeijingDateParts();
    return Array.from({ length: 7 }, (_, index) => {
      const date = new Date(Date.UTC(now.year, now.month - 1, now.day));
      date.setUTCDate(date.getUTCDate() - (6 - index));
      const key = `${date.getUTCFullYear()}-${date.getUTCMonth() + 1}-${date.getUTCDate()}`;
      const total = transactions
        .filter((transaction) => beijingDateKey(transaction.occurredAt) === key && transaction.direction === 'expense')
        .reduce((sum, transaction) => sum + transaction.amount, 0);
      return { label: String(date.getUTCDate()).padStart(2, '0'), total };
    });
  }, [transactions]);
  const max = Math.max(...days.map((day) => day.total), 1);
  return (
    <div className="daily-bars" aria-label="最近七天支出柱状图">
      {days.map((day) => (
        <div className="daily-bar-column" key={day.label}>
          <span className="daily-bar-value">{day.total ? Math.round(day.total) : ''}</span>
          <div className="daily-bar-track"><i style={{ height: `${day.total ? Math.max(8, (day.total / max) * 100) : 4}%` }} /></div>
          <span className="daily-bar-label">{day.label}</span>
        </div>
      ))}
    </div>
  );
}

function CalendarHeatmap({ transactions }: { transactions: Transaction[] }) {
  const now = getBeijingDateParts();
  const year = now.year;
  const month = now.month;
  const firstWeekday = (new Date(Date.UTC(year, month - 1, 1)).getUTCDay() + 6) % 7;
  const days = new Date(Date.UTC(year, month, 0)).getUTCDate();
  const totals = new Map<number, number>();
  for (const transaction of transactions) {
    const date = getBeijingDateParts(transaction.occurredAt);
    if (date.year === year && date.month === month && transaction.direction === 'expense') {
      totals.set(date.day, (totals.get(date.day) ?? 0) + transaction.amount);
    }
  }
  const max = Math.max(...Array.from(totals.values()), 1);
  return (
    <div className="calendar-heatmap">
      <div className="calendar-weekdays">{WEEKDAYS.map((day) => <span key={day}>{day}</span>)}</div>
      <div className="calendar-grid">
        {Array.from({ length: firstWeekday }).map((_, index) => <span className="calendar-empty" key={`empty-${index}`} />)}
        {Array.from({ length: days }, (_, index) => {
          const day = index + 1;
          const total = totals.get(day) ?? 0;
          const intensity = total ? 0.22 + (total / max) * 0.72 : 0;
          return (
            <div
              className={`calendar-cell ${total ? 'has-spend' : ''} ${intensity > 0.56 ? 'is-dark' : ''}`}
              key={day}
              style={total ? ({ '--heat': intensity } as React.CSSProperties) : undefined}
            >
              <strong>{day}</strong>
              {total ? <small>{Math.round(total)}</small> : <small className="muted">—</small>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

type CategoryTotal = { category: Category; total: number; count: number };
type VisibleCategoryTotal = CategoryTotal & { containedCount?: number; members?: CategoryTotal[] };

function CategoryOverview({ transactions, categories, onOpenTransaction }: { transactions: Transaction[]; categories: Category[]; onOpenTransaction: (transaction: Transaction) => void }) {
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const totals = categories.map((category) => {
    const items = transactions.filter((item) => item.direction === 'expense' && item.categoryId === category.id);
    return { category, total: items.reduce((sum, item) => sum + item.amount, 0), count: items.length };
  }).filter((item) => item.total > 0).sort((a, b) => b.total - a.total);
  const total = totals.reduce((sum, item) => sum + item.total, 0);
  const scale = total || 1;
  const top = totals.filter((item) => item.category.id !== 'other').slice(0, 4);
  const topIds = new Set(top.map((item) => item.category.id));
  const rest = totals.filter((item) => !topIds.has(item.category.id));
  const groupedTotal = rest.reduce((sum, item) => sum + item.total, 0);
  const grouped: VisibleCategoryTotal | null = totals.length > 5 && rest.length ? {
    category: { id: 'grouped-rest', name: '其他分类', short: '其', color: '#bdbdbd', keywords: [] },
    total: groupedTotal,
    count: rest.reduce((sum, item) => sum + item.count, 0),
    containedCount: rest.length,
    members: rest,
  } : null;
  const visible: VisibleCategoryTotal[] = grouped ? [
    ...top,
    grouped,
  ] : totals;
  const expanded: VisibleCategoryTotal | null = expandedId === grouped?.category.id
    ? grouped
    : totals.find((item) => item.category.id === expandedId) ?? null;
  const expandedTransactions = expanded
    ? transactions
      .filter((item) => item.direction === 'expense' && (expanded.members ? expanded.members.some((member) => member.category.id === item.categoryId) : item.categoryId === expanded.category.id))
      .sort((a, b) => new Date(b.occurredAt).getTime() - new Date(a.occurredAt).getTime())
    : [];
  let cursor = 0;
  const gradient = visible.map((item, index) => {
    const start = cursor;
    const end = cursor + (item.total / scale) * 100;
    cursor = end;
    return `${GRAY_SCALE[index]} ${start}% ${end}%`;
  }).join(', ');
  return (
    <section className="overview-card category-overview-card">
      <div className="card-heading"><h2>分类统计</h2><span>{totals.length} 类</span></div>
      <div className="category-overview-body">
        <div className="donut-wrap">
          <div className="donut-chart" style={{ background: `conic-gradient(${gradient || '#e6e6e6 0% 100%'})` }}>
            <div className="donut-center"><strong>¥{formatMoney(total)}</strong><span>本月支出</span></div>
          </div>
        </div>
        <div className="category-ranking">
          {visible.map((item, index) => (
            <button
              type="button"
              className={`category-rank-row ${expanded?.category.id === item.category.id ? 'is-open' : ''}`}
              key={item.category.id}
              aria-expanded={expanded?.category.id === item.category.id}
              aria-controls="category-detail"
              onClick={() => setExpandedId((current) => current === item.category.id ? null : item.category.id)}
            >
              <span className="rank-dot" style={{ background: GRAY_SCALE[index] }} />
              <span className="rank-name">
                {item.category.name}
                {'containedCount' in item ? <small>{item.containedCount} 项合并</small> : null}
              </span>
              <span className="rank-percent">{((item.total / total) * 100).toFixed(0)}%</span>
              <strong>¥{formatMoney(item.total)}</strong>
              <ChevronRight className="rank-chevron" size={13} aria-hidden="true" />
            </button>
          ))}
        </div>
      </div>
      {expanded ? (
        <div className="category-detail" id="category-detail">
          <div className="category-detail-head">
            <div><strong>{expanded.category.name}明细</strong><span>{expanded.count} 笔 · 均 ¥{formatMoney(expanded.total / Math.max(1, expanded.count))}</span></div>
            <button type="button" className="icon-button" onClick={() => setExpandedId(null)} aria-label="收起分类明细"><X size={16} /></button>
          </div>
          {expanded.members?.length ? (
            <div className="category-detail-breakdown" aria-label="合并分类构成">
              {expanded.members.map((member) => (
                <button type="button" key={member.category.id} onClick={() => setExpandedId(member.category.id)}>
                  <span>{member.category.name}</span><strong>¥{formatMoney(member.total)}</strong><ChevronRight size={12} />
                </button>
              ))}
            </div>
          ) : null}
          <div className="category-detail-list">
            {expandedTransactions.map((transaction) => (
              <button type="button" className="category-detail-row" key={transaction.id} onClick={() => onOpenTransaction(transaction)}>
                <span className="category-detail-date">{new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', month: 'numeric', day: 'numeric' }).format(new Date(transaction.occurredAt))}</span>
                <span className="category-detail-copy"><strong>{transaction.merchant || '未命名账目'}</strong><small>{categoryById(categories, transaction.categoryId).name} · {transaction.source || '未填写支付方式'}</small></span>
                <b>−¥{formatMoney(transaction.amount)}</b>
              </button>
            ))}
          </div>
        </div>
      ) : null}
    </section>
  );
}

function BudgetReminder({ transactions, categories }: { transactions: Transaction[]; categories: Category[] }) {
  const alerts = categories
    .filter((category) => (category.monthlyBudget ?? 0) > 0)
    .map((category) => {
      const spent = transactions
        .filter((transaction) => transaction.direction === 'expense' && transaction.categoryId === category.id)
        .reduce((sum, transaction) => sum + transaction.amount, 0);
      const budget = category.monthlyBudget ?? 0;
      return { category, spent, budget, percent: budget > 0 ? (spent / budget) * 100 : 0 };
    })
    .filter((item) => item.percent >= 80)
    .sort((a, b) => b.percent - a.percent);

  if (!alerts.length) return null;
  return (
    <section className="budget-reminder-card" aria-label="分类预算提醒">
      <div className="budget-reminder-heading"><AlertTriangle size={17} /><strong>预算提醒</strong><span>{alerts.length} 个分类</span></div>
      <div className="budget-reminder-list">
        {alerts.slice(0, 4).map(({ category, spent, budget, percent }) => (
          <div className={`budget-reminder-row ${percent >= 100 ? 'is-over' : 'is-near'}`} key={category.id}>
            <CategoryMark category={category} small />
            <div>
              <span><strong>{category.name}</strong><small>{percent >= 100 ? '已超预算' : '接近预算'}</small></span>
              <div className="budget-progress"><i style={{ width: `${Math.min(100, percent)}%` }} /></div>
            </div>
            <b>{Math.round(percent)}%</b>
            <em>¥{formatMoney(spent)} / ¥{formatMoney(budget)}</em>
          </div>
        ))}
      </div>
    </section>
  );
}

export default function HomePage({ transactions, categories, onOpenLedger, onOpenTransaction, onOpenSettings }: Props) {
  const [shortcutHelpOpen, setShortcutHelpOpen] = useState(false);
  const now = getBeijingDateParts();
  const month = monthTransactions(transactions);
  const expense = month.filter((item) => item.direction === 'expense').reduce((sum, item) => sum + item.amount, 0);
  const income = month.filter((item) => item.direction === 'income').reduce((sum, item) => sum + item.amount, 0);
  const recent = transactions.slice(0, 4);
  const sampleCount = transactions.filter((item) => item.isSample).length;
  const dateLabel = formatFullDate(new Date());
  const shortcutTemplate = `${window.location.origin}${import.meta.env.BASE_URL}?capture=auto&text=编码后的文本&auto=1`;

  return (
    <main className="page home-page monochrome-home">
      <header className="home-header">
        <div className="app-logo" aria-hidden="true">简</div>
        <div className="home-header-copy"><h1>简记</h1><span>极简 · 快捷 · 自动</span></div>
        <span className="home-date">{dateLabel}</span>
      </header>

      {sampleCount ? (
        <button type="button" className="sample-banner" onClick={onOpenSettings}>
          <Info size={15} />
          <span>当前包含 {sampleCount} 笔示例账目，仅用于预览；去设置可清除</span>
          <ChevronRight size={15} />
        </button>
      ) : null}

      <section className="overview-card balance-card">
        <div className="card-heading"><h2>本月结余</h2><button type="button" className="card-link" onClick={onOpenLedger}>全部 <ArrowRight size={15} /></button></div>
        <div className="balance-number">{income >= expense ? '+' : '−'}¥{formatMoney(Math.abs(income - expense))}</div>
        <div className="balance-meta">
          <span>支出 <strong>¥{formatMoney(expense)}</strong></span>
          <span>收入 <strong>¥{formatMoney(income)}</strong></span>
          <span>{month.length} 笔</span>
        </div>
        <DailyBars transactions={transactions} />
      </section>

      <div className="home-actions">
        <button type="button" className="shortcut-card" onClick={() => setShortcutHelpOpen(true)}>
          <span className="shortcut-icon"><ScanLine size={22} /></span>
          <span><strong>快捷指令自动记账</strong><small>查看接入方式与写入地址</small></span>
          <ChevronRight size={18} />
        </button>

      </div>

      <CategoryOverview transactions={month} categories={categories} onOpenTransaction={onOpenTransaction} />

      <BudgetReminder transactions={month} categories={categories} />

      <section className="overview-card calendar-card">
        <div className="card-heading"><h2>{now.month} 月账页</h2><span>每日支出</span></div>
        <CalendarHeatmap transactions={transactions} />
      </section>

      <section className="overview-card recent-card">
        <div className="card-heading"><h2>最近记录</h2><button type="button" className="card-link" onClick={onOpenLedger}>查看全部 <ArrowRight size={14} /></button></div>
        <div className="monochrome-ledger-list">
          {recent.length ? recent.map((transaction) => (
            <LedgerRow key={transaction.id} transaction={transaction} categories={categories} onClick={onOpenTransaction} showDate />
          )) : <p className="empty-inline">还没有记录，先运行一次快捷指令吧。</p>}
        </div>
      </section>
      {shortcutHelpOpen ? <ShortcutHelpSheet template={shortcutTemplate} onClose={() => setShortcutHelpOpen(false)} /> : null}
    </main>
  );
}
