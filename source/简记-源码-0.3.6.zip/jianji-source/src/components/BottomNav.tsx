import { BookOpenText, Settings2, Tags } from 'lucide-react';

export type AppView = 'home' | 'capture' | 'ledger' | 'categories' | 'settings';

type Props = {
  active: AppView;
  onChange: (view: AppView) => void;
};

const items = [
  { id: 'home' as const, label: '账页', icon: BookOpenText },
  { id: 'categories' as const, label: '分类', icon: Tags },
  { id: 'settings' as const, label: '设置', icon: Settings2 },
];

export default function BottomNav({ active, onChange }: Props) {
  return (
    <nav className="bottom-nav" aria-label="主导航">
      {items.map((item) => {
        const Icon = item.icon;
        const selected = active === item.id;
        return (
          <button
            key={item.id}
            type="button"
            className={`nav-tab ${selected ? 'is-active' : ''}`}
            aria-current={selected ? 'page' : undefined}
            onClick={() => onChange(item.id)}
          >
            <Icon size={21} strokeWidth={selected ? 2.2 : 1.8} aria-hidden="true" />
            <span>{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
}
