import { useEffect, useRef, useState } from 'react';
import { Check, Trash2, X } from 'lucide-react';
import type { Category, Transaction } from '../types';
import { CategoryGlyph } from './CategoryGlyph';
import { categoryById } from '../categories';
import { beijingDateTimeToIso, toDateTimeInput } from '../parser';

type Props = {
  transaction: Transaction;
  categories: Category[];
  onClose: () => void;
  onSave: (transaction: Transaction) => void;
  onDelete: (transaction: Transaction) => void;
};

type ViewportMetrics = { height: number; offsetTop: number };

function readViewportMetrics(): ViewportMetrics {
  const viewport = window.visualViewport;
  return {
    height: Math.max(240, Math.round(viewport?.height ?? window.innerHeight)),
    offsetTop: Math.max(0, Math.round(viewport?.offsetTop ?? 0)),
  };
}

export default function TransactionSheet({ transaction, categories, onClose, onSave, onDelete }: Props) {
  const [form, setForm] = useState(transaction);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [amountText, setAmountText] = useState(String(transaction.amount));
  const [viewport, setViewport] = useState<ViewportMetrics>(readViewportMetrics);
  const dialogRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const dialog = dialogRef.current;
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const background = document.querySelector<HTMLElement>('.desk-surface');
    const navigation = document.querySelector<HTMLElement>('.bottom-nav');
    const previousOverflow = document.body.style.overflow;
    background?.setAttribute('inert', '');
    navigation?.setAttribute('inert', '');
    document.body.style.overflow = 'hidden';

    const focusables = () => Array.from(dialog?.querySelectorAll<HTMLElement>('button:not([disabled]), input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [href], [tabindex]:not([tabindex="-1"])') ?? []);
    const first = focusables()[0];
    window.requestAnimationFrame(() => first?.focus());

    function onKey(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        event.preventDefault();
        onClose();
        return;
      }
      if (event.key !== 'Tab') return;
      const items = focusables();
      if (!items.length) return;
      const firstItem = items[0];
      const lastItem = items[items.length - 1];
      if (event.shiftKey && document.activeElement === firstItem) {
        event.preventDefault();
        lastItem.focus();
      } else if (!event.shiftKey && document.activeElement === lastItem) {
        event.preventDefault();
        firstItem.focus();
      }
    }

    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('keydown', onKey);
      background?.removeAttribute('inert');
      navigation?.removeAttribute('inert');
      document.body.style.overflow = previousOverflow;
      previousFocus?.focus({ preventScroll: true });
    };
  }, [onClose]);

  useEffect(() => {
    const visualViewport = window.visualViewport;
    let frame = 0;
    const update = () => {
      window.cancelAnimationFrame(frame);
      frame = window.requestAnimationFrame(() => setViewport(readViewportMetrics()));
    };
    update();
    visualViewport?.addEventListener('resize', update);
    visualViewport?.addEventListener('scroll', update);
    window.addEventListener('resize', update);
    return () => {
      window.cancelAnimationFrame(frame);
      visualViewport?.removeEventListener('resize', update);
      visualViewport?.removeEventListener('scroll', update);
      window.removeEventListener('resize', update);
    };
  }, []);

  const keyboardOpen = viewport.height < window.innerHeight - 100;

  useEffect(() => {
    const active = document.activeElement;
    if (!keyboardOpen || !dialogRef.current?.contains(active)) return;
    if (!(active instanceof HTMLInputElement || active instanceof HTMLTextAreaElement || active instanceof HTMLSelectElement)) return;
    const timer = window.setTimeout(() => {
      active.scrollIntoView({ block: 'center', inline: 'nearest' });
    }, 180);
    return () => window.clearTimeout(timer);
  }, [keyboardOpen, viewport.height]);

  function save() {
    const amount = Number(amountText);
    if (!Number.isFinite(amount) || amount <= 0) return;
    onSave({ ...form, amount, merchant: form.merchant.trim() || '未命名账目', note: form.note.trim() });
  }

  return (
    <div
      className={`sheet-backdrop ${keyboardOpen ? 'is-keyboard-open' : ''}`}
      role="presentation"
      style={{ '--sheet-viewport-height': `${viewport.height}px`, '--sheet-viewport-top': `${viewport.offsetTop}px` } as React.CSSProperties}
      onMouseDown={(event) => { if (event.currentTarget === event.target) onClose(); }}
    >
      <section
        ref={dialogRef}
        className="transaction-sheet"
        role="dialog"
        aria-modal="true"
        aria-labelledby="transaction-sheet-title"
        tabIndex={-1}
        onFocusCapture={(event) => {
          const target = event.target;
          if (!(target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target instanceof HTMLSelectElement)) return;
          window.setTimeout(() => target.scrollIntoView({ block: 'center', inline: 'nearest' }), keyboardOpen ? 60 : 260);
        }}
      >
        <div className="sheet-drag-handle" aria-hidden="true" />
        <header className="sheet-title-row">
          <div><p className="sheet-kicker">账目详情</p><h2 id="transaction-sheet-title">{categoryById(categories, form.categoryId).name} · {form.source}</h2></div>
          <button type="button" className="icon-button" onClick={onClose} aria-label="关闭"><X size={19} /></button>
        </header>

        <label className="field-label" htmlFor="edit-merchant">商户 / 摘要</label>
        <input id="edit-merchant" className="merchant-input" value={form.merchant} onChange={(event) => setForm({ ...form, merchant: event.target.value })} />

        <div className="amount-editor compact-editor">
          <span className="currency-symbol">¥</span>
          <input aria-label="金额" className="amount-input" type="number" inputMode="decimal" step="0.01" min="0" value={amountText} onChange={(event) => setAmountText(event.target.value)} />
          <div className="direction-toggle">
            <button type="button" className={form.direction === 'expense' ? 'is-active' : ''} onClick={() => setForm({ ...form, direction: 'expense' })}>支出</button>
            <button type="button" className={form.direction === 'income' ? 'is-active income' : ''} onClick={() => setForm({ ...form, direction: 'income' })}>收入</button>
          </div>
        </div>

        <div className="field-row">
          <label><span className="field-label">时间</span><input type="datetime-local" value={toDateTimeInput(form.occurredAt)} onChange={(event) => setForm({ ...form, occurredAt: beijingDateTimeToIso(event.target.value) })} /></label>
          <label><span className="field-label">支付方式</span><input value={form.source} onChange={(event) => setForm({ ...form, source: event.target.value })} /></label>
        </div>

        <span className="field-label">分类</span>
        <div className="category-chip-row compact-chips">
          {categories.map((category) => (
            <button type="button" key={category.id} className={`category-chip ${form.categoryId === category.id ? 'is-selected' : ''}`} style={{ '--chip-color': category.color } as React.CSSProperties} onClick={() => setForm({ ...form, categoryId: category.id })}>
              <CategoryGlyph category={category} size={16} />{category.name}
            </button>
          ))}
        </div>

        <label><span className="field-label">备注</span><input value={form.note} onChange={(event) => setForm({ ...form, note: event.target.value })} placeholder="补充说明" /></label>

        <div className="sheet-actions">
          {confirmDelete ? (
            <div className="delete-confirm">
              <span>确定删除这笔？</span>
              <button type="button" className="text-button danger-text" onClick={() => onDelete(form)}>删除</button>
              <button type="button" className="text-button" onClick={() => setConfirmDelete(false)}>取消</button>
            </div>
          ) : (
            <button type="button" className="secondary-button danger" onClick={() => setConfirmDelete(true)}><Trash2 size={16} /> 删除</button>
          )}
          <button type="button" className="primary-stamp compact" onClick={save}><Check size={16} /> 保存修改</button>
        </div>
      </section>
    </div>
  );
}
