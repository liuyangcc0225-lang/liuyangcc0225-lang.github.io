import { ChevronRight } from 'lucide-react';
import type { Category, Transaction } from '../types';
import { formatMoney, formatShortDate, formatTime } from '../parser';
import { categoryById } from '../categories';
import { CategoryGlyph } from './CategoryGlyph';

export function CategoryMark({ category, small = false }: { category: Category; small?: boolean }) {
  return (
    <span
      className={`category-mark ${small ? 'is-small' : ''}`}
      style={{ '--mark-color': category.color } as React.CSSProperties}
      aria-hidden="true"
    >
      <CategoryGlyph category={category} size={small ? 16 : 19} />
    </span>
  );
}

type Props = {
  transaction: Transaction;
  categories: Category[];
  onClick: (transaction: Transaction) => void;
  showDate?: boolean;
};

export default function LedgerRow({ transaction, categories, onClick, showDate = false }: Props) {
  const category = categoryById(categories, transaction.categoryId);
  const sign = transaction.direction === 'income' ? '+' : '−';
  return (
    <button type="button" className="ledger-row" onClick={() => onClick(transaction)}>
      <CategoryMark category={category} />
      <span className="ledger-row-main">
        <span className="ledger-row-title">
          {transaction.merchant}
          {transaction.isSample ? <span className="sample-mark">示例</span> : null}
        </span>
        <span className="ledger-row-meta">
          {category.name}
          <span className="meta-dot">·</span>
          {transaction.source}
          {showDate ? <><span className="meta-dot">·</span>{formatShortDate(transaction.occurredAt)}</> : null}
        </span>
      </span>
      <span className="ledger-row-side">
        <span className={`ledger-amount ${transaction.direction}`}>{sign}¥{formatMoney(transaction.amount)}</span>
        <span className="ledger-time">{formatTime(transaction.occurredAt)}</span>
      </span>
      <ChevronRight size={15} className="ledger-chevron" aria-hidden="true" />
    </button>
  );
}
