import { createClient, type Session, type User } from '@supabase/supabase-js';
import type { Category, Transaction } from './types';

const SUPABASE_URL = (import.meta.env.VITE_SUPABASE_URL ?? '').trim();
const SUPABASE_KEY = (import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ?? import.meta.env.VITE_SUPABASE_ANON_KEY ?? '').trim();
export const cloudPublishableKey = SUPABASE_KEY;
const TOMBSTONE_KEY = 'jianji-cloud-tombstones-v1';

export const cloudConfigured = Boolean(SUPABASE_URL && SUPABASE_KEY);

export const cloudClient = cloudConfigured
  ? createClient(SUPABASE_URL, SUPABASE_KEY, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
      },
    })
  : null;

export type CloudSnapshot = {
  version: 1;
  transactions: Transaction[];
  categories: Category[];
  deletedTransactionIds: string[];
  deletedCategoryIds: string[];
  savedAt: string;
};

export type CloudTombstones = {
  transactions: string[];
  categories: string[];
};

export type CloudUser = Pick<User, 'id' | 'email'>;

export type RemoteSnapshot = {
  payload: CloudSnapshot;
  updatedAt: string;
};

const EMPTY_TOMBSTONES: CloudTombstones = { transactions: [], categories: [] };

function uniqueStrings(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.filter((item): item is string => typeof item === 'string' && item.length > 0))];
}

function normalizeSnapshot(value: unknown): CloudSnapshot {
  const source = value && typeof value === 'object' ? value as Partial<CloudSnapshot> : {};
  return {
    version: 1,
    transactions: Array.isArray(source.transactions) ? source.transactions.filter((item): item is Transaction => Boolean(item?.id)) : [],
    categories: Array.isArray(source.categories) ? source.categories.filter((item): item is Category => Boolean(item?.id)) : [],
    deletedTransactionIds: uniqueStrings(source.deletedTransactionIds),
    deletedCategoryIds: uniqueStrings(source.deletedCategoryIds),
    savedAt: typeof source.savedAt === 'string' ? source.savedAt : new Date(0).toISOString(),
  };
}

export function loadTombstones(): CloudTombstones {
  try {
    const parsed = JSON.parse(localStorage.getItem(TOMBSTONE_KEY) ?? 'null') as Partial<CloudTombstones> | null;
    return {
      transactions: uniqueStrings(parsed?.transactions),
      categories: uniqueStrings(parsed?.categories),
    };
  } catch {
    return { ...EMPTY_TOMBSTONES };
  }
}

export function saveTombstones(tombstones: CloudTombstones): void {
  localStorage.setItem(TOMBSTONE_KEY, JSON.stringify({
    transactions: uniqueStrings(tombstones.transactions),
    categories: uniqueStrings(tombstones.categories),
  }));
}

export function rememberDeletedTransaction(id: string): void {
  const tombstones = loadTombstones();
  tombstones.transactions = uniqueStrings([...tombstones.transactions, id]);
  saveTombstones(tombstones);
}

export function rememberDeletedCategory(id: string): void {
  const tombstones = loadTombstones();
  tombstones.categories = uniqueStrings([...tombstones.categories, id]);
  saveTombstones(tombstones);
}

export function buildSnapshot(transactions: Transaction[], categories: Category[], tombstones = loadTombstones()): CloudSnapshot {
  return {
    version: 1,
    transactions: transactions.filter((transaction) => !transaction.isSample),
    categories,
    deletedTransactionIds: uniqueStrings(tombstones.transactions),
    deletedCategoryIds: uniqueStrings(tombstones.categories),
    savedAt: new Date().toISOString(),
  };
}

type TimedRecord = { id: string; updatedAt?: string; createdAt?: string };

function recordTime(record: TimedRecord): number {
  const value = 'updatedAt' in record && record.updatedAt
    ? record.updatedAt
    : 'createdAt' in record && record.createdAt
      ? record.createdAt
      : '';
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function mergeRecords<T extends TimedRecord>(local: T[], remote: T[]): T[] {
  const merged = new Map<string, T>();
  for (const item of remote) merged.set(item.id, item);
  for (const item of local) {
    const existing = merged.get(item.id);
    if (!existing || recordTime(item) >= recordTime(existing)) merged.set(item.id, item);
  }
  return [...merged.values()];
}

export function mergeSnapshots(local: CloudSnapshot, remote?: CloudSnapshot | null): CloudSnapshot {
  const deletedTransactionIds = new Set([...(remote?.deletedTransactionIds ?? []), ...local.deletedTransactionIds]);
  const deletedCategoryIds = new Set([...(remote?.deletedCategoryIds ?? []), ...local.deletedCategoryIds]);
  const transactions = mergeRecords(
    local.transactions.filter((item) => !item.isSample && !deletedTransactionIds.has(item.id)),
    (remote?.transactions ?? []).filter((item) => !item.isSample && !deletedTransactionIds.has(item.id)),
  ).sort((a, b) => new Date(b.occurredAt).getTime() - new Date(a.occurredAt).getTime());
  const categories = mergeRecords(
    local.categories.filter((item) => !deletedCategoryIds.has(item.id)),
    (remote?.categories ?? []).filter((item) => !deletedCategoryIds.has(item.id)),
  );

  return {
    version: 1,
    transactions,
    categories,
    deletedTransactionIds: [...deletedTransactionIds],
    deletedCategoryIds: [...deletedCategoryIds],
    savedAt: new Date().toISOString(),
  };
}

export function snapshotFingerprint(snapshot: CloudSnapshot): string {
  return JSON.stringify({
    transactions: snapshot.transactions,
    categories: snapshot.categories,
    deletedTransactionIds: [...snapshot.deletedTransactionIds].sort(),
    deletedCategoryIds: [...snapshot.deletedCategoryIds].sort(),
  });
}

export async function getCloudSession(): Promise<Session | null> {
  if (!cloudClient) return null;
  const { data, error } = await cloudClient.auth.getSession();
  if (error) throw error;
  return data.session;
}

export function onCloudAuthChange(callback: (session: Session | null) => void): () => void {
  if (!cloudClient) return () => undefined;
  const { data } = cloudClient.auth.onAuthStateChange((_event, session) => callback(session));
  return () => data.subscription.unsubscribe();
}

export async function signInToCloud(email: string, password: string): Promise<CloudUser> {
  if (!cloudClient) throw new Error('云同步尚未配置');
  const { data, error } = await cloudClient.auth.signInWithPassword({ email: email.trim(), password });
  if (error) throw error;
  if (!data.user) throw new Error('登录失败，请稍后再试');
  return data.user;
}

export async function signUpForCloud(email: string, password: string): Promise<{ user: CloudUser | null; needsConfirmation: boolean }> {
  if (!cloudClient) throw new Error('云同步尚未配置');
  const emailRedirectTo = `${window.location.origin}${import.meta.env.BASE_URL}`;
  const { data, error } = await cloudClient.auth.signUp({ email: email.trim(), password, options: { emailRedirectTo } });
  if (error) throw error;
  return { user: data.user, needsConfirmation: !data.session };
}

export async function signOutOfCloud(): Promise<void> {
  if (!cloudClient) return;
  const { error } = await cloudClient.auth.signOut();
  if (error) throw error;
}

export async function pullCloudSnapshot(userId: string): Promise<RemoteSnapshot | null> {
  if (!cloudClient) throw new Error('云同步尚未配置');
  const { data, error } = await cloudClient
    .from('ledger_snapshots')
    .select('payload, updated_at')
    .eq('user_id', userId)
    .maybeSingle();
  if (error) throw error;
  if (!data) return null;
  return { payload: normalizeSnapshot(data.payload), updatedAt: data.updated_at };
}

export async function pushCloudSnapshot(userId: string, snapshot: CloudSnapshot): Promise<string> {
  if (!cloudClient) throw new Error('云同步尚未配置');
  const savedAt = new Date().toISOString();
  const payload = { ...snapshot, savedAt };
  const { data, error } = await cloudClient
    .from('ledger_snapshots')
    .upsert({ user_id: userId, payload, updated_at: savedAt }, { onConflict: 'user_id' })
    .select('updated_at')
    .single();
  if (error) throw error;
  return data.updated_at;
}

export function subscribeToCloudSnapshot(userId: string, onChange: () => void): () => void {
  if (!cloudClient) return () => undefined;
  const channel = cloudClient
    .channel(`ledger-snapshot-${userId}`)
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'ledger_snapshots', filter: `user_id=eq.${userId}` },
      onChange,
    )
    .subscribe();
  return () => {
    void cloudClient.removeChannel(channel);
  };
}

export function cloudErrorMessage(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error ?? '');
  if (/invalid login credentials/i.test(message)) return '邮箱或密码错误';
  if (/email not confirmed/i.test(message)) return '请先打开邮箱里的验证邮件';
  if (/already registered|already exists/i.test(message)) return '该邮箱已经注册，请直接登录';
  if (/password/i.test(message) && /least/i.test(message)) return '密码长度至少需要 6 位';
  if (/rate limit|too many|only request this after/i.test(message)) return '邮件发送过于频繁，请稍后再试';
  if (/fetch|network|failed to fetch/i.test(message)) return '无法连接 Supabase，请检查网络';
  return message || '云同步操作失败';
}
export const shortcutCaptureEndpoint = SUPABASE_URL ? `${SUPABASE_URL}/rest/v1/rpc/capture_shortcut` : '';
export const museWriteEndpoint = SUPABASE_URL ? `${SUPABASE_URL}/functions/v1/muse-write` : '';
export const museVisionEndpoint = SUPABASE_URL ? `${SUPABASE_URL}/functions/v1/muse-vision` : '';
export const museOcrEndpoint = SUPABASE_URL ? `${SUPABASE_URL}/functions/v1/muse-ocr` : '';
const SHORTCUT_TOKEN_PREFIX = 'jianji-shortcut-token-';
const MUSE_TOKEN_PREFIX = 'jianji-muse-write-token-';
const SHORTCUT_TOKEN_LABEL = '简记无跳转快捷指令';
const MUSE_TOKEN_LABEL = 'Muse AI 写入接口';

function base64Url(bytes: Uint8Array): string {
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

async function sha256Hex(value: string): Promise<string> {
  const bytes = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

export function getSavedShortcutToken(userId: string): string {
  return localStorage.getItem(`${SHORTCUT_TOKEN_PREFIX}${userId}`) ?? '';
}

export async function createShortcutToken(userId: string): Promise<string> {
  if (!cloudClient) throw new Error('云同步尚未配置');
  const random = crypto.getRandomValues(new Uint8Array(32));
  const token = `jj_${base64Url(random)}`;
  const { error } = await cloudClient.from('shortcut_tokens').insert({
    user_id: userId,
    token_hash: await sha256Hex(token),
    label: SHORTCUT_TOKEN_LABEL,
  });
  if (error) throw error;
  localStorage.setItem(`${SHORTCUT_TOKEN_PREFIX}${userId}`, token);
  return token;
}

export async function revokeShortcutTokens(userId: string): Promise<void> {
  if (!cloudClient) return;
  const { error } = await cloudClient.from('shortcut_tokens').delete().eq('user_id', userId).eq('label', SHORTCUT_TOKEN_LABEL);
  if (error) throw error;
  localStorage.removeItem(`${SHORTCUT_TOKEN_PREFIX}${userId}`);
}

export function getSavedMuseToken(userId: string): string {
  return localStorage.getItem(`${MUSE_TOKEN_PREFIX}${userId}`) ?? '';
}

export async function createMuseToken(userId: string): Promise<string> {
  if (!cloudClient) throw new Error('云同步尚未配置');
  const random = crypto.getRandomValues(new Uint8Array(32));
  const token = `muse_${base64Url(random)}`;
  const { error } = await cloudClient.from('shortcut_tokens').insert({
    user_id: userId,
    token_hash: await sha256Hex(token),
    label: MUSE_TOKEN_LABEL,
    scopes: ['read', 'write', 'update', 'delete'],
  });
  if (error) throw error;
  localStorage.setItem(`${MUSE_TOKEN_PREFIX}${userId}`, token);
  return token;
}

export async function revokeMuseTokens(userId: string): Promise<void> {
  if (!cloudClient) return;
  const { error } = await cloudClient.from('shortcut_tokens').delete().eq('user_id', userId).eq('label', MUSE_TOKEN_LABEL);
  if (error) throw error;
  localStorage.removeItem(`${MUSE_TOKEN_PREFIX}${userId}`);
}

