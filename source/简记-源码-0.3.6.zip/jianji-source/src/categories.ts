import type { Category } from './types';

export const CATEGORY_COLORS = ['#111111', '#4f4f4f', '#777777', '#9a9a9a', '#bdbdbd', '#d0d0d0', '#e0e0e0', '#ededed'];

export const DEFAULT_CATEGORIES: Category[] = [
  { id: 'food', name: '餐饮', short: '餐', icon: 'utensils', color: '#b64a37', builtin: true, keywords: ['咖啡', '餐厅', '饭店', '外卖', '奶茶', '早餐', '午餐', '晚餐', '夜宵', '美团', '饿了么', 'manner', 'starbucks', '星巴克', '瑞幸', '便利店', '超市食品'] },
  { id: 'transport', name: '交通', short: '行', icon: 'bus-front', color: '#315c56', builtin: true, keywords: ['地铁', '公交', '滴滴', '出租', '打车', '高铁', '火车', '机票', '加油', '停车', '共享单车'] },
  { id: 'shopping', name: '购物', short: '购', icon: 'shopping-bag', color: '#a4742d', builtin: true, keywords: ['淘宝', '京东', '拼多多', '商城', '超市', '购物', '便利店', '天猫', '盒马', '山姆'] },
  { id: 'home', name: '居住', short: '住', icon: 'house', color: '#7a654f', builtin: true, keywords: ['房租', '水电', '水费', '电费', '燃气', '物业', '宽带', '家居'] },
  { id: 'fun', name: '娱乐', short: '娱', icon: 'gamepad-2', color: '#7b5d75', builtin: true, keywords: ['电影', '游戏', '视频', '会员', '音乐', '演出', '门票', 'ktv'] },
  { id: 'health', name: '医疗', short: '医', icon: 'heart-pulse', color: '#8e3e4f', builtin: true, keywords: ['医院', '药店', '挂号', '体检', '医疗', '牙科', '诊所'] },
  { id: 'study', name: '学习', short: '学', icon: 'book-open', color: '#5f6880', builtin: true, keywords: ['书店', '课程', '教育', '学费', '培训', '考试', '书'] },
  { id: 'social', name: '人情', short: '人', icon: 'gift', color: '#8d6746', builtin: true, keywords: ['红包', '礼物', '请客', '份子', '转账'] },
  { id: 'salary', name: '工资', short: '薪', icon: 'wallet-cards', color: '#60714a', builtin: true, keywords: ['工资', '薪水', '奖金', '报销', '兼职', '收入'] },
  { id: 'refund', name: '退款', short: '退', icon: 'rotate-ccw', color: '#577571', builtin: true, keywords: ['退款', '退回', '返现', '退货'] },
  { id: 'other', name: '其他', short: '其', icon: 'shapes', color: '#77736a', builtin: true, keywords: [] },
];

export function normalizeText(value: string): string {
  return value.toLowerCase().replace(/[\s\u3000]+/g, '').replace(/[，。！？、,.!?;；:：()（）\[\]【】]/g, '');
}

export function rankCategories(text: string, merchant: string, categories: Category[]) {
  const haystack = normalizeText(`${text} ${merchant}`);
  const scored = categories.map((category) => {
    const matches = category.keywords.filter((keyword) => keyword && haystack.includes(normalizeText(keyword)));
    let score = matches.reduce((sum, keyword) => sum + Math.min(5, Math.max(2, keyword.length)), 0);
    if (haystack.includes(normalizeText(category.name))) score += 8;
    if (category.id === 'food' && /(早餐|午餐|晚餐|吃饭|咖啡|奶茶)/.test(text)) score += 4;
    if (category.id === 'salary' && /(工资|收入|奖金|报销)/.test(text)) score += 5;
    if (category.id === 'refund' && /(退款|返现)/.test(text)) score += 7;
    return { id: category.id, score, matches: Array.from(new Set(matches)).slice(0, 4) };
  });
  return scored.sort((a, b) => b.score - a.score);
}

export function findBestCategory(text: string, merchant: string, categories: Category[]): string {
  const ranked = rankCategories(text, merchant, categories);
  return ranked[0]?.score > 0 ? ranked[0].id : 'other';
}

export function categoryById(categories: Category[], id: string): Category {
  return categories.find((category) => category.id === id) ?? categories[categories.length - 1] ?? DEFAULT_CATEGORIES[DEFAULT_CATEGORIES.length - 1];
}
