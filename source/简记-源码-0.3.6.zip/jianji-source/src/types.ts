export type Direction = 'expense' | 'income';

export type Category = {
  id: string;
  name: string;
  short: string;
  icon?: string;
  color: string;
  keywords: string[];
  monthlyBudget?: number;
  builtin?: boolean;
  updatedAt?: string;
};

export type Transaction = {
  id: string;
  amount: number;
  direction: Direction;
  merchant: string;
  categoryId: string;
  occurredAt: string;
  source: string;
  note: string;
  createdAt: string;
  externalId?: string;
  isSample?: boolean;
  updatedAt?: string;
};

export type Draft = {
  amount: number | null;
  direction: Direction;
  merchant: string;
  categoryId: string;
  categoryCandidates: { id: string; score: number; matches: string[] }[];
  occurredAt: string;
  source: string;
  note: string;
  confidence: number;
  evidence: string[];
  rawText: string;
  sourceType: 'ocr' | 'text' | 'manual';
};

export type AppSettings = {
  clearClipboard: boolean;
  seeded: boolean;
  learnedRules: boolean;
  installPromptDismissed: boolean;
};

export type CaptureStage = 'idle' | 'reading' | 'ocr' | 'parsing' | 'done' | 'error';

export type DuplicateMatch = {
  transaction: Transaction;
  reason: string;
};

export type CloudPhase = 'disabled' | 'signed-out' | 'connecting' | 'syncing' | 'synced' | 'error';
