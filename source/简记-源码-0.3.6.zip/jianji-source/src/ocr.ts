type OcrWorker = {
  recognize: (image: Blob) => Promise<{ data: { text?: string } }>;
};

let workerPromise: Promise<OcrWorker> | null = null;

export type OcrProgress = (stage: string, progress: number) => void;

function getWorker(onProgress?: OcrProgress): Promise<OcrWorker> {
  if (!workerPromise) {
    const base = import.meta.env.BASE_URL;
    workerPromise = import('tesseract.js').then(({ createWorker }) => createWorker('chi_sim+eng', 1, {
      workerPath: `${base}tesseract/worker.min.js`,
      corePath: `${base}tesseract/core`,
      langPath: `${base}tessdata`,
      logger: (message: { status?: string; progress?: number }) => {
        onProgress?.(message.status ?? '识别中', Number(message.progress ?? 0));
      },
      gzip: true,
    } as never) as Promise<OcrWorker>);
  }
  return workerPromise;
}

async function loadBitmap(blob: Blob): Promise<{ source: CanvasImageSource; width: number; height: number; cleanup: () => void }> {
  if ('createImageBitmap' in window) {
    const bitmap = await createImageBitmap(blob);
    return { source: bitmap, width: bitmap.width, height: bitmap.height, cleanup: () => bitmap.close() };
  }
  const url = URL.createObjectURL(blob);
  const image = new Image();
  image.src = url;
  await image.decode();
  return { source: image, width: image.naturalWidth, height: image.naturalHeight, cleanup: () => URL.revokeObjectURL(url) };
}

async function preprocessImage(blob: Blob, crop?: { top: number; bottom: number }): Promise<Blob> {
  const image = await loadBitmap(blob);
  try {
    const maxSide = 1800;
    const sourceY = crop ? Math.max(0, Math.round(image.height * crop.top)) : 0;
    const sourceH = crop ? Math.max(1, Math.round(image.height * (crop.bottom - crop.top))) : image.height;
    const scale = Math.min(1, maxSide / Math.max(image.width, sourceH));
    const width = Math.max(1, Math.round(image.width * scale));
    const height = Math.max(1, Math.round(sourceH * scale));
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext('2d', { willReadFrequently: true });
    if (!context) throw new Error('浏览器无法创建图像画布');
    context.fillStyle = '#ffffff';
    context.fillRect(0, 0, width, height);
    context.drawImage(image.source, 0, sourceY, image.width, sourceH, 0, 0, width, height);
    const frame = context.getImageData(0, 0, width, height);
    const pixels = frame.data;
    for (let i = 0; i < pixels.length; i += 4) {
      const luminance = pixels[i] * 0.299 + pixels[i + 1] * 0.587 + pixels[i + 2] * 0.114;
      const value = Math.max(0, Math.min(255, (luminance - 128) * 1.16 + 128));
      pixels[i] = value;
      pixels[i + 1] = value;
      pixels[i + 2] = value;
    }
    context.putImageData(frame, 0, 0);
    return await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob((result) => (result ? resolve(result) : reject(new Error('截图预处理失败'))), 'image/png', 0.92);
    });
  } finally {
    image.cleanup();
  }
}

export async function recognizeImage(blob: Blob, onProgress?: OcrProgress): Promise<string> {
  onProgress?.('正在准备工作线程', 0.02);
  const worker = await getWorker(onProgress);
  onProgress?.('正在识别截图', 0.06);
  const original = await worker.recognize(blob);
  const originalText = original.data.text || '';

  // Payment screenshots often render the amount as very large type that the
  // full-page Chinese model can skip. A second pass over the upper receipt area
  // reliably recovers the amount line without storing a crop on disk.
  const hasAmount = /(?:[¥￥]\s*-?\d|[-−–—]\s*[¥￥]?\s*\d|\d+\.\d{2})/.test(originalText);
  if (hasAmount) return originalText;

  const amountRegex = /(?:[¥￥]\s*-?\d|[-−–—]\s*[¥￥]?\s*\d|\d+\.\d{2})/;
  const crops = [
    { top: 0.10, bottom: 0.38 },
    { top: 0.22, bottom: 0.50 },
    { top: 0.36, bottom: 0.64 },
  ];
  let combined = originalText;
  for (let index = 0; index < crops.length; index += 1) {
    onProgress?.(`正在单独识别金额区域 ${index + 1}/${crops.length}`, 0.58 + index * 0.1);
    const amountCrop = await preprocessImage(blob, crops[index]);
    try {
      const amountPass = await worker.recognize(amountCrop);
      const passText = amountPass.data.text || '';
      combined = [combined, passText].filter(Boolean).join('\n');
      if (amountRegex.test(passText)) return combined;
    } finally {
      amountCrop.arrayBuffer().catch(() => undefined);
    }
  }
  return combined;
}

export async function readImageFromClipboard(): Promise<Blob> {
  if (!navigator.clipboard?.read) throw new Error('当前浏览器不支持直接读取剪贴板，请长按粘贴区后选择“粘贴”。');
  try {
    const items = await navigator.clipboard.read();
    for (const item of items) {
      const imageType = item.types.find((type) => type.startsWith('image/'));
      if (imageType) return item.getType(imageType);
    }
    throw new Error('剪贴板里没有图片。请先运行“截屏并复制到剪贴板”的快捷指令。');
  } catch (error) {
    if (error instanceof Error && error.message.includes('没有图片')) throw error;
    throw new Error('iOS 没有允许读取剪贴板。请长按扫描页里的粘贴区，再选择“粘贴”。');
  }
}

export async function clearClipboardAfterUse(): Promise<boolean> {
  try {
    await navigator.clipboard.writeText('简记已读取截图');
    return true;
  } catch {
    return false;
  }
}

export function imageFromPasteEvent(event: ClipboardEvent): Blob | null {
  const items = event.clipboardData?.items;
  if (!items) return null;
  for (const item of Array.from(items)) {
    if (item.type.startsWith('image/')) return item.getAsFile();
  }
  return null;
}
