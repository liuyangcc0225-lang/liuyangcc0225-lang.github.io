import type { Category, Direction, DuplicateMatch, Draft, Transaction } from './types';
import { findBestCategory, normalizeText, rankCategories } from './categories';

const APP_TIME_ZONE = 'Asia/Shanghai';
const zonedFormatter = new Intl.DateTimeFormat('en-CA', {
  timeZone: APP_TIME_ZONE,
  year: 'numeric', month: '2-digit', day: '2-digit',
  hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23',
});

export type BeijingDateParts = { year: number; month: number; day: number; hour: number; minute: number; second: number };

export function getBeijingDateParts(value: string | Date = new Date()): BeijingDateParts {
  const parsed = typeof value === 'string' ? new Date(value) : value;
  const date = Number.isNaN(parsed.getTime()) ? new Date() : parsed;
  const parts = zonedFormatter.formatToParts(date);
  const pick = (type: Intl.DateTimeFormatPartTypes) => Number(parts.find((part) => part.type === type)?.value ?? 0);
  return { year: pick('year'), month: pick('month'), day: pick('day'), hour: pick('hour'), minute: pick('minute'), second: pick('second') };
}

export function beijingDateTimeToIso(value: string): string {
  const normalized = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value) ? `${value}:00` : value;
  const date = new Date(`${normalized}+08:00`);
  return Number.isNaN(date.getTime()) ? new Date().toISOString() : date.toISOString();
}

export function beijingDateKey(value: string | Date): string {
  const parts = getBeijingDateParts(value);
  return `${parts.year}-${parts.month}-${parts.day}`;
}

export function beijingDateTimeDaysAgo(daysAgo: number, hour: number, minute: number): string {
  const now = getBeijingDateParts();
  const date = new Date(Date.UTC(now.year, now.month - 1, now.day - daysAgo, hour - 8, minute, 0));
  return date.toISOString();
}

function beijingPartsToIso(parts: BeijingDateParts): string {
  const pad = (value: number) => String(value).padStart(2, '0');
  const date = new Date(`${parts.year}-${pad(parts.month)}-${pad(parts.day)}T${pad(parts.hour)}:${pad(parts.minute)}:${pad(parts.second)}+08:00`);
  return Number.isNaN(date.getTime()) ? new Date().toISOString() : date.toISOString();
}
const GENERIC_MERCHANT_WORDS = ['支付成功', '付款成功', '交易成功', '当前状态', '支付时间', '商品', '商户全称', '账单详情', '订单详情', '微信支付', '支付宝', '余额', '银行卡', '手续费', '优惠', '实付', '合计', '金额'];

function cleanLine(value: string): string {
  return value.replace(/^[\s\-—•·]+/, '').replace(/[：:]\s*$/, '').trim();
}

function safeDate(value: Date): Date {
  return Number.isNaN(value.getTime()) ? new Date() : value;
}

export function toDateTimeInput(value: string | Date): string {
  const parts = getBeijingDateParts(value);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${parts.year}-${pad(parts.month)}-${pad(parts.day)}T${pad(parts.hour)}:${pad(parts.minute)}`;
}

export function formatMoney(value: number): string {
  return new Intl.NumberFormat('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);
}

export function formatShortDate(value: string | Date): string {
  return new Intl.DateTimeFormat('zh-CN', { timeZone: APP_TIME_ZONE, month: 'numeric', day: 'numeric' }).format(new Date(value));
}

export function formatFullDate(value: string | Date): string {
  return new Intl.DateTimeFormat('zh-CN', { timeZone: APP_TIME_ZONE, year: 'numeric', month: 'long', day: 'numeric', weekday: 'short' }).format(new Date(value));
}

export function formatTime(value: string | Date): string {
  return new Intl.DateTimeFormat('zh-CN', { timeZone: APP_TIME_ZONE, hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date(value));
}

export function formatDayLabel(value: string | Date): string {
  return new Intl.DateTimeFormat('zh-CN', { timeZone: APP_TIME_ZONE, month: 'long', day: 'numeric', weekday: 'short' }).format(new Date(value));
}

export function formatDateTime(value: string | Date): string {
  return new Intl.DateTimeFormat('zh-CN', {
    timeZone: APP_TIME_ZONE,
    year: 'numeric', month: 'numeric', day: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
  }).format(new Date(value));
}
function amountCandidates(lines: string[]): { value: number; score: number; evidence: string }[] {
  const candidates: { value: number; score: number; evidence: string }[] = [];
  const numberPattern = /(?:[¥￥]\s*)?(-?\d[\d,]*(?:\.\d{1,2})?)(?:\s*元)?/g;
  for (const line of lines) {
    const numericLine = line.replace(/[−–—]/g, '-');
    const hasExplicitAmountLabel = /(支付金额|实付|付款金额|交易金额|消费金额|订单金额|合计|总计|金额)/.test(numericLine);
    const looksLikeDateOrTime = /(支付时间|交易时间|账单时间|日期)|(?:20\d{2}\s*[年./-]\s*\d{1,2})|(?:\d{1,2}\s*[:：]\s*\d{2})/.test(numericLine);
    if (looksLikeDateOrTime && !hasExplicitAmountLabel) continue;
    let match: RegExpExecArray | null;
    while ((match = numberPattern.exec(numericLine)) !== null) {
      const raw = match[1];
      if (!raw) continue;
      const value = Number(raw.replace(/,/g, ''));
      if (!Number.isFinite(value) || value <= 0 || value > 100000000) continue;
      const after = numericLine.slice((match.index ?? 0) + match[0].length, (match.index ?? 0) + match[0].length + 3);
      if (/^(?:年|月|日|时|分|秒)/.test(after)) continue;
      let score = 0;
      if (hasExplicitAmountLabel) score += 7;
      if (/[¥￥]/.test(numericLine)) score += 3;
      if (/(?:^|\s)-\s*[¥￥]?/.test(numericLine)) score += 1;
      if (/\.\d{1,2}/.test(raw)) score += 1;
      if (/原价|优惠|折扣|余额|积分|手续费/.test(numericLine)) score -= 5;
      if (/尾号|卡号|订单号|流水号|支付时间|交易时间|日期/.test(numericLine)) score -= 6;
      if (!/[¥￥元]/.test(numericLine) && !/支付|实付|合计|金额/.test(numericLine)) score -= 2;
      candidates.push({ value, score, evidence: line });
    }
  }
  return candidates.sort((a, b) => b.score - a.score);
}

function extractMerchant(lines: string[], text: string): { merchant: string; evidence: string | null } {
  const directPatterns = [
    /(?:商户全称|商户名称|商户|收款方|收款人|商家)[：:]\s*([^\n]+)/i,
    /(?:订单标题|商品名称|商品)[：:]\s*([^\n]+)/i,
  ];
  for (const pattern of directPatterns) {
    const match = text.match(pattern);
    if (match?.[1]) {
      const merchant = cleanLine(match[1]).replace(/\s{2,}.*$/, '').slice(0, 48);
      if (merchant && !GENERIC_MERCHANT_WORDS.some((word) => merchant === word)) return { merchant, evidence: match[0].trim() };
    }
  }

  const naturalPatterns = [
    /(?:在|去|吃了|喝了|买了|用了)\s*([^，。,;；\n]{2,30}?)(?:，|,|。|花了|支付|付款|微信|支付宝|$)/i,
    /(?:给|向)\s*([^，。,;；\n]{2,30}?)(?:转账|付款|支付)/i,
  ];
  for (const pattern of naturalPatterns) {
    const match = text.match(pattern);
    if (match?.[1]) {
      const merchant = cleanLine(match[1]).replace(/(今天|昨天|前天|我|朋友|好友)+/g, '').trim();
      if (merchant.length >= 2 && !GENERIC_MERCHANT_WORDS.includes(merchant)) return { merchant, evidence: match[0].trim() };
    }
  }

  const brandLine = lines.find((line) => {
    if (line.length < 3 || line.length > 46) return false;
    if (GENERIC_MERCHANT_WORDS.some((word) => line.includes(word))) return false;
    if (/[¥￥]|\d{1,2}:\d{2}|\d{4}[年./-]\d{1,2}/.test(line)) return false;
    if (/^[\d\s.,:+-]+$/.test(line)) return false;
    return /[A-Za-z]{2,}/.test(line) || /[\u4e00-\u9fff]{2,}/.test(line);
  });
  if (brandLine) return { merchant: brandLine.slice(0, 48), evidence: brandLine };
  return { merchant: '', evidence: null };
}

function extractDirection(text: string): Direction {
  if (/(退款|退回|收款|收入|工资|奖金|报销|入账|转入|返现|退货)/.test(text) && !/(支付成功|付款成功|消费|支出|扣款)/.test(text)) return 'income';
  return 'expense';
}

function extractSource(text: string): string {
  if (/微信/.test(text)) return '微信';
  if (/支付宝/.test(text)) return '支付宝';
  if (/云闪付/.test(text)) return '云闪付';
  if (/Apple\s*Pay/i.test(text)) return 'Apple Pay';
  if (/(信用卡|储蓄卡|银行卡|尾号)/.test(text)) return '银行卡';
  if (/余额/.test(text)) return '余额';
  if (/现金/.test(text)) return '现金';
  return '未注明';
}

function extractOccurredAt(text: string, now: Date): { value: string; evidence: string | null } {
  const nowParts = getBeijingDateParts(now);
  let year = nowParts.year;
  let month = nowParts.month;
  let day = nowParts.day;
  let matchedDate = false;
  let evidence: string | null = null;
  const full = text.match(/(20\d{2})\s*[年./-]\s*(\d{1,2})\s*[月./-]\s*(\d{1,2})\s*日?/);
  if (full) {
    year = Number(full[1]);
    month = Number(full[2]);
    day = Number(full[3]);
    matchedDate = true;
    evidence = full[0];
  } else {
    const short = text.match(/(\d{1,2})\s*月\s*(\d{1,2})\s*日?/);
    if (short) {
      month = Number(short[1]);
      day = Number(short[2]);
      matchedDate = true;
      evidence = short[0];
    }
  }
  const relative = text.match(/(今天|昨天|前天)/);
  if (relative) {
    const offset = relative[1] === '昨天' ? -1 : relative[1] === '前天' ? -2 : 0;
    const shifted = new Date(Date.UTC(year, month - 1, day + offset));
    year = shifted.getUTCFullYear();
    month = shifted.getUTCMonth() + 1;
    day = shifted.getUTCDate();
    matchedDate = true;
    evidence = relative[1];
  }
  let hour = nowParts.hour;
  let minute = nowParts.minute;
  let second = 0;
  const time = text.match(/(\d{1,2})\s*[:：]\s*(\d{2})(?:\s*[:：]\s*(\d{2}))?/);
  if (time) {
    hour = Number(time[1]);
    if (/(下午|晚上|傍晚)/.test(text) && hour < 12) hour += 12;
    minute = Number(time[2]);
    second = Number(time[3] ?? 0);
    if (!evidence) evidence = time[0];
  }
  if (!matchedDate) {
    year = nowParts.year;
    month = nowParts.month;
    day = nowParts.day;
  }
  return {
    value: beijingPartsToIso({ year, month, day, hour, minute, second }),
    evidence,
  };
}
function buildEvidence(lines: string[], amountEvidence: string | null, merchantEvidence: string | null, dateEvidence: string | null, source: string): string[] {
  const evidence = new Set<string>();
  if (amountEvidence) evidence.add(amountEvidence.slice(0, 80));
  if (merchantEvidence) evidence.add(merchantEvidence.slice(0, 80));
  if (dateEvidence) evidence.add(dateEvidence.slice(0, 80));
  if (source !== '未注明') {
    const sourceLine = lines.find((line) => line.includes(source) || (source === '银行卡' && /(信用卡|储蓄卡|尾号)/.test(line)));
    if (sourceLine) evidence.add(sourceLine.slice(0, 80));
  }
  return Array.from(evidence).slice(0, 4);
}

export function parseTransactionText(rawText: string, categories: Category[], now = new Date(), sourceType: Draft['sourceType'] = 'text'): Draft {
  const text = rawText.replace(/\u00a0/g, ' ').replace(/\r\n/g, '\n').trim();
  const lines = text.split(/\n+/).map(cleanLine).filter(Boolean);
  const amounts = amountCandidates(lines.length ? lines : [text]);
  const amount = amounts[0]?.value ?? null;
  const direction = extractDirection(text);
  const { merchant, evidence: merchantEvidence } = extractMerchant(lines, text);
  const occurred = extractOccurredAt(text, now);
  const source = extractSource(text);
  const categoryCandidates = rankCategories(text, merchant, categories).filter((item) => item.score > 0);
  const categoryId = merchant || text ? findBestCategory(text, merchant, categories) : 'other';
  const evidence = buildEvidence(lines, amounts[0]?.evidence ?? null, merchantEvidence, occurred.evidence, source);
  let confidence = 0.18;
  if (amount !== null) confidence += 0.32;
  if (merchant) confidence += 0.16;
  if (occurred.evidence) confidence += 0.1;
  if (source !== '未注明') confidence += 0.06;
  if (categoryCandidates[0]?.score) confidence += 0.12;
  if (!amount) confidence = Math.min(confidence, 0.28);
  const fallbackCategory = categories.find((category) => category.id === categoryId);
  return {
    amount,
    direction,
    merchant: merchant || fallbackCategory?.name || '未命名账目',
    categoryId,
    categoryCandidates: categoryCandidates.length ? categoryCandidates.slice(0, 5) : [{ id: categoryId, score: 0, matches: [] }],
    occurredAt: occurred.value,
    source,
    note: '',
    confidence: Math.min(0.98, confidence),
    evidence,
    rawText: text,
    sourceType,
  };
}

function similarity(a: string, b: string): number {
  const left = normalizeText(a);
  const right = normalizeText(b);
  if (!left || !right) return 0;
  if (left === right) return 1;
  if (left.includes(right) || right.includes(left)) return 0.82;
  const rows = left.length + 1;
  const cols = right.length + 1;
  const dp = Array.from({ length: rows }, () => new Array<number>(cols).fill(0));
  for (let i = 0; i < rows; i += 1) dp[i][0] = i;
  for (let j = 0; j < cols; j += 1) dp[0][j] = j;
  for (let i = 1; i < rows; i += 1) {
    for (let j = 1; j < cols; j += 1) {
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + (left[i - 1] === right[j - 1] ? 0 : 1));
    }
  }
  return 1 - dp[left.length][right.length] / Math.max(left.length, right.length);
}

export function findDuplicate(draft: Pick<Draft, 'amount' | 'merchant' | 'occurredAt' | 'direction'>, transactions: Transaction[]): DuplicateMatch | null {
  if (draft.amount === null) return null;
  const target = new Date(draft.occurredAt).getTime();
  for (const transaction of transactions) {
    if (transaction.direction !== draft.direction) continue;
    if (Math.abs(transaction.amount - draft.amount) > 0.009) continue;
    const dayDiff = Math.abs(new Date(transaction.occurredAt).getTime() - target) / 86400000;
    if (dayDiff > 1.1) continue;
    const merchantScore = similarity(transaction.merchant, draft.merchant);
    if (merchantScore >= 0.52) {
      return { transaction, reason: dayDiff < 0.2 ? '金额和时间都很接近' : '金额与商户高度相似' };
    }
  }
  return null;
}

export function draftToTransaction(draft: Draft): Transaction {
  return {
    id: crypto.randomUUID?.() ?? `tx-${Date.now()}-${Math.random().toString(16).slice(2)}`,
    amount: Number(draft.amount ?? 0),
    direction: draft.direction,
    merchant: draft.merchant.trim() || '未命名账目',
    categoryId: draft.categoryId,
    occurredAt: draft.occurredAt,
    source: draft.source || '未注明',
    note: draft.note.trim(),
    createdAt: new Date().toISOString(),
  };
}
