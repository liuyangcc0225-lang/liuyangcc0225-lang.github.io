import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Check, X } from 'lucide-react';
import type { AppSettings, CaptureStage, Category, CloudPhase, Draft, Transaction } from './types';
import { DEFAULT_CATEGORIES, categoryById } from './categories';
import { clearAllData, clearSampleTransactions, DEFAULT_SETTINGS, deleteTransaction as deleteTransactionRecord, loadTransactions, replaceLedgerData, saveCategories, saveCategory, saveSettings, saveTransaction, seedIfNeeded } from './db';
import { beijingDateKey, draftToTransaction, findDuplicate, formatDateTime, parseTransactionText } from './parser';
import { clearClipboardAfterUse, imageFromPasteEvent, readImageFromClipboard, recognizeImage } from './ocr';
import {
  buildSnapshot,
  cloudConfigured,
  cloudErrorMessage,
  cloudPublishableKey,
  createMuseToken,
  createShortcutToken,
  getCloudSession,
  getSavedMuseToken,
  getSavedShortcutToken,
  mergeSnapshots,
  museOcrEndpoint,
  museVisionEndpoint,
  museWriteEndpoint,
  onCloudAuthChange,
  pullCloudSnapshot,
  pushCloudSnapshot,
  rememberDeletedTransaction,
  revokeMuseTokens,
  revokeShortcutTokens,
  saveTombstones,
  signInToCloud,
  signOutOfCloud,
  shortcutCaptureEndpoint,
  signUpForCloud,
  snapshotFingerprint,
  subscribeToCloudSnapshot,
  type CloudUser,
} from './cloud';
import BottomNav, { type AppView } from './components/BottomNav';
import HomePage from './components/HomePage';
import CapturePage from './components/CapturePage';
import ReviewPage from './components/ReviewPage';
import LedgerPage from './components/LedgerPage';
import CategoriesPage from './components/CategoriesPage';
import SettingsPage from './components/SettingsPage';
import TransactionSheet from './components/TransactionSheet';

type Screen = AppView | 'review';

type Toast = { id: number; message: string };


export default function App() {
  const initialCapture = new URLSearchParams(window.location.search).get('capture') === '1';
  const [view, setView] = useState<Screen>(initialCapture ? 'capture' : 'home');
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [categories, setCategories] = useState<Category[]>(DEFAULT_CATEGORIES);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [captureStage, setCaptureStage] = useState<CaptureStage>('idle');
  const [captureProgress, setCaptureProgress] = useState(0);
  const [captureStatus, setCaptureStatus] = useState('');
  const [captureError, setCaptureError] = useState('');
  const [loading, setLoading] = useState(true);
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [toast, setToast] = useState<Toast | null>(null);
  const toastTimer = useRef<number | null>(null);
  const shortcutHandled = useRef(false);
  const [cloudUser, setCloudUser] = useState<CloudUser | null>(null);
  const [cloudReady, setCloudReady] = useState(!cloudConfigured);
  const [cloudPhase, setCloudPhase] = useState<CloudPhase>(cloudConfigured ? 'connecting' : 'disabled');
  const [cloudError, setCloudError] = useState('');
  const [lastSyncedAt, setLastSyncedAt] = useState('');
  const [shortcutToken, setShortcutToken] = useState('');
  const [museToken, setMuseToken] = useState('');
  const transactionsRef = useRef<Transaction[]>([]);
  const categoriesRef = useRef<Category[]>([]);
  const syncingRef = useRef(false);
  const syncedFingerprintRef = useRef('');
  const syncTimerRef = useRef<number | null>(null);

  const notify = useCallback((message: string) => {
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    setToast({ id: Date.now(), message });
    toastTimer.current = window.setTimeout(() => setToast(null), 2800);
  }, []);

  useEffect(() => {
    seedIfNeeded()
      .then((data) => {
        setTransactions(data.transactions);
        setCategories(data.categories);
        setSettings(data.settings);
      })
      .catch(() => notify('本地数据库打开失败，请刷新页面重试'))
      .finally(() => setLoading(false));
  }, [notify]);

  useEffect(() => {
    if (!initialCapture) return;
    notify('截图在剪贴板里吗？点一下读取即可');
  }, [initialCapture, notify]);

  useEffect(() => {
    const handler = (event: Event) => {
      const promptEvent = event as BeforeInstallPromptEvent;
      event.preventDefault();
      setInstallPrompt(promptEvent);
    };
    const installed = () => {
      setInstallPrompt(null);
      notify('简记已安装到主屏幕');
    };
    window.addEventListener('beforeinstallprompt', handler);
    window.addEventListener('appinstalled', installed);
    if ('storage' in navigator && 'persist' in navigator.storage) navigator.storage.persist().catch(() => undefined);
    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
      window.removeEventListener('appinstalled', installed);
    };
  }, [notify]);

  useEffect(() => {
    transactionsRef.current = transactions;
  }, [transactions]);

  useEffect(() => {
    categoriesRef.current = categories;
  }, [categories]);

  const syncNow = useCallback(async () => {
    if (!cloudUser || syncingRef.current) return;
    syncingRef.current = true;
    setCloudPhase('syncing');
    setCloudError('');
    try {
      const local = buildSnapshot(transactionsRef.current, categoriesRef.current);
      const remote = await pullCloudSnapshot(cloudUser.id);
      const merged = mergeSnapshots(local, remote?.payload);
      const localFingerprint = snapshotFingerprint(local);
      const remoteFingerprint = remote ? snapshotFingerprint(remote.payload) : '';
      const mergedFingerprint = snapshotFingerprint(merged);

      syncedFingerprintRef.current = mergedFingerprint;
      if (localFingerprint !== mergedFingerprint) {
        const mergedTransactions = merged.transactions.filter((item) => !item.isSample);
        await replaceLedgerData(mergedTransactions, merged.categories);
        saveTombstones({
          transactions: merged.deletedTransactionIds,
          categories: merged.deletedCategoryIds,
        });
        transactionsRef.current = mergedTransactions;
        categoriesRef.current = merged.categories;
        setTransactions(mergedTransactions);
        setCategories(merged.categories);
      }

      if (!remote || mergedFingerprint !== remoteFingerprint) {
        await pushCloudSnapshot(cloudUser.id, merged);
      }

      setLastSyncedAt(new Date().toISOString());
      setCloudPhase('synced');
    } catch (error) {
      setCloudError(cloudErrorMessage(error));
      setCloudPhase('error');
    } finally {
      syncingRef.current = false;
    }
  }, [cloudUser]);

  const handleGenerateShortcutToken = useCallback(async () => {
    if (!cloudUser) return '';
    try {
      await revokeShortcutTokens(cloudUser.id);
      const token = await createShortcutToken(cloudUser.id);
      setShortcutToken(token);
      notify('快捷指令令牌已生成');
      return token;
    } catch (error) {
      notify(cloudErrorMessage(error));
      return '';
    }
  }, [cloudUser, notify]);

  const handleRevokeShortcutToken = useCallback(async () => {
    if (!cloudUser) return;
    try {
      await revokeShortcutTokens(cloudUser.id);
      setShortcutToken('');
      notify('快捷指令令牌已撤销');
    } catch (error) {
      notify(cloudErrorMessage(error));
    }
  }, [cloudUser, notify]);

  const handleGenerateMuseToken = useCallback(async () => {
    if (!cloudUser) return '';
    try {
      await revokeMuseTokens(cloudUser.id);
      const token = await createMuseToken(cloudUser.id);
      setMuseToken(token);
      notify('Muse 写入令牌已生成');
      return token;
    } catch (error) {
      notify(cloudErrorMessage(error));
      return '';
    }
  }, [cloudUser, notify]);

  const handleRevokeMuseToken = useCallback(async () => {
    if (!cloudUser) return;
    try {
      await revokeMuseTokens(cloudUser.id);
      setMuseToken('');
      notify('Muse 写入令牌已撤销');
    } catch (error) {
      notify(cloudErrorMessage(error));
    }
  }, [cloudUser, notify]);
  useEffect(() => {
    if (!cloudConfigured) return;
    let active = true;
    const applySession = (session: Awaited<ReturnType<typeof getCloudSession>>) => {
      if (!active) return;
      const user = session?.user;
      setCloudUser(user ? { id: user.id, email: user.email } : null);
      setShortcutToken(user ? getSavedShortcutToken(user.id) : '');
      setMuseToken(user ? getSavedMuseToken(user.id) : '');
      setCloudError('');
      if (user) {
        setCloudPhase('connecting');
      } else {
        syncedFingerprintRef.current = '';
        setCloudPhase('signed-out');
      }
    };

    const unsubscribe = onCloudAuthChange(applySession);
    getCloudSession()
      .then(applySession)
      .catch((error) => {
        if (!active) return;
        setCloudError(cloudErrorMessage(error));
        setCloudPhase('error');
      })
      .finally(() => {
        if (active) setCloudReady(true);
      });

    return () => {
      active = false;
      unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (!cloudReady || loading || !cloudUser) return;
    void syncNow();
  }, [cloudReady, cloudUser, loading, syncNow]);

  useEffect(() => {
    if (!cloudUser || loading || !syncedFingerprintRef.current || syncingRef.current) return;
    const fingerprint = snapshotFingerprint(buildSnapshot(transactions, categories));
    if (fingerprint === syncedFingerprintRef.current) return;
    if (syncTimerRef.current) window.clearTimeout(syncTimerRef.current);
    syncTimerRef.current = window.setTimeout(() => {
      void syncNow();
    }, 1200);
    return () => {
      if (syncTimerRef.current) window.clearTimeout(syncTimerRef.current);
    };
  }, [categories, cloudUser, loading, syncNow, transactions]);

  useEffect(() => {
    if (!cloudUser) return;
    const syncWhenVisible = () => {
      if (document.visibilityState === 'visible') void syncNow();
    };
    const interval = window.setInterval(syncWhenVisible, 45_000);
    const unsubscribe = subscribeToCloudSnapshot(cloudUser.id, () => {
      void syncNow();
    });
    document.addEventListener('visibilitychange', syncWhenVisible);
    return () => {
      window.clearInterval(interval);
      unsubscribe();
      document.removeEventListener('visibilitychange', syncWhenVisible);
    };
  }, [cloudUser, syncNow]);

  const handleCloudSignIn = useCallback(async (email: string, password: string) => {
    setCloudError('');
    setCloudPhase('connecting');
    try {
      await signInToCloud(email, password);
      return null;
    } catch (error) {
      const message = cloudErrorMessage(error);
      setCloudError(message);
      setCloudPhase('error');
      return message;
    }
  }, []);

  const handleCloudSignUp = useCallback(async (email: string, password: string) => {
    setCloudError('');
    setCloudPhase('connecting');
    try {
      const result = await signUpForCloud(email, password);
      if (result.needsConfirmation) {
        setCloudPhase('signed-out');
        return { ok: true, message: '验证邮件已发送，请打开邮件完成验证后再登录。' };
      }
      if (result.user) {
        setCloudUser(result.user);
        setCloudPhase('connecting');
      }
      return { ok: true, message: '账号已创建，正在同步本地账目。' };
    } catch (error) {
      const message = cloudErrorMessage(error);
      setCloudError(message);
      setCloudPhase('error');
      return { ok: false, message };
    }
  }, []);

  const handleCloudSignOut = useCallback(async () => {
    try {
      await signOutOfCloud();
    } catch (error) {
      notify(cloudErrorMessage(error));
    } finally {
      setCloudUser(null);
      setCloudPhase(cloudConfigured ? 'signed-out' : 'disabled');
      syncedFingerprintRef.current = '';
    }
  }, [notify]);

  const duplicate = useMemo(() => (draft ? findDuplicate(draft, transactions) : null), [draft, transactions]);

  useEffect(() => {
    if (loading) return;
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' as ScrollBehavior });
    const frame = window.requestAnimationFrame(() => {
      const heading = document.querySelector<HTMLElement>('.page h1');
      if (!heading) return;
      heading.setAttribute('tabindex', '-1');
      heading.focus({ preventScroll: true });
    });
    return () => window.cancelAnimationFrame(frame);
  }, [view, loading]);

  const handleImage = useCallback(async (blob: Blob, fromClipboard = true) => {
    setView('capture');
    setCaptureError('');
    setCaptureProgress(0.02);
    setCaptureStatus('正在读取截屏');
    setCaptureStage('reading');
    try {
      const text = await recognizeImage(blob, (status, progress) => {
        setCaptureStatus(status);
        setCaptureProgress(Math.max(0.03, Math.min(0.98, progress)));
        setCaptureStage(progress < 0.18 ? 'reading' : 'ocr');
      });
      if (!text.trim()) throw new Error('没有从截图里读到文字，请确认截屏包含支付详情。');
      setCaptureStage('parsing');
      setCaptureProgress(0.99);
      setCaptureStatus('正在整理账单草稿');
      const nextDraft = parseTransactionText(text, categories, new Date(), 'ocr');
      const clipboardCleared = !(fromClipboard && settings.clearClipboard) || await clearClipboardAfterUse();
      setDraft(nextDraft);
      setCaptureStage('done');
      setView('review');
      if (!nextDraft.amount) {
        notify('识别到文字，但没找到金额，请手动补充');
      } else if (!clipboardCleared) {
        notify('已生成草稿；iOS 未允许自动覆盖剪贴板，可手动复制任意文字清除');
      } else {
        notify('已生成账单草稿，请核对后入账');
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : '截图识别失败，请重试';
      setCaptureError(message);
      setCaptureStage('error');
      setCaptureStatus('识别失败');
    }
  }, [categories, notify, settings.clearClipboard]);

  useEffect(() => {
    function onPaste(event: ClipboardEvent) {
      const blob = imageFromPasteEvent(event);
      if (!blob) return;
      event.preventDefault();
      handleImage(blob, true);
    }
    window.addEventListener('paste', onPaste);
    return () => window.removeEventListener('paste', onPaste);
  }, [handleImage]);

  const handleReadClipboard = useCallback(async () => {
    setCaptureError('');
    setCaptureProgress(0.01);
    setCaptureStatus('正在读取剪贴板');
    setCaptureStage('reading');
    try {
      const blob = await readImageFromClipboard();
      await handleImage(blob, true);
    } catch (error) {
      const message = error instanceof Error ? error.message : '无法读取剪贴板截图';
      setCaptureError(message);
      setCaptureStage('error');
    }
  }, [handleImage]);

  const handleTextDraft = useCallback((text: string) => {
    const nextDraft = parseTransactionText(text, categories, new Date(), 'text');
    setDraft(nextDraft);
    setCaptureStage('done');
    setView('review');
    notify(nextDraft.amount ? '文字草稿已生成' : '还需要你补充金额');
  }, [categories, notify]);

  const learnCategory = useCallback(async (nextDraft: Draft) => {
    if (!settings.learnedRules) return;
    const merchant = nextDraft.merchant.trim();
    if (merchant.length < 2 || merchant.length > 28) return;
    const category = categoryById(categories, nextDraft.categoryId);
    if (category.keywords.some((keyword) => keyword.toLowerCase() === merchant.toLowerCase())) return;
    const updated = { ...category, keywords: [...category.keywords, merchant].slice(-40), updatedAt: new Date().toISOString() };
    await saveCategory(updated);
    setCategories((current) => current.map((item) => (item.id === updated.id ? updated : item)));
  }, [categories, settings.learnedRules]);

  const handleConfirmDraft = useCallback(async (nextDraft: Draft, message = '已经记入账页') => {
    const transaction = { ...draftToTransaction(nextDraft), updatedAt: new Date().toISOString() };
    await saveTransaction(transaction);
    await clearSampleTransactions();
    await learnCategory(nextDraft);
    setTransactions((current) => [transaction, ...current.filter((item) => item.id !== transaction.id && !item.isSample)].sort((a, b) => new Date(b.occurredAt).getTime() - new Date(a.occurredAt).getTime()));
    setDraft(null);
    setCaptureStage('idle');
    setCaptureProgress(0);
    setCaptureStatus('');
    setView('home');
    notify(message);
  }, [learnCategory, notify]);


  const handleAbandonDraft = useCallback(() => {
    setDraft(null);
    setCaptureStage('idle');
    setView('capture');
  }, []);
  useEffect(() => {
    if (loading || shortcutHandled.current) return;
    const params = new URLSearchParams(window.location.search);
    if (params.get('capture') !== 'auto') return;
    shortcutHandled.current = true;
    const text = params.get('text') ?? '';
    if (!text.trim()) {
      setView('capture');
      notify('快捷指令没有传入文字，请检查“从图像中提取文本”步骤');
      return;
    }
    const nextDraft = parseTransactionText(text, categories, new Date(), 'ocr');
    const duplicateMatch = findDuplicate(nextDraft, transactions);
    window.history.replaceState({}, '', import.meta.env.BASE_URL);
    if (params.get('auto') === '1' && nextDraft.amount && nextDraft.confidence >= 0.82 && !duplicateMatch) {
      void handleConfirmDraft(nextDraft, '快捷指令已自动记入账页');
      return;
    }
    setDraft(nextDraft);
    setView('review');
    notify(duplicateMatch ? '快捷指令已识别；发现疑似重复账单，请核对' : nextDraft.amount ? '快捷指令已识别，请核对后入账' : '快捷指令已识别；请补充金额');
  }, [categories, handleConfirmDraft, loading, notify, transactions]);

  const handleSaveTransaction = useCallback(async (transaction: Transaction) => {
    const updated = { ...transaction, updatedAt: new Date().toISOString() };
    await saveTransaction(updated);
    setTransactions((current) => [updated, ...current.filter((item) => item.id !== updated.id)].sort((a, b) => new Date(b.occurredAt).getTime() - new Date(a.occurredAt).getTime()));
    setSelectedTransaction(null);
    notify('账目已更新');
  }, [notify]);

  const handleDeleteTransaction = useCallback(async (transaction: Transaction) => {
    rememberDeletedTransaction(transaction.id);
    await deleteTransactionRecord(transaction.id);
    setTransactions((current) => current.filter((item) => item.id !== transaction.id));
    setSelectedTransaction(null);
    notify('账目已删除');
  }, [notify]);

  const handleSaveCategory = useCallback(async (category: Category) => {
    const updated = { ...category, updatedAt: new Date().toISOString() };
    await saveCategory(updated);
    setCategories((current) => current.map((item) => (item.id === updated.id ? updated : item)));
    notify('分类已保存');
  }, [notify]);

  const updateSettings = useCallback(async (nextSettings: AppSettings) => {
    setSettings(nextSettings);
    await saveSettings(nextSettings);
  }, []);

  const handleInstall = useCallback(async () => {
    if (!installPrompt) return;
    await installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    if (choice.outcome === 'accepted') notify('正在安装简记');
    setInstallPrompt(null);
  }, [installPrompt, notify]);

  const exportCsv = useCallback(() => {
    const header = ['日期', '收支', '金额', '商户', '分类', '支付方式', '备注'];
    const rows = transactions.map((transaction) => [
      formatDateTime(transaction.occurredAt),
      transaction.direction === 'expense' ? '支出' : '收入',
      transaction.amount.toFixed(2),
      transaction.merchant,
      categoryById(categories, transaction.categoryId).name,
      transaction.source,
      transaction.note,
    ]);
    const escape = (value: string) => `"${value.replace(/"/g, '""')}"`;
    const csv = '\uFEFF' + [header, ...rows].map((row) => row.map(escape).join(',')).join('\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = `简记-${beijingDateKey(new Date())}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    notify('CSV 已导出');
  }, [categories, notify, transactions]);

  const handleClearSamples = useCallback(async () => {
    await clearSampleTransactions();
    setTransactions(await loadTransactions());
    notify('示例账目已清除');
  }, [notify]);

  const handleReset = useCallback(async () => {
    if (!window.confirm('这会清空所有账目和自定义分类，只保留空白账页。继续吗？')) return;
    transactions.filter((item) => !item.isSample).forEach((item) => rememberDeletedTransaction(item.id));
    await clearAllData();
    const resetAt = new Date().toISOString();
    const cleanCategories = DEFAULT_CATEGORIES.map((category) => ({ ...category, keywords: [...category.keywords], updatedAt: resetAt }));
    const cleanSettings = { ...DEFAULT_SETTINGS, seeded: true };
    await saveCategories(cleanCategories);
    await saveSettings(cleanSettings);
    setTransactions([]);
    setCategories(cleanCategories);
    setSettings(cleanSettings);
    setView('home');
    notify('本地数据已清空');
  }, [notify, transactions]);

  const isStandalone = window.matchMedia('(display-mode: standalone)').matches || Boolean((navigator as Navigator & { standalone?: boolean }).standalone);

  if (loading) {
    return (
      <div className="loading-screen">
        <div className="loading-mark"><span /><span /><span /><span /></div>
        <p>正在摊开账页…</p>
      </div>
    );
  }

  return (
    <div className={`app-shell view-${view}`}>
      <div className="desk-surface">
        {view === 'home' ? (
          <HomePage
            transactions={transactions}
            categories={categories}

            onOpenLedger={() => setView('ledger')}
            onOpenTransaction={setSelectedTransaction}
            onOpenSettings={() => setView('settings')}
          />
        ) : null}
        {view === 'capture' ? (
          <CapturePage
            stage={captureStage}
            progress={captureProgress}
            status={captureStatus}
            error={captureError}
            onBack={() => setView('home')}
            onReadClipboard={handleReadClipboard}
            onPasteImage={(blob) => handleImage(blob, true)}
            onTextDraft={handleTextDraft}
          />
        ) : null}
        {view === 'review' && draft ? (
          <ReviewPage
            draft={draft}
            categories={categories}
            duplicate={duplicate}
            onBack={handleAbandonDraft}
            onConfirm={handleConfirmDraft}
          />
        ) : null}
        {view === 'ledger' ? (
          <LedgerPage transactions={transactions} categories={categories} onOpenTransaction={setSelectedTransaction} onExport={exportCsv} />
        ) : null}
        {view === 'categories' ? (
          <CategoriesPage categories={categories} transactions={transactions} onSaveCategory={handleSaveCategory} onOpenTransaction={setSelectedTransaction} />
        ) : null}
        {view === 'settings' ? (
          <SettingsPage
            settings={settings}
            onSettingsChange={updateSettings}
            onExport={exportCsv}
            onClearSamples={handleClearSamples}
            onReset={handleReset}
            installPrompt={installPrompt}
            onInstall={handleInstall}
            isStandalone={isStandalone}
            cloudConfigured={cloudConfigured}
            cloudPhase={cloudPhase}
            cloudEmail={cloudUser?.email ?? ''}
            cloudError={cloudError}
            lastSyncedAt={lastSyncedAt}
            onCloudSignIn={handleCloudSignIn}
            onCloudSignUp={handleCloudSignUp}
            onCloudSignOut={handleCloudSignOut}
            onCloudSync={syncNow}
            shortcutToken={shortcutToken}
            shortcutEndpoint={shortcutCaptureEndpoint}
            shortcutApiKey={cloudPublishableKey}
            onGenerateShortcutToken={handleGenerateShortcutToken}
            onRevokeShortcutToken={handleRevokeShortcutToken}
            museToken={museToken}
            museEndpoint={museWriteEndpoint}
            museVisionEndpoint={museVisionEndpoint}
            museOcrEndpoint={museOcrEndpoint}
            onGenerateMuseToken={handleGenerateMuseToken}
            onRevokeMuseToken={handleRevokeMuseToken}
          />
        ) : null}
      </div>

      {['home', 'capture', 'ledger', 'categories', 'settings'].includes(view) ? (
        <BottomNav active={(view === 'ledger' ? 'home' : view) as AppView} onChange={(next) => {
          if (next === 'capture') {
            setCaptureError('');
            setCaptureStage('idle');
            setCaptureProgress(0);
          }
          setView(next);
        }} />
      ) : null}

      {selectedTransaction ? (
        <TransactionSheet
          transaction={selectedTransaction}
          categories={categories}
          onClose={() => setSelectedTransaction(null)}
          onSave={handleSaveTransaction}
          onDelete={handleDeleteTransaction}
        />
      ) : null}

      {toast ? (
        <div className="toast" role="status" key={toast.id}>
          <Check size={16} />
          <span>{toast.message}</span>
          <button type="button" onClick={() => setToast(null)} aria-label="关闭提示"><X size={14} /></button>
        </div>
      ) : null}
    </div>
  );
}
