import type { AppSettings, Category, Transaction } from './types';
import { DEFAULT_CATEGORIES } from './categories';
import { beijingDateTimeDaysAgo } from './parser';

const DB_NAME = 'yiyizhang';
const DB_VERSION = 1;
const SETTINGS_KEY = 'app';

let dbPromise: Promise<IDBDatabase> | null = null;

function openDb(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains('transactions')) {
        const store = db.createObjectStore('transactions', { keyPath: 'id' });
        store.createIndex('occurredAt', 'occurredAt');
      }
      if (!db.objectStoreNames.contains('categories')) {
        db.createObjectStore('categories', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings');
      }
    };
    request.onsuccess = () => resolve(request.result);
  });
  return dbPromise;
}

function requestToPromise<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export const DEFAULT_SETTINGS: AppSettings = {
  clearClipboard: true,
  seeded: false,
  learnedRules: true,
  installPromptDismissed: false,
};

export async function loadSettings(): Promise<AppSettings> {
  const db = await openDb();
  const tx = db.transaction('settings', 'readonly');
  const value = await requestToPromise(tx.objectStore('settings').get(SETTINGS_KEY));
  return { ...DEFAULT_SETTINGS, ...(value ?? {}) };
}

export async function saveSettings(settings: AppSettings): Promise<void> {
  const db = await openDb();
  const tx = db.transaction('settings', 'readwrite');
  await requestToPromise(tx.objectStore('settings').put(settings, SETTINGS_KEY));
}

export async function loadTransactions(): Promise<Transaction[]> {
  const db = await openDb();
  const tx = db.transaction('transactions', 'readonly');
  const rows = await requestToPromise(tx.objectStore('transactions').getAll());
  return rows.sort((a, b) => new Date(b.occurredAt).getTime() - new Date(a.occurredAt).getTime());
}

export async function saveTransaction(transaction: Transaction): Promise<void> {
  const db = await openDb();
  const tx = db.transaction('transactions', 'readwrite');
  await requestToPromise(tx.objectStore('transactions').put(transaction));
}

export async function deleteTransaction(id: string): Promise<void> {
  const db = await openDb();
  const tx = db.transaction('transactions', 'readwrite');
  await requestToPromise(tx.objectStore('transactions').delete(id));
}

export async function loadCategories(): Promise<Category[]> {
  const db = await openDb();
  const tx = db.transaction('categories', 'readonly');
  const rows = await requestToPromise(tx.objectStore('categories').getAll());
  if (!rows.length) return DEFAULT_CATEGORIES.map((category) => ({ ...category, keywords: [...category.keywords] }));
  return rows.sort((a, b) => DEFAULT_CATEGORIES.findIndex((c) => c.id === a.id) - DEFAULT_CATEGORIES.findIndex((c) => c.id === b.id));
}

export async function saveCategory(category: Category): Promise<void> {
  const db = await openDb();
  const tx = db.transaction('categories', 'readwrite');
  await requestToPromise(tx.objectStore('categories').put(category));
}

export async function saveCategories(categories: Category[]): Promise<void> {
  const db = await openDb();
  const tx = db.transaction('categories', 'readwrite');
  for (const category of categories) await requestToPromise(tx.objectStore('categories').put(category));
}

function atDaysAgo(days: number, hour: number, minute: number): string {
  return beijingDateTimeDaysAgo(days, hour, minute);
}

function sampleTransactions(): Transaction[] {
  return [
    { id: 'sample-1', amount: 15, direction: 'expense', merchant: 'Manner Coffee', categoryId: 'food', occurredAt: atDaysAgo(0, 13, 20), source: '微信', note: '拿铁', createdAt: new Date().toISOString(), isSample: true },
    { id: 'sample-2', amount: 4, direction: 'expense', merchant: '地铁出行', categoryId: 'transport', occurredAt: atDaysAgo(0, 9, 10), source: 'NFC', note: '通勤', createdAt: new Date().toISOString(), isSample: true },
    { id: 'sample-3', amount: 86.4, direction: 'expense', merchant: '盒马鲜生', categoryId: 'shopping', occurredAt: atDaysAgo(1, 19, 42), source: '支付宝', note: '晚餐食材', createdAt: new Date().toISOString(), isSample: true },
    { id: 'sample-4', amount: 42, direction: 'expense', merchant: '西西弗书店', categoryId: 'study', occurredAt: atDaysAgo(2, 16, 8), source: 'Apple Pay', note: '一本书', createdAt: new Date().toISOString(), isSample: true },
    { id: 'sample-5', amount: 12800, direction: 'income', merchant: '本月工资', categoryId: 'salary', occurredAt: atDaysAgo(7, 10, 0), source: '银行卡', note: '', createdAt: new Date().toISOString(), isSample: true },
    { id: 'sample-6', amount: 68, direction: 'expense', merchant: '滴滴出行', categoryId: 'transport', occurredAt: atDaysAgo(9, 22, 16), source: '支付宝', note: '回家', createdAt: new Date().toISOString(), isSample: true },
  ];
}

export async function seedIfNeeded(): Promise<{ transactions: Transaction[]; categories: Category[]; settings: AppSettings }> {
  const settings = await loadSettings();
  let categories = await loadCategories();
  if (!settings.seeded) {
    if (!categories.length) categories = DEFAULT_CATEGORIES.map((category) => ({ ...category, keywords: [...category.keywords] }));
    await saveCategories(categories);
    const existing = await loadTransactions();
    if (!existing.length) {
      for (const transaction of sampleTransactions()) await saveTransaction(transaction);
    } else if (existing.some((transaction) => !transaction.isSample)) {
      await clearSampleTransactions();
    }
    const nextSettings = { ...settings, seeded: true };
    await saveSettings(nextSettings);
    return { transactions: await loadTransactions(), categories, settings: nextSettings };
  }
  const current = await loadTransactions();
  if (current.some((transaction) => !transaction.isSample)) {
    await clearSampleTransactions();
    return { transactions: await loadTransactions(), categories, settings };
  }
  return { transactions: current, categories, settings };
}

export async function clearSampleTransactions(): Promise<void> {
  const db = await openDb();
  const tx = db.transaction('transactions', 'readwrite');
  const store = tx.objectStore('transactions');
  const rows = await requestToPromise(store.getAll());
  for (const row of rows as Transaction[]) {
    if (row.isSample) store.delete(row.id);
  }
}

export async function clearAllData(): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(['transactions', 'categories', 'settings'], 'readwrite');
  tx.objectStore('transactions').clear();
  tx.objectStore('categories').clear();
  tx.objectStore('settings').clear();
  await new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  dbPromise = null;
}

export async function replaceLedgerData(transactions: Transaction[], categories: Category[]): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(['transactions', 'categories'], 'readwrite');
  const transactionStore = tx.objectStore('transactions');
  const categoryStore = tx.objectStore('categories');
  transactionStore.clear();
  categoryStore.clear();
  for (const transaction of transactions) transactionStore.put(transaction);
  for (const category of categories) categoryStore.put(category);
  await new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}
