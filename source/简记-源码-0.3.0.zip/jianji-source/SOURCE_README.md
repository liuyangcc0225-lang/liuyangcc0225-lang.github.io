# 简记源码

这是简记 0.3.0 的可审阅源码包。

## 内容

- `src/`：React / TypeScript 页面、解析器、云端同步、OCR 和业务逻辑。
- `public/icons/`：PWA 图标。
- `scripts/publish-pages.mjs`：清理旧 assets 后构建并发布到 `jianji/`。
- `supabase/schema.sql`：数据库表、RLS、快捷指令和 Muse 写入/删除函数。
- `supabase/functions/muse-write/index.ts`：Muse 单密钥 HTTP Edge Function。
- `简记-Muse写入接口.md`：Muse 接口说明。

## 未放入源码包的资源

以下 OCR 运行资源较大，部署包中位于 Pages 仓库的 `jianji/tesseract` 和 `jianji/tessdata`：

- Tesseract worker 和 wasm core
- `chi_sim.traineddata.gz`
- `eng.traineddata.gz`

这些资源现在按需加载，不进入 Service Worker 首次安装预缓存。

## 本地构建

1. 安装 Node.js。
2. 在源码目录运行 `npm ci`。
3. 从已部署的 `jianji/` 目录复制 `tesseract`、`tessdata`、`icons` 到 `public/`。
4. 开发运行 `npm run dev`。
5. 构建运行 `npm run build`。
6. 发布到 Pages 目标目录：

```powershell
npm run publish:pages -- --target C:\path\to\repo\jianji
```

发布脚本会先删除旧的 `jianji` 部署目录，再复制新构建，避免累积旧 assets。

## 版本

- 0.3.0：分析筛选、分类预算、OCR 懒加载、Service Worker 仅预缓存应用壳。
