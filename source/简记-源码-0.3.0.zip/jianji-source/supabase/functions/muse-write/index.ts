import { createClient } from 'jsr:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type',
  'Access-Control-Allow-Methods': 'POST, DELETE, OPTIONS',
};

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json; charset=utf-8' },
  });
}

Deno.serve(async (request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (request.method !== 'POST' && request.method !== 'DELETE') {
    return json({ ok: false, error: 'method not allowed' }, 405);
  }

  const authorization = request.headers.get('authorization') ?? '';
  const token = authorization.match(/^Bearer\s+(muse_[A-Za-z0-9_-]{20,})$/i)?.[1];
  if (!token) return json({ ok: false, error: 'missing or invalid muse token' }, 401);

  const contentLength = Number(request.headers.get('content-length') ?? 0);
  if (contentLength > 16_384) return json({ ok: false, error: 'payload too large' }, 413);

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return json({ ok: false, error: 'invalid JSON body' }, 400);
  }
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    return json({ ok: false, error: 'JSON body must be an object' }, 400);
  }

  const body = payload as Record<string, unknown>;
  const isDelete = request.method === 'DELETE' || body.action === 'delete';

  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!supabaseUrl || !serviceRoleKey) return json({ ok: false, error: 'server is not configured' }, 500);

  const admin = createClient(supabaseUrl, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data, error } = isDelete
    ? await admin.rpc('muse_delete_transaction', {
        p_token: token,
        p_transaction_id: typeof body.transactionId === 'string' ? body.transactionId : null,
        p_external_id: typeof body.idempotencyKey === 'string' ? body.idempotencyKey : null,
      })
    : await admin.rpc('muse_write_transaction', {
        p_token: token,
        p_payload: payload,
      });

  if (error) {
    const status = error.code === '28000'
      ? 401
      : error.code === '22023'
        ? 400
        : error.code === 'P0002'
          ? 404
          : 500;
    return json({ ok: false, error: error.message }, status);
  }
  return json(data);
});
