# 简记源码 0.3.4

源码包包含 React/TypeScript 页面、OCR 懒加载、PWA 构建配置、Supabase Schema、Muse Edge Function 和发布脚本。

## 本次更新

- 分类页改成单一支出时间线，不再把每天先合并成多层分类卡片。
- 日期按北京时间倒序；同一天内按具体记账时间倒序。
- 每笔支出直接显示时间、商户、分类、支付方式和金额，并可打开账目详情。
- 保留分类管理、预算提醒和自定义分类编辑入口。

## Muse 权限

- `read`：查询账目与分类
- `write`：创建账目
- `update`：修改由 Muse 创建的账目
- `delete`：删除由 Muse 创建的账目

手工账目不会被 Muse 修改或删除。

## 构建

```powershell
npm ci
npm run build
npm run publish:pages -- --target C:\path\to\repo\jianji
```

Tesseract wasm 和语言包体积较大，不重复放入源码包。首次使用前从部署目录的 `jianji/tesseract`、`jianji/tessdata` 复制到源码项目的 `public/`。发布脚本会先带入并校验这些运行资源，再清空旧 `jianji/`，避免旧 assets 堆积。