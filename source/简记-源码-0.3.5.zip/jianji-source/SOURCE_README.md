# 简记源码 0.3.5

源码包包含 React/TypeScript 页面、OCR 懒加载、PWA 构建配置、Supabase Schema、Muse 文本与视觉 Edge Functions，以及发布脚本。

## 本次更新

- 新增 `muse-vision` 临时视觉解析接口：接收单张截图，返回账目草稿和 `writePayload`。
- 图片只在请求内存中转发给已配置的视觉供应商，不写 Storage、数据库或相册。
- 复用 `muse_...` Bearer 令牌，并在函数内部校验 SHA-256 哈希、撤销状态和 `write` scope。
- 支持 PNG、JPEG、WebP、HEIC，单图最大 8 MB。
- 设置页显示视觉接口地址，并可复制连接配置。
- 未配置视觉供应商时安全返回 503，不会返回伪造解析结果。

## 视觉解析配置

在 Supabase Edge Function Secrets 中配置：

```text
MUSE_VISION_ENDPOINT=https://你的视觉服务/v1/chat/completions
MUSE_VISION_API_KEY=你的供应商密钥
MUSE_VISION_MODEL=支持图片输入的模型名
```

完整请求和 iPhone 快捷指令流程见 `简记-Muse视觉解析接口.md`。

## Muse 权限

- `read`：查询账目与分类
- `write`：创建账目、调用视觉解析
- `update`：修改由 Muse 创建的账目
- `delete`：删除由 Muse 创建的账目

手工账目不会被 Muse 修改或删除。

## 构建

```powershell
npm ci
npm run build
npm run publish:pages -- --target C:\path\to\repo\jianji
```

Tesseract wasm 和语言包体积较大，不重复放入源码包。首次使用前从部署目录的 `jianji/tesseract`、`jianji/tessdata` 复制到源码项目的 `public/`。发布脚本会先带入并校验这些运行资源，再清空旧 `jianji/`，避免旧 assets 堆积。